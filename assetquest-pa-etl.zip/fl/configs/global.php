<?php
//require("controllers/user.php");

//File Directories and URLs
$urlStr = "http://184.168.245.24/score/data/fl";
$url = "184.168.245.24/score/data/fl";

if(isset($_GET['p'])){
	$pid = $_GET['p'];
}
?>