<div style="padding:15px;">
    <div class="row" style="width:100%;">
        <div class="large-12 columns">
            <div class="top-bar">
				<ul class="menu">
					<li class="menu-text">Select County: </li>
					<li>
					<form name="form" class="mob-nav">
						<select name="jumpMenu" id="jumpMenu" onchange="MM_jumpMenu('parent',this,0)">
							<option <?if($pid==5){echo "selected";};?> value="/score/data/fl/?p=5">Brevard County</option>
							<option <?if($pid==2){echo "selected";};?> value="/score/data/fl/?p=2">Charlotte County</option>
							<option <?if($pid==6){echo "selected";};?> value="/score/data/fl/?p=6">Citrus County</option>
							<option <?if($pid==4){echo "selected";};?> value="/score/data/fl/?p=4">Collier County</option>
							<option <?if($pid==7){echo "selected";};?> value="/score/data/fl/?p=7">Flagler County</option>
							<option <?if($pid==8){echo "selected";};?> value="/score/data/fl/?p=8">Indian River County</option>
							<option <?if($pid==1||$pid==0){echo "selected";};?> value="/score/data/fl/?p=1">Lee County</option>
							<option <?if($pid==9){echo "selected";};?> value="/score/data/fl/?p=9">Marion County</option>
							<option <?if($pid==10){echo "selected";};?> value="/score/data/fl/?p=10">Osceola County</option>
							<option <?if($pid==12){echo "selected";};?> value="/score/data/fl/?p=12">Polk County</option>
							<option <?if($pid==11){echo "selected";};?> value="/score/data/fl/?p=11">Saint Lucie County</option>
							<option <?if($pid==3){echo "selected";};?> value="/score/data/fl/?p=3">Sarasota County</option>
						</select>
					</form>
					</li>
                </ul>
            </div>
        </div>
    </div>
</div>