<div id="footerArea">
	<div id="footer">
        <div style="text-align:center; padding:5px;">
        Asset Quest | SCORE &copy; 2017 - 2018
        </div>
    </div>
</div>