<div style="padding:15px;">
    <div class="row" style="width:100%;">
        <div class="large-12 columns">
            <div class="top-bar">
                <ul class="menu">
                  <li class="menu-text">Select County: </li>
                  <li><a href="http://zadoodns.com/score/data/fl/?p=2"<?php if($pid==2){echo " style=\" font-weight:bold;\"";}; ?>>CHARLOTTE</a></li>
                  <li><a href="http://zadoodns.com/score/data/fl/?p=4"<?php if($pid==4){echo " style=\" font-weight:bold;\"";}; ?>>COLLIER</a></li>
                  <li><a href="http://zadoodns.com/score/data/fl/?p=1"<?php if($pid==1){echo " style=\" font-weight:bold;\"";}; ?>>LEE</a></li>
                  <li><a href="http://zadoodns.com/score/data/fl/?p=3"<?php if($pid==3){echo " style=\" font-weight:bold;\"";}; ?>>SARASOTA</a></li>
                </ul>
            </div>
        </div>
    </div>
</div>