<?php
if($sysmsg<>""){
?>
<div class="row" style="width:100%; margin-left:auto; margin-right:auto; margin-top:15px; margin-bottom:15px;">
	<div class="twelve columns">
        <div class="alert-box alert">
          <?php echo $sysmsg; ?>
          <a href="" class="close">&times;</a>
        </div>
	</div>
</div>
<?php
	$sysmsg = "";
} 
?>
<div class="row" style="width:100%; margin-top:15px; margin-bottom:15px;">
	<div class="twelve columns">
    <table width="100%" border="0" cellpadding="0" cellspacing="0">
      <tr>
        <td>
        <div style="padding:0px 20px;">
        <?php if($pid==1){ ?> <!--- Lee County Data Manager --->
            <?php include("views/lee.php"); ?>
		<?php }elseif($pid==2){ ?> <!--- Charlotte County Data Manager --->
            <?php include("views/cha.php"); ?>
		<?php }elseif($pid==3){ ?> <!--- Sarasota County Data Manager --->
            <?php include("views/sar.php"); ?>
		<?php }elseif($pid==4){ ?> <!--- Collier County Data Manager --->
            <?php include("views/col.php"); ?>
		<?php }else{ ?> <!--- Dashboard --->
            <?php include("views/dashboard.php"); ?>
        <?php } ?>
        </div>
        </td>
      </tr>
    </table>
	</div>
</div>