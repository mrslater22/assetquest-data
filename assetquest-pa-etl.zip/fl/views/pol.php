<h3 class="subheader">Polk County, FL - Prepare Import Table Scripts</h3>
<div>&raquo; <a href="https://p3nlmysqladm001.secureserver.net/nl41/67/index.php" target="_blank">PHPmyadmin</a></div>
<div class="row">
	<div class="large-12 columns">
        <table>
          <thead>
            <tr>
              <th>Description</th>
              <th width="75" style="text-align:center;">Action</th>
              <th width="550">Status</th>
            </tr>
          </thead>
          <tbody>
            <tr>
              <td>1. Clean Raw County Data</td>
              <td style="text-align:center;"><div id="comp1"><a class="small secondary button" onClick="clean_county_data_fl_pol('comp1','status1');" style="width:100%; margin:0px; padding:2px;">Run</a></div></td>
              <td><div id="status1"></div></td>
            </tr>
            <tr>
              <td>2. Truncate Master Table</td>
              <td style="text-align:center;"><div id="comp2"><a class="small secondary button" onClick="truncate_master_fl_pol('comp2','status2');" style="width:100%; margin:0px; padding:2px;">Run</a></td>
              <td><div id="status2"></div></td>
            </tr>
            <tr>
              <td>3. Insert Master Data</td>
              <td style="text-align:center;"><div id="comp3"><a class="small secondary button" onClick="insert_master_data_fl_pol('comp3','status3');" style="width:100%; margin:0px; padding:2px;">Run</a></div></td>
              <td><div id="status3"></div></td>
            </tr>
            <tr>
              <td>4. Clean Master Data</td>
              <td style="text-align:center;"><div id="comp4"><a class="small secondary button" onClick="clean_master_data_fl_pol('comp4','status4');" style="width:100%; margin:0px; padding:2px;">Run</a></div></td>
              <td><div id="status4"></div></td>
            </tr>
            <tr>
              <td>5. Truncate Import Table</td>
              <td style="text-align:center;"><div id="comp5"><a class="small secondary button" onClick="truncate_import_fl_pol('comp5','status5');" style="width:100%; margin:0px; padding:2px;">Run</a></td>
              <td><div id="status5"></div></td>
            </tr>
            <tr>
              <td>6. Insert Alturas Import Data</td>
              <td style="text-align:center;"><div id="comp6"><a class="small secondary button" onClick="insert_import_data_fl_pol('comp6','status6','ALT');" style="width:100%; margin:0px; padding:2px;">Run</a></td>
              <td><div id="status6"></div></td>
            </tr>
            <tr>
              <td>7. Insert Auburndale Import Data</td>
              <td style="text-align:center;"><div id="comp7"><a class="small secondary button" onClick="insert_import_data_fl_pol('comp7','status7','AUB');" style="width:100%; margin:0px; padding:2px;">Run</a></td>
              <td><div id="status7"></div></td>
            </tr>
            <tr>
              <td>8. Insert Babson Park Import Data</td>
              <td style="text-align:center;"><div id="comp8"><a class="small secondary button" onClick="insert_import_data_fl_pol('comp8','status8','BAP');" style="width:100%; margin:0px; padding:2px;">Run</a></td>
              <td><div id="status8"></div></td>
            </tr>
			<tr>
              <td>9. Insert Bartow Import Data</td>
              <td style="text-align:center;"><div id="comp9"><a class="small secondary button" onClick="insert_import_data_fl_pol('comp9','status9','BAR');" style="width:100%; margin:0px; padding:2px;">Run</a></td>
              <td><div id="status9"></div></td>
            </tr>
			<tr>
              <td>10. Insert Bowling Green Import Data</td>
              <td style="text-align:center;"><div id="comp10"><a class="small secondary button" onClick="insert_import_data_fl_pol('comp10','status10','BOG');" style="width:100%; margin:0px; padding:2px;">Run</a></td>
              <td><div id="status10"></div></td>
            </tr>
			<tr>
              <td>11. Insert Bradley Import Data</td>
              <td style="text-align:center;"><div id="comp11"><a class="small secondary button" onClick="insert_import_data_fl_pol('comp11','status11','BRA');" style="width:100%; margin:0px; padding:2px;">Run</a></td>
              <td><div id="status11"></div></td>
            </tr>
			<tr>
              <td>12. Insert Davenport Import Data</td>
              <td style="text-align:center;"><div id="comp12"><a class="small secondary button" onClick="insert_import_data_fl_pol('comp12','status12','DAV');" style="width:100%; margin:0px; padding:2px;">Run</a></td>
              <td><div id="status12"></div></td>
            </tr>
            <tr>
              <td>13. Insert Dundee Import Data</td>
              <td style="text-align:center;"><div id="comp13"><a class="small secondary button" onClick="insert_import_data_fl_pol('comp13','status13','DUN');" style="width:100%; margin:0px; padding:2px;">Run</a></td>
              <td><div id="status13"></div></td>
            </tr>
			<tr>
              <td>14. Insert Eagle Lake Import Data</td>
              <td style="text-align:center;"><div id="comp14"><a class="small secondary button" onClick="insert_import_data_fl_pol('comp14','status14','EAL');" style="width:100%; margin:0px; padding:2px;">Run</a></td>
              <td><div id="status14"></div></td>
            </tr>
			<tr>
              <td>15. Insert Eaton Park Import Data</td>
              <td style="text-align:center;"><div id="comp15"><a class="small secondary button" onClick="insert_import_data_fl_pol('comp15','status15','EAP');" style="width:100%; margin:0px; padding:2px;">Run</a></td>
              <td><div id="status15"></div></td>
            </tr>
			<tr>
              <td>16. Insert Eloise Import Data</td>
              <td style="text-align:center;"><div id="comp16"><a class="small secondary button" onClick="insert_import_data_fl_pol('comp16','status16','ELO');" style="width:100%; margin:0px; padding:2px;">Run</a></td>
              <td><div id="status16"></div></td>
            </tr>
			<tr>
              <td>17. Insert Fedhaven Import Data</td>
              <td style="text-align:center;"><div id="comp17"><a class="small secondary button" onClick="insert_import_data_fl_pol('comp17','status17','FED');" style="width:100%; margin:0px; padding:2px;">Run</a></td>
              <td><div id="status17"></div></td>
            </tr>
			<tr>
              <td>18. Insert Fort Meade Import Data</td>
              <td style="text-align:center;"><div id="comp18"><a class="small secondary button" onClick="insert_import_data_fl_pol('comp18','status18','FOM');" style="width:100%; margin:0px; padding:2px;">Run</a></td>
              <td><div id="status18"></div></td>
            </tr>
            <tr>
              <td>19. Insert Frostproof Import Data</td>
              <td style="text-align:center;"><div id="comp19"><a class="small secondary button" onClick="insert_import_data_fl_pol('comp19','status19','FRO');" style="width:100%; margin:0px; padding:2px;">Run</a></td>
              <td><div id="status19"></div></td>
            </tr>
			<tr>
              <td>20. Insert Grenelefe Import Data</td>
              <td style="text-align:center;"><div id="comp20"><a class="small secondary button" onClick="insert_import_data_fl_pol('comp20','status20','GRE');" style="width:100%; margin:0px; padding:2px;">Run</a></td>
              <td><div id="status20"></div></td>
            </tr>
            <tr>
              <td>21. Insert Haines City Import Data</td>
              <td style="text-align:center;"><div id="comp21"><a class="small secondary button" onClick="insert_import_data_fl_pol('comp21','status21','HAC');" style="width:100%; margin:0px; padding:2px;">Run</a></td>
              <td><div id="status21"></div></td>
            </tr>
            <tr>
              <td>22. Insert Highland City Import Data</td>
              <td style="text-align:center;"><div id="comp22"><a class="small secondary button" onClick="insert_import_data_fl_pol('comp22','status22','HIC');" style="width:100%; margin:0px; padding:2px;">Run</a></td>
              <td><div id="status22"></div></td>
            </tr>
            <tr>
              <td>23. Insert Homeland Import Data</td>
              <td style="text-align:center;"><div id="comp23"><a class="small secondary button" onClick="insert_import_data_fl_pol('comp23','status23','HOM');" style="width:100%; margin:0px; padding:2px;">Run</a></td>
              <td><div id="status23"></div></td>
            </tr>
            <tr>
              <td>24. Insert Indian Lake Estates Import Data</td>
              <td style="text-align:center;"><div id="comp24"><a class="small secondary button" onClick="insert_import_data_fl_pol('comp24','status24','ILE');" style="width:100%; margin:0px; padding:2px;">Run</a></td>
              <td><div id="status24"></div></td>
            </tr>
			<tr>
              <td>25. Insert Kathleen Import Data</td>
              <td style="text-align:center;"><div id="comp25"><a class="small secondary button" onClick="insert_import_data_fl_pol('comp25','status25','KAT');" style="width:100%; margin:0px; padding:2px;">Run</a></td>
              <td><div id="status25"></div></td>
            </tr>
			<tr>
              <td>26. Insert Kissimmee Import Data</td>
              <td style="text-align:center;"><div id="comp26"><a class="small secondary button" onClick="insert_import_data_fl_pol('comp26','status26','KIS');" style="width:100%; margin:0px; padding:2px;">Run</a></td>
              <td><div id="status26"></div></td>
            </tr>
			<tr>
              <td>27. Insert Lake Alfred Import Data</td>
              <td style="text-align:center;"><div id="comp27"><a class="small secondary button" onClick="insert_import_data_fl_pol('comp27','status27','LKA');" style="width:100%; margin:0px; padding:2px;">Run</a></td>
              <td><div id="status27"></div></td>
            </tr>
			<tr>
              <td>28. Insert Lake Hamilton Import Data</td>
              <td style="text-align:center;"><div id="comp28"><a class="small secondary button" onClick="insert_import_data_fl_pol('comp28','status28','LKH');" style="width:100%; margin:0px; padding:2px;">Run</a></td>
              <td><div id="status28"></div></td>
            </tr>
			<tr>
              <td>29. Insert Lake Wales Import Data</td>
              <td style="text-align:center;"><div id="comp29"><a class="small secondary button" onClick="insert_import_data_fl_pol('comp29','status29','LKW');" style="width:100%; margin:0px; padding:2px;">Run</a></td>
              <td><div id="status29"></div></td>
            </tr>
			<tr>
              <td>30. Insert Lakeland Import Data</td>
              <td style="text-align:center;"><div id="comp30"><a class="small secondary button" onClick="insert_import_data_fl_pol('comp30','status30','LKL');" style="width:100%; margin:0px; padding:2px;">Run</a></td>
              <td><div id="status30"></div></td>
            </tr>
			<tr>
              <td>31. Insert Lakeland DDA Import Data</td>
              <td style="text-align:center;"><div id="comp31"><a class="small secondary button" onClick="insert_import_data_fl_pol('comp31','status31','LKD');" style="width:100%; margin:0px; padding:2px;">Run</a></td>
              <td><div id="status31"></div></td>
            </tr>
			<tr>
              <td>32. Insert Lakeshore Import Data</td>
              <td style="text-align:center;"><div id="comp32"><a class="small secondary button" onClick="insert_import_data_fl_pol('comp32','status32','LKS');" style="width:100%; margin:0px; padding:2px;">Run</a></td>
              <td><div id="status32"></div></td>
            </tr>
			<tr>
              <td>33. Insert Loughman Import Data</td>
              <td style="text-align:center;"><div id="comp33"><a class="small secondary button" onClick="insert_import_data_fl_pol('comp33','status33','LOU');" style="width:100%; margin:0px; padding:2px;">Run</a></td>
              <td><div id="status33"></div></td>
            </tr>
			<tr>
              <td>34. Insert Mulberry Import Data</td>
              <td style="text-align:center;"><div id="comp34"><a class="small secondary button" onClick="insert_import_data_fl_pol('comp34','status34','MUL');" style="width:100%; margin:0px; padding:2px;">Run</a></td>
              <td><div id="status34"></div></td>
            </tr>
			<tr>
              <td>35. Insert Nichols Import Data</td>
              <td style="text-align:center;"><div id="comp35"><a class="small secondary button" onClick="insert_import_data_fl_pol('comp35','status35','NIC');" style="width:100%; margin:0px; padding:2px;">Run</a></td>
              <td><div id="status35"></div></td>
            </tr>
			<tr>
              <td>36. Insert Poinciana Import Data</td>
              <td style="text-align:center;"><div id="comp36"><a class="small secondary button" onClick="insert_import_data_fl_pol('comp36','status36','POI');" style="width:100%; margin:0px; padding:2px;">Run</a></td>
              <td><div id="status36"></div></td>
            </tr>
			<tr>
              <td>37. Insert Polk City Import Data</td>
              <td style="text-align:center;"><div id="comp37"><a class="small secondary button" onClick="insert_import_data_fl_pol('comp37','status37','POC');" style="width:100%; margin:0px; padding:2px;">Run</a></td>
              <td><div id="status37"></div></td>
            </tr>
			<tr>
              <td>38. Insert River Ranch Import Data</td>
              <td style="text-align:center;"><div id="comp38"><a class="small secondary button" onClick="insert_import_data_fl_pol('comp38','status38','RIR');" style="width:100%; margin:0px; padding:2px;">Run</a></td>
              <td><div id="status38"></div></td>
            </tr>
			<tr>
              <td>39. Insert Wahneta Import Data</td>
              <td style="text-align:center;"><div id="comp39"><a class="small secondary button" onClick="insert_import_data_fl_pol('comp39','status39','WAH');" style="width:100%; margin:0px; padding:2px;">Run</a></td>
              <td><div id="status39"></div></td>
            </tr>
			<tr>
              <td>40. Insert Waverly Import Data</td>
              <td style="text-align:center;"><div id="comp40"><a class="small secondary button" onClick="insert_import_data_fl_pol('comp40','status40','WAV');" style="width:100%; margin:0px; padding:2px;">Run</a></td>
              <td><div id="status40"></div></td>
            </tr>
			<tr>
              <td>41. Insert Winter Haven Import Data</td>
              <td style="text-align:center;"><div id="comp41"><a class="small secondary button" onClick="insert_import_data_fl_pol('comp41','status41','WIH');" style="width:100%; margin:0px; padding:2px;">Run</a></td>
              <td><div id="status41"></div></td>
            </tr>
          </tbody>
        </table>
    </div>
</div>