<h3 class="subheader">Sarasota County, FL - Prepare Import Table Scripts</h3>
<div>&raquo; <a href="https://p3nlmysqladm002.secureserver.net/grid55/7/index.php" target="_blank">PHPmyadmin</a></div>
<div class="row">
	<div class="large-12 columns">
        <table>
          <thead>
            <tr>
              <th>Description</th>
              <th width="75" style="text-align:center;">Action</th>
              <th width="550">Status</th>
            </tr>
          </thead>
          <tbody>
            <tr>
              <td>1. Clean Raw County Data</td>
              <td style="text-align:center;"><div id="comp1"><a class="small secondary button" onClick="clean_county_data_fl_sar('comp1','status1');" style="width:100%; margin:0px; padding:2px;">Run</a></div></td>
              <td><div id="status1"></div></td>
            </tr>
            <tr>
              <td>2. Truncate Master Table</td>
              <td style="text-align:center;"><div id="comp2"><a class="small secondary button" onClick="truncate_master_fl_sar('comp2','status2');" style="width:100%; margin:0px; padding:2px;">Run</a></td>
              <td><div id="status2"></div></td>
            </tr>
            <tr>
              <td>3. Insert Master Data</td>
              <td style="text-align:center;"><div id="comp3"><a class="small secondary button" onClick="insert_master_data_fl_sar('comp3','status3');" style="width:100%; margin:0px; padding:2px;">Run</a></div></td>
              <td><div id="status3"></div></td>
            </tr>
            <tr>
              <td>4. Clean Master Data</td>
              <td style="text-align:center;"><div id="comp4"><a class="small secondary button" onClick="clean_master_data_fl_sar('comp4','status4');" style="width:100%; margin:0px; padding:2px;">Run</a></div></td>
              <td><div id="status4"></div></td>
            </tr>
            <tr>
              <td>5. Truncate Import Table</td>
              <td style="text-align:center;"><div id="comp5"><a class="small secondary button" onClick="truncate_import_fl_sar('comp5','status5');" style="width:100%; margin:0px; padding:2px;">Run</a></td>
              <td><div id="status5"></div></td>
            </tr>
            <tr>
              <td>6. Insert North Port Import Data</td>
              <td style="text-align:center;"><div id="comp6"><a class="small secondary button" onClick="insert_import_data_fl_sar('comp6','status6','NOR');" style="width:100%; margin:0px; padding:2px;">Run</a></td>
              <td><div id="status6"></div></td>
            </tr>
            <tr>
              <td>7. Insert Englewood Import Data</td>
              <td style="text-align:center;"><div id="comp7"><a class="small secondary button" onClick="insert_import_data_fl_sar('comp7','status7','ENG');" style="width:100%; margin:0px; padding:2px;">Run</a></td>
              <td><div id="status7"></div></td>
            </tr>
            <tr>
              <td>8. Insert Lakewood Ranch Import Data</td>
              <td style="text-align:center;"><div id="comp8"><a class="small secondary button" onClick="insert_import_data_fl_sar('comp8','status8','LAK');" style="width:100%; margin:0px; padding:2px;">Run</a></td>
              <td><div id="status8"></div></td>
            </tr>
            <tr>
              <td>9. Insert Longboat Key Import Data</td>
              <td style="text-align:center;"><div id="comp9"><a class="small secondary button" onClick="insert_import_data_fl_sar('comp9','status9','LON');" style="width:100%; margin:0px; padding:2px;">Run</a></td>
              <td><div id="status9"></div></td>
            </tr>
            <tr>
              <td>10. Insert Mayakka City Import Data</td>
              <td style="text-align:center;"><div id="comp10"><a class="small secondary button" onClick="insert_import_data_fl_sar('comp10','status10','MYA');" style="width:100%; margin:0px; padding:2px;">Run</a></td>
              <td><div id="status10"></div></td>
            </tr>
            <tr>
              <td>11. Insert Nokomis Import Data</td>
              <td style="text-align:center;"><div id="comp11"><a class="small secondary button" onClick="insert_import_data_fl_sar('comp11','status11','NOK');" style="width:100%; margin:0px; padding:2px;">Run</a></td>
              <td><div id="status11"></div></td>
            </tr>
            <tr>
              <td>12. Insert North Venice Import Data</td>
              <td style="text-align:center;"><div id="comp12"><a class="small secondary button" onClick="insert_import_data_fl_sar('comp12','status12','NVE');" style="width:100%; margin:0px; padding:2px;">Run</a></td>
              <td><div id="status12"></div></td>
            </tr>
            <tr>
              <td>13. Insert Osprey Import Data</td>
              <td style="text-align:center;"><div id="comp13"><a class="small secondary button" onClick="insert_import_data_fl_sar('comp13','status13','OSP');" style="width:100%; margin:0px; padding:2px;">Run</a></td>
              <td><div id="status13"></div></td>
            </tr>
            <tr>
              <td>14. Insert Sarasota Import Data</td>
              <td style="text-align:center;"><div id="comp14"><a class="small secondary button" onClick="insert_import_data_fl_sar('comp14','status14','SAR');" style="width:100%; margin:0px; padding:2px;">Run</a></td>
              <td><div id="status14"></div></td>
            </tr>
            <tr>
              <td>15. Insert Sidell Import Data</td>
              <td style="text-align:center;"><div id="comp15"><a class="small secondary button" onClick="insert_import_data_fl_sar('comp15','status15','SID');" style="width:100%; margin:0px; padding:2px;">Run</a></td>
              <td><div id="status15"></div></td>
            </tr>
            <tr>
              <td>16. Insert Venice Import Data</td>
              <td style="text-align:center;"><div id="comp16"><a class="small secondary button" onClick="insert_import_data_fl_sar('comp16','status16','VEN');" style="width:100%; margin:0px; padding:2px;">Run</a></td>
              <td><div id="status16"></div></td>
            </tr>
          </tbody>
        </table>
    </div>
</div>