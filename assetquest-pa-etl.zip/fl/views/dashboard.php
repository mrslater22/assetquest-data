<h2>FL-LEE Dashboard</h2>
<h3 class="subheader">Prepare Import Scripts</h3>
<div class="row">
	<div class="large-12 columns">
        <table>
          <thead>
            <tr>
              <th>Description</th>
              <th width="75" style="text-align:center;">Action</th>
              <th width="550">Status</th>
            </tr>
          </thead>
          <tbody>
            <tr>
              <td>1. Clean Raw County Data</td>
              <td style="text-align:center;"><div id="comp1"><a class="small secondary button" onClick="cleanCountyData('comp1','status1');" style="width:100%; margin:0px; padding:2px;">Run</a></div></td>
              <td><div id="status1"></div></td>
            </tr>
            <tr>
              <td>2. Truncate Master Table</td>
              <td style="text-align:center;"><div id="comp2"><a class="small secondary button" onClick="truncateMaster('comp2','status2');" style="width:100%; margin:0px; padding:2px;">Run</a></td>
              <td><div id="status2"></div></td>
            </tr>
            <tr>
              <td>3. Insert Raw County Data</td>
              <td style="text-align:center;"><div id="comp3"><a class="small secondary button" onClick="insertCountyData('comp3','status3');" style="width:100%; margin:0px; padding:2px;">Run</a></div></td>
              <td><div id="status3"></div></td>
            </tr>
            <tr>
              <td>4. Clean Master Data</td>
              <td style="text-align:center;"><div id="comp4"><a class="small secondary button" onClick="cleanMasterData('comp4','status4');" style="width:100%; margin:0px; padding:2px;">Run</a></div></td>
              <td><div id="status4"></div></td>
            </tr>
            <tr>
              <td>5. Truncate Import Table</td>
              <td style="text-align:center;"><div id="comp5"><a class="small secondary button" onClick="truncateImport('comp5','status5');" style="width:100%; margin:0px; padding:2px;">Run</a></td>
              <td><div id="status5"></div></td>
            </tr>
            <tr>
              <td>6. Insert Cape Coral Import Data</td>
              <td style="text-align:center;"><div id="comp6"><a class="small secondary button" onClick="insertImportData('comp6','status6','CAP');" style="width:100%; margin:0px; padding:2px;">Run</a></td>
              <td><div id="status6"></div></td>
            </tr>
            <tr>
              <td>7. Insert Lehigh Acres Import Data</td>
              <td style="text-align:center;"><div id="comp7"><a class="small secondary button" onClick="insertImportData('comp7','status7','LEH');" style="width:100%; margin:0px; padding:2px;">Run</a></td>
              <td><div id="status7"></div></td>
            </tr>
          </tbody>
        </table>
    </div>
</div>