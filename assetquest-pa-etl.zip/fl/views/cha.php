<h3 class="subheader">Charlotte County, FL - Prepare Import Table Scripts</h3>
<div>&raquo; <a href="https://p3nlmysqladm002.secureserver.net/grid55/53/index.php" target="_blank">PHPmyadmin</a></div>
<div class="row">
	<div class="large-12 columns">
        <table>
          <thead>
            <tr>
              <th>Description</th>
              <th width="75" style="text-align:center;">Action</th>
              <th width="550">Status</th>
            </tr>
          </thead>
          <tbody>
            <tr>
              <td>1. Clean Raw County Data</td>
              <td style="text-align:center;"><div id="comp1"><a class="small secondary button" onClick="clean_county_data_fl_cha('comp1','status1');" style="width:100%; margin:0px; padding:2px;">Run</a></div></td>
              <td><div id="status1"></div></td>
            </tr>
            <tr>
              <td>2. Truncate Master Table</td>
              <td style="text-align:center;"><div id="comp2"><a class="small secondary button" onClick="truncate_master_fl_cha('comp2','status2');" style="width:100%; margin:0px; padding:2px;">Run</a></td>
              <td><div id="status2"></div></td>
            </tr>
            <tr>
              <td>3. Insert Master Data</td>
              <td style="text-align:center;"><div id="comp3"><a class="small secondary button" onClick="insert_master_data_fl_cha('comp3','status3');" style="width:100%; margin:0px; padding:2px;">Run</a></div></td>
              <td><div id="status3"></div></td>
            </tr>
            <tr>
              <td>4. Clean Master Data</td>
              <td style="text-align:center;"><div id="comp4"><a class="small secondary button" onClick="clean_master_data_fl_cha('comp4','status4');" style="width:100%; margin:0px; padding:2px;">Run</a></div></td>
              <td><div id="status4"></div></td>
            </tr>
            <tr>
              <td>5. Truncate Import Table</td>
              <td style="text-align:center;"><div id="comp5"><a class="small secondary button" onClick="truncate_import_fl_cha('comp5','status5');" style="width:100%; margin:0px; padding:2px;">Run</a></td>
              <td><div id="status5"></div></td>
            </tr>
            <tr>
              <td>6. Insert Port Charlotte Import Data</td>
              <td style="text-align:center;"><div id="comp6"><a class="small secondary button" onClick="insert_import_data_fl_cha('comp6','status6','POR');" style="width:100%; margin:0px; padding:2px;">Run</a></td>
              <td><div id="status6"></div></td>
            </tr>
            <tr>
              <td>7. Insert Punta Gorda Import Data</td>
              <td style="text-align:center;"><div id="comp7"><a class="small secondary button" onClick="insert_import_data_fl_cha('comp7','status7','PUN');" style="width:100%; margin:0px; padding:2px;">Run</a></td>
              <td><div id="status7"></div></td>
            </tr>
            <tr>
              <td>8. Insert Boca Grande Import Data</td>
              <td style="text-align:center;"><div id="comp8"><a class="small secondary button" onClick="insert_import_data_fl_cha('comp8','status8','BOC');" style="width:100%; margin:0px; padding:2px;">Run</a></td>
              <td><div id="status8"></div></td>
            </tr>
            <tr>
              <td>9. Insert Englewood Import Data</td>
              <td style="text-align:center;"><div id="comp9"><a class="small secondary button" onClick="insert_import_data_fl_cha('comp9','status9','ENG');" style="width:100%; margin:0px; padding:2px;">Run</a></td>
              <td><div id="status9"></div></td>
            </tr>
            <tr>
              <td>10. Insert North Fort Myers Import Data</td>
              <td style="text-align:center;"><div id="comp10"><a class="small secondary button" onClick="insert_import_data_fl_cha('comp10','status10','NFM');" style="width:100%; margin:0px; padding:2px;">Run</a></td>
              <td><div id="status10"></div></td>
            </tr>
            <tr>
              <td>11. Insert Placida Import Data</td>
              <td style="text-align:center;"><div id="comp11"><a class="small secondary button" onClick="insert_import_data_fl_cha('comp11','status11','PLA');" style="width:100%; margin:0px; padding:2px;">Run</a></td>
              <td><div id="status11"></div></td>
            </tr>
          </tbody>
        </table>
    </div>
</div>