<div class="row">
    <div class="twelve columns">
        <h4>Login</h4>
        <div class="panel radius">
        <form name="userLogin" method="post" action="">
            <label<?php if($error1==1){echo " class=\"error\"";} ?>><strong>Email:</strong></label>
            <input<?php if($error1==1){echo " class=\"error\"";} ?> type="text" name="uName" size="20" maxlength="50" value="<?php echo $_POST['uName']; ?>" />
            <?php if($error1==1){echo "<small class=\"error\">".$error1msg."</small>";} ?>
            <label<?php if($error2==1){echo " class=\"error\"";} ?>><strong>Password:</strong></label>
            <input<?php if($error2==1){echo " class=\"error\"";} ?> type="password" name="pWord" size="20" maxlength="25" />
            <?php if($error2==1){echo "<small class=\"error\">".$error2msg."</small>";} ?>
            <input type="hidden" name="processID" value="1" />
            <input type="submit" name="submit" value="Submit" />
        </form>
        </div>
	</div>
</div>