<h3 class="subheader">Brevard County, FL - Prepare Import Table Scripts</h3>
<div>&raquo; <a href="https://p3nlmysqladm002.secureserver.net/grid55/231/index.php" target="_blank">PHPmyadmin</a></div>
<div class="row">
	<div class="large-12 columns">
        <table>
          <thead>
            <tr>
              <th>Description</th>
              <th width="75" style="text-align:center;">Action</th>
              <th width="550">Status</th>
            </tr>
          </thead>
          <tbody>
            <tr>
              <td>1. Clean Raw County Data</td>
              <td style="text-align:center;"><div id="comp1"><a class="small secondary button" onClick="clean_county_data_fl_bre('comp1','status1');" style="width:100%; margin:0px; padding:2px;">Run</a></div></td>
              <td><div id="status1"></div></td>
            </tr>
            <tr>
              <td>2. Truncate Master Table</td>
              <td style="text-align:center;"><div id="comp2"><a class="small secondary button" onClick="truncate_master_fl_bre('comp2','status2');" style="width:100%; margin:0px; padding:2px;">Run</a></td>
              <td><div id="status2"></div></td>
            </tr>
            <tr>
              <td>3. Insert Master Data</td>
              <td style="text-align:center;"><div id="comp3"><a class="small secondary button" onClick="insert_master_data_fl_bre('comp3','status3');" style="width:100%; margin:0px; padding:2px;">Run</a></div></td>
              <td><div id="status3"></div></td>
            </tr>
            <tr>
              <td>4. Clean Master Data</td>
              <td style="text-align:center;"><div id="comp4"><a class="small secondary button" onClick="clean_master_data_fl_bre('comp4','status4');" style="width:100%; margin:0px; padding:2px;">Run</a></div></td>
              <td><div id="status4"></div></td>
            </tr>
            <tr>
              <td>5. Truncate Import Table</td>
              <td style="text-align:center;"><div id="comp5"><a class="small secondary button" onClick="truncate_import_fl_bre('comp5','status5');" style="width:100%; margin:0px; padding:2px;">Run</a></td>
              <td><div id="status5"></div></td>
            </tr>
            <tr>
              <td>6. Insert Barefoot Bay Import Data</td>
              <td style="text-align:center;"><div id="comp6"><a class="small secondary button" onClick="insert_import_data_fl_bre('comp6','status6','BAB');" style="width:100%; margin:0px; padding:2px;">Run</a></td>
              <td><div id="status6"></div></td>
            </tr>
            <tr>
              <td>7. Insert Cape Canaveral Import Data</td>
              <td style="text-align:center;"><div id="comp7"><a class="small secondary button" onClick="insert_import_data_fl_bre('comp7','status7','CAC');" style="width:100%; margin:0px; padding:2px;">Run</a></td>
              <td><div id="status7"></div></td>
            </tr>
			<tr>
              <td>8. Insert Cocoa Import Data</td>
              <td style="text-align:center;"><div id="comp8"><a class="small secondary button" onClick="insert_import_data_fl_bre('comp8','status8','COC');" style="width:100%; margin:0px; padding:2px;">Run</a></td>
              <td><div id="status8"></div></td>
            </tr>
            <tr>
              <td>9. Insert Cocoa Beach Import Data</td>
              <td style="text-align:center;"><div id="comp9"><a class="small secondary button" onClick="insert_import_data_fl_bre('comp9','status9','COB');" style="width:100%; margin:0px; padding:2px;">Run</a></td>
              <td><div id="status9"></div></td>
            </tr>
			<tr>
              <td>10. Insert Fellsmere Import Data</td>
              <td style="text-align:center;"><div id="comp10"><a class="small secondary button" onClick="insert_import_data_fl_bre('comp10','status10','FEL');" style="width:100%; margin:0px; padding:2px;">Run</a></td>
              <td><div id="status10"></div></td>
            </tr>
			<tr>
              <td>11. Insert Grant Valkaria Import Data</td>
              <td style="text-align:center;"><div id="comp11"><a class="small secondary button" onClick="insert_import_data_fl_bre('comp11','status11','GRV');" style="width:100%; margin:0px; padding:2px;">Run</a></td>
              <td><div id="status11"></div></td>
            </tr>
			<tr>
              <td>12. Insert Indialantic Import Data</td>
              <td style="text-align:center;"><div id="comp12"><a class="small secondary button" onClick="insert_import_data_fl_bre('comp12','status12','IND');" style="width:100%; margin:0px; padding:2px;">Run</a></td>
              <td><div id="status12"></div></td>
            </tr>
            <tr>
              <td>13. Insert Indian Harbour Beach Import Data</td>
              <td style="text-align:center;"><div id="comp13"><a class="small secondary button" onClick="insert_import_data_fl_bre('comp13','status13','IHB');" style="width:100%; margin:0px; padding:2px;">Run</a></td>
              <td><div id="status13"></div></td>
            </tr>
			<tr>
              <td>14. Insert Melabar Import Data</td>
              <td style="text-align:center;"><div id="comp14"><a class="small secondary button" onClick="insert_import_data_fl_bre('comp14','status14','MAL');" style="width:100%; margin:0px; padding:2px;">Run</a></td>
              <td><div id="status14"></div></td>
            </tr>
            <tr>
              <td>15. Insert Melbourne Import Data</td>
              <td style="text-align:center;"><div id="comp15"><a class="small secondary button" onClick="insert_import_data_fl_bre('comp15','status15','MEL');" style="width:100%; margin:0px; padding:2px;">Run</a></td>
              <td><div id="status15"></div></td>
            </tr>
			<tr>
              <td>16. Insert Melbourne Beach Import Data</td>
              <td style="text-align:center;"><div id="comp16"><a class="small secondary button" onClick="insert_import_data_fl_bre('comp16','status16','MEB');" style="width:100%; margin:0px; padding:2px;">Run</a></td>
              <td><div id="status16"></div></td>
            </tr>
			<tr>
              <td>17. Insert Melbourne Village Import Data</td>
              <td style="text-align:center;"><div id="comp17"><a class="small secondary button" onClick="insert_import_data_fl_bre('comp17','status17','MEV');" style="width:100%; margin:0px; padding:2px;">Run</a></td>
              <td><div id="status17"></div></td>
            </tr>
			<tr>
              <td>18. Insert Merritt Island Import Data</td>
              <td style="text-align:center;"><div id="comp18"><a class="small secondary button" onClick="insert_import_data_fl_bre('comp18','status18','MEI');" style="width:100%; margin:0px; padding:2px;">Run</a></td>
              <td><div id="status18"></div></td>
            </tr>
			<tr>
              <td>19. Insert Micco Import Data</td>
              <td style="text-align:center;"><div id="comp19"><a class="small secondary button" onClick="insert_import_data_fl_bre('comp19','status19','MIC');" style="width:100%; margin:0px; padding:2px;">Run</a></td>
              <td><div id="status19"></div></td>
            </tr>
			<tr>
              <td>20. Insert Mims Import Data</td>
              <td style="text-align:center;"><div id="comp20"><a class="small secondary button" onClick="insert_import_data_fl_bre('comp20','status20','MIM');" style="width:100%; margin:0px; padding:2px;">Run</a></td>
              <td><div id="status20"></div></td>
            </tr>
            <tr>
              <td>21. Insert Palm Bay Import Data</td>
              <td style="text-align:center;"><div id="comp21"><a class="small secondary button" onClick="insert_import_data_fl_bre('comp21','status21','PAB');" style="width:100%; margin:0px; padding:2px;">Run</a></td>
              <td><div id="status21"></div></td>
            </tr>
			<tr>
              <td>22. Insert Palm Shores Import Data</td>
              <td style="text-align:center;"><div id="comp22"><a class="small secondary button" onClick="insert_import_data_fl_bre('comp22','status22','PAS');" style="width:100%; margin:0px; padding:2px;">Run</a></td>
              <td><div id="status22"></div></td>
            </tr>
            <tr>
              <td>23. Insert Rockledge Import Data</td>
              <td style="text-align:center;"><div id="comp23"><a class="small secondary button" onClick="insert_import_data_fl_bre('comp23','status23','ROC');" style="width:100%; margin:0px; padding:2px;">Run</a></td>
              <td><div id="status23"></div></td>
            </tr>
            <tr>
              <td>24. Insert Satellite Beach Import Data</td>
              <td style="text-align:center;"><div id="comp24"><a class="small secondary button" onClick="insert_import_data_fl_bre('comp24','status24','SAB');" style="width:100%; margin:0px; padding:2px;">Run</a></td>
              <td><div id="status24"></div></td>
            </tr>
            <tr>
              <td>25. Insert Titusville Import Data</td>
              <td style="text-align:center;"><div id="comp25"><a class="small secondary button" onClick="insert_import_data_fl_bre('comp25','status25','TIT');" style="width:100%; margin:0px; padding:2px;">Run</a></td>
              <td><div id="status25"></div></td>
            </tr>
            <tr>
              <td>26. Insert West Melbourne Import Data</td>
              <td style="text-align:center;"><div id="comp26"><a class="small secondary button" onClick="insert_import_data_fl_bre('comp26','status26','WEM');" style="width:100%; margin:0px; padding:2px;">Run</a></td>
              <td><div id="status26"></div></td>
            </tr>

          </tbody>
        </table>
    </div>
</div>