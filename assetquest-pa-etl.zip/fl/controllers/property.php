<?php
function checkPropGeo($uid) {
	// Select all the rows in the markers table
	$query = "SELECT P.* FROM tbl_user U LEFT JOIN tbl_userPortMap UPM ON U.userID = UPM.userID LEFT JOIN tbl_portfolio PORT ON UPM.portfolioID = PORT.portfolioID LEFT JOIN tbl_portPropMap PPM ON PORT.portfolioID = PPM.aPortfolioID LEFT JOIN tbl_property P ON PPM.propertyID = P.propertyID WHERE U.userID = ".$uid." AND geocoded = 0";
	$result = mysql_query($query);
	if (!$result) {
	  die("Invalid query: " . mysql_error());
	}
	
	// Initialize delay in geocode speed
	$delay = 0;
	$base_url = "http://maps.googleapis.com/maps/api/geocode/xml";
	
	// Iterate through the rows, geocoding each address
	while ($row = @mysql_fetch_assoc($result)) {
	  $geocode_pending = true;
	
	  while ($geocode_pending) {
		$address = $row["siteAddress"].", ".$row["siteCity"].", ".$row["siteState"];
		$id = $row["propertyID"];
		$request_url = $base_url . "?address=".urlencode($address)."&sensor=false";
		$xml = simplexml_load_file($request_url) or die("url not loading");
	
		$status = $xml->status;
		if ($status=="OK") {
		  // Successful geocode
		  $geocode_pending = false;
		  // Format: Longitude, Latitude, Altitude
		  $lat = $xml->result->geometry->location->lat;
		  $lng = $xml->result->geometry->location->lng;
	
		  $query = sprintf("UPDATE tbl_property " .
				 " SET lat = '%s', lng = '%s', geocoded = 1 " .
				 " WHERE propertyID = '%s' LIMIT 1;",
				 mysql_real_escape_string($lat),
				 mysql_real_escape_string($lng),
				 mysql_real_escape_string($id));
		  $update_result = mysql_query($query);
		  if (!$update_result) {
			die("Invalid query: " . mysql_error());
		  }
		  echo "Address " . $address . " geocoded. <br />";
		} else if ($status=="ZERO_RESULTS") {
		  // sent geocodes too fast
		  $delay += 100000;
		} else {
		  // failure to geocode
		  $geocode_pending = false;
		  echo "Address " . $address . " failed to geocoded. ";
		  echo "Received status " . $status . "<br />";
		}
		usleep($delay);
	  }
	}

	return 1;
}
?>