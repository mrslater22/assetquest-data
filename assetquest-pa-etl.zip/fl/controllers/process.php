<?php
if(isset($_POST['processID'])){
	
	//User Login
	if($_POST['processID']==1){
		include("controllers/forms.php");
		$uNameClean = addslashes(strip_tags(strtolower($_POST['uName'])));
		$pWord = addslashes(strip_tags($_POST['pWord']));
		
		//Validate Login Form
		$fmCheck = checkLogin($uNameClean,$pWord);

		if ($fmCheck[0] == 1) {
			$loginCheck = login($uNameClean,$pWord);
			if($loginCheck == 1){
				//Geocodes properties if not geocoded
				$checkPropGeo = checkPropGeo($_SESSION['uid']);
				header('Location: index.php?p=2');
			}elseif($loginCheck == 0){
				$sysmsg = "Sorry, Your Username/Password Combination Did Not Work.";
			}elseif($loginCheck == 2){
				$sysmsg = "Sorry, Your Are Not Authorized To Use This System.";
			}
		}else{
			$sysmsg = "Please verify the Email and Password have been entered.";
			$error1 = $fmCheck[1];
			$error1msg = $fmCheck[2];
			$error2 = $fmCheck[3];
			$error2msg = $fmCheck[4];
		}
	}
	
	//Validate Prospect Info
	if($_POST['processID']==2){
		include("controllers/forms.php");
		$prospectID = $_POST['prospectID'];
		$zipCode = $_POST['zipCode'];

		//Validate Prospect Form
		$fmCheck = checkProspect($prospectID,$zipCode);
		
		if ($fmCheck[0] == 1) {
			//Validate Prospect Info
			$uid = checkProspectExist($prospectID,$zipCode);
			if ($uid > 0) {
				//Geocodes properties if not geocoded
				$checkPropGeo = checkPropGeo($uid);
				$_SESSION['uid']=$uid;
				header('Location: index.php?p=8');
			}else{
				$sysmsg = "We could not find your account.  Please check your Prospect ID and Zip Code on the postcard or contact technical support for assistance (239) 541-8448.";
			}
		}else{
			$sysmsg = "Please verify the Prospect ID and 5-Digit Zip Code have been entered.";
			$error3 = $fmCheck[1];
			$error3msg = $fmCheck[2];
			$error4 = $fmCheck[3];
			$error4msg = $fmCheck[4];
		}
	}
	
	//Create Account
	if($_POST['processID']==3){
		include("controllers/forms.php");
		include("controllers/notifications.php");
		
		//Get Form Submission Values
		$userID = $_POST['userID'];
		$email = addslashes(strip_tags($_POST['email']));
		$uName = addslashes(strip_tags($_POST['email']));
		$uNameClean = addslashes(strip_tags(strtolower($_POST['email'])));
		$pWord = addslashes(strip_tags($_POST['pWord']));
		$vCode = generateRandom();
		
		//Validate Registration Form
		$fmCheck = checkReg($email,$pWord);
		
		if ($fmCheck[0] == 1) {
			//Check User
			$usrCheck = checkUser(1,$uNameClean);

			if($usrCheck==0){
				$uid = updateUserInfo($userID,$email,$uName,$uNameClean,$pWord,$vCode);
				sendWelcome($userID,$urlStr);
				setUserSession($userID);
				$sysmsg = "Your Asset Quest Virtual Portfolio account has been created! Please check your email to validate your new account";
				header('Location: index.php?p=9');
			}else{
				$error1 = 1;
				$error1msg = "Email Already Exists.";
				$sysmsg = "This email address has already been used for another account..";
			}	
		}else{
			$error1 = $fmCheck[1];
			$error1msg = $fmCheck[2];
			$error2 = $fmCheck[3];
			$error2msg = $fmCheck[4];
		}
	}
	
	//User Validation
	if($_POST['processID']==4){
		include("controllers/notifications.php");
		sendValidation($_POST['userID'],$urlStr);
		$sysmsg = "Your Asset Quest Virtual Portal Account Validation Email Has Been Sent.";
	}
	
	//Update User Email And Validation
	if($_POST['processID']==5){
		include("controllers/notifications.php");
		$fmCheck = updateEmail($_POST['userID'],$_POST['email']);
		if ($fmCheck[0] == 1) {
			sendValidation($_POST['userID'],$urlStr);
			$sysmsg = "Your Asset Quest Virtual Portal Account Validation Email Has Been Sent.";
		}else{
			$sysmsg = "This Email Account Is Already Being Used By Another User. Please Contact Customer Service Or Use Another Email Account.";
		}
	}

	//User Forgot Password Service
	if($_POST['processID']==6){
		include("controllers/notifications.php");
		$uNameClean = addslashes(strip_tags(strtolower($_POST['uName'])));
		
		//Validate Login Form
		$fmCheck = $checkForgot($uNameClean);
		
		if ($fmCheck[0] == 1) {
			$pWordNew = resetPassword($uNameClean);
			if ($pWordNew[1] == 1) {
				sendPassword($pWordNew[2],$pWordNew[3]);
				$sysmsg = "Your Temporary Password Has Been Sent To Your Email.";
				$vid = 24;
			}else{
				$sysmsg = "The Username/Email Provided Does Not Exist In Our System.";
			}
		}else{
			$error1 = $fmCheck[1];
			$error1msg = $fmCheck[2];
		}
	}
	
	//Send Offer Request
	if($_POST['processID']==7){
		include("controllers/forms.php");
		include("controllers/notifications.php");
		$fmCheck = checkPhone($_POST['phone']);
		if ($fmCheck[0] == 1) {
			updatePhone($_POST['userID'],$_POST['phone']);
			sendOfferReq($_POST['userID'],$urlStr);
			$sysmsg = "Your Offer Request Has Been Sent.";
		}else{
			$sysmsg = "Your Phone Number Is Required For An Offer Request So May Contact You To Discuss The Offer Details.";
		}
	}
	
	//Update Property Info
	if($_POST['processID']==8){
		include("controllers/forms.php");
		
		//Get Relationship Record ID
		$propertyID = $_POST['propertyID'];
		
		//Begin Process Property Image File
		if($_FILES["file1"]["name"]<>""){
			if ($_FILES["file1"]["error"]>0){
				$sysmsg = "Error: " . $_FILES["file1"]["error"];
			}else{				
				$path_parts = pathinfo($propFileDir.$_FILES["file1"]["name"]);		
				$fileExt = strtolower($path_parts['extension']);
				$fileType = $_FILES["file1"]["type"];
				$fileSize = $_FILES["file1"]["size"];
				$_SESSION['file1Ext'] = $fileExt;		
				if($fileExt=='jpg'||$fileExt=='jpeg'||$fileExt=='gif'||$fileExt=='png'){
					//Process Content Image
					$assetTypeID = 1;
					$relID = $propertyID;
					//Check For Existing Asset
					$query = "SELECT * FROM tbl_asset WHERE assetTypeID = ".$assetTypeID." AND relID = ".$relID;
					$result = mysql_query($query);
					$rcount = mysql_num_rows($result);
					$row = mysql_fetch_array($result);
					$_SESSION['sQry2'] = $query;
					
					if($rcount==0){
						//Insert New Property Image Asset Record
						$fieldStr = "assetTypeID,relID,createUID";
						$valueStr = $assetTypeID.",".$relID.",1";
						$query = "INSERT INTO tbl_asset (".$fieldStr.") VALUES (".$valueStr.")";
						mysql_query($query);
						$_SESSION['iQry2'] = $query;
					
						//Get New Content Image Asset Record ID
						$assetID = mysql_insert_id();
					}else{
						$assetID = $row['assetID'];
					}
					
					$newFileName = "prop".$assetID;
					$newFilePath = $propFileDir.$newFileName.".".$fileExt;
					
					move_uploaded_file($_FILES["file1"]["tmp_name"],$newFilePath);
					
					//Update Content Image Asset Record
					$query = "UPDATE tbl_asset SET fileName = '".$newFileName."', fileExt = '".$fileExt."', fileType = '".$fileType."', fileSize = ".$fileSize.", fileDir = '".addslashes($propFileDir)."', fileWebDir = '".$propFileWebDir."' WHERE assetID = ".$assetID;
					mysql_query($query);
					$_SESSION['uQry2'] = $query;
					
					//Begin Resize Image
					if($fileExt=='jpg'||$fileExt=='jpeg'){
						$imageSrc = imagecreatefromjpeg($newFilePath);
					}elseif($fileExt=='gif'){
						$imageSrc = imagecreatefromgif($newFilePath);
					}elseif($fileExt=='png'){
						$imageSrc = imagecreatefrompng($newFilePath);
					}
					
					list($width,$height) = getimagesize($newFilePath);
					
					$newwidth1 = 300;
					$newheight1 = ($height/$width)*$newwidth1;
					$tmpImage1 = imagecreatetruecolor($newwidth1,$newheight1);
					imagecopyresampled($tmpImage1,$imageSrc,0,0,0,0,$newwidth1,$newheight1,$width,$height);
					$fileName1 = $propFileDir.$newFileName."_300.".$fileExt;
					
					$newwidth2 = 200;
					$newheight2 = ($height/$width)*$newwidth2;
					$tmpImage2 = imagecreatetruecolor($newwidth2,$newheight2);
					imagecopyresampled($tmpImage2,$imageSrc,0,0,0,0,$newwidth2,$newheight2,$width,$height);
					$fileName2 = $propFileDir.$newFileName."_200.".$fileExt;
					
					$newwidth3 = 100;
					$newheight3 = ($height/$width)*$newwidth3;
					$tmpImage3 = imagecreatetruecolor($newwidth3,$newheight3);
					imagecopyresampled($tmpImage3,$imageSrc,0,0,0,0,$newwidth3,$newheight3,$width,$height);
					$fileName3 = $propFileDir.$newFileName."_100.".$fileExt;
					
					if($fileExt=='jpg'||$fileExt=='jpeg'){
						imagejpeg($tmpImage1,$fileName1,100);
						imagejpeg($tmpImage2,$fileName2,100);
						imagejpeg($tmpImage3,$fileName3,100);
					}elseif($fileExt=='gif'){
						imagegif($tmpImage1,$fileName1,100);
						imagegif($tmpImage2,$fileName2,100);
						imagegif($tmpImage3,$fileName3,100);
					}elseif($fileExt=='png'){
						imagepng($tmpImage1,$fileName1,9);
						imagepng($tmpImage2,$fileName2,9);
						imagepng($tmpImage3,$fileName3,9);
					}
					
					imagedestroy($imageSrc);
					imagedestroy($tmpImage1);
					imagedestroy($tmpImage2);
					imagedestroy($tmpImage3);
					$sysmsg = "Image Uploaded Successfully!";
				}else{
					$_SESSION['error2'] = 1;
					$sysmsg = "Error Processing Image: ".$_FILES["file1"]["name"].".".$fileExt;
				}
			}
		}
	}
	
	//search
	if($_POST['processID']==9){
		$hdrStr = "Location: index.php?p=".$_POST['modID']."&search=".$_POST['searchStr'];
		header($hdrStr);
	}
	
	//update listing
	if($_POST['processID']==10){
		if(isset($_POST['optCash'])){
			$optCashValue = 1;
		}else{
			$optCashValue = 0;
		}
		
		if(isset($_POST['optFinance'])){
			$optFinanceValue = 1;
		}else{
			$optFinanceValue = 0;
		}
		
		if($_POST['agreeDate']==""){
			$agreeDateValue = "0000-00-00";
		}else{
			$agreeDateValue = date('Y-m-d',strtotime($_POST['agreeDate']));
		}
		
		//Update Content Image Asset Record
		$query = "UPDATE zlcom_listing SET agreeDate = '".$agreeDateValue."', statusID = ".$_POST['statusID'].", listTitle = '".$_POST['listTitle']."', listURLStr = '".strtolower($_POST['listURLStr'])."', listCaption = '".$_POST['listCaption']."', listDesc = '".$_POST['listDesc']."', listYouTube = '".$_POST['listYouTube']."', listMetaTitle = '".$_POST['listMetaTitle']."', listMetaKey = '".$_POST['listMetaKey']."', listMetaDesc = '".$_POST['listMetaDesc']."', listBasePrice = ".$_POST['listBasePrice'].", listPrice = ".$_POST['listPrice'].", listPkgPrice = ".$_POST['listPkgPrice'].", isActive = ".$_POST['isActive'].", isFeatured = ".$_POST['isFeatured'].", optCash = ".$optCashValue.", optFinance = ".$optFinanceValue.", modUID = ".$_SESSION['uid'].", modDate = '".date('Y-m-d H:i:s')."' WHERE listID = ".$_POST['listID'];
		mysql_query($query);
		
		$sysmsg = "Listing Updated Successfully!";
	}
	
	//search directory
	if($_POST['processID']==11){
		$hdrStr = "Location: index.php?p=".$_GET['p']."&search=".trim($_POST['searchStr'])."&siteCity=ALL&lotType=ALL&liststat=ALL";
		header($hdrStr);
	}
	
	//Insert News Content
	if($_POST['processID']==12){

		$fieldStr = "pageURL,metaTitle,metaKey,metaDesc,pageHeader,pageContent";
		$valueStr ="'".$_POST['pageURL']."','".$_POST['metaTitle']."','".$_POST['metaKey']."','".$_POST['metaDesc']."','".$_POST['pageHeader']."','".$_POST['pageContent']."'";
		$query = "INSERT INTO zlcom_newscontent (".$fieldStr.") VALUES (".$valueStr.")";
		mysql_query($query);
		
		$contentid = mysql_insert_id();	
			
		$sysmsg = "News Content Added Successfully!";
		
		$hdrStr = "Location: index.php?p=7&edit=1&contentid=".$contentid;
		header($hdrStr);	

	}
	
	//Update News Content
	if($_POST['processID']==13){

		$query = "UPDATE zlcom_newscontent SET pageURL = '".$_POST['pageURL']."', metaTitle = '".$_POST['metaTitle']."', metaKey = '".$_POST['metaKey']."', metaDesc = '".$_POST['metaDesc']."', pageHeader = '".$_POST['pageHeader']."', pageContent = '".$_POST['pageContent']."' WHERE contentID = ".$_POST['contentID'];
		mysql_query($query);
		
		$sysmsg = "News Content Updated Successfully!";

	}
	
	//Insert Page Content
	if($_POST['processID']==14){
		
		$fieldStr = "pageID,pageURL,metaTitle,metaKey,metaDesc,pageHeader,pageContent";
		$valueStr ="'".$_POST['pageID']."','".$_POST['pageURL']."','".$_POST['metaTitle']."','".$_POST['metaKey']."','".$_POST['metaDesc']."','".$_POST['pageHeader']."','".$_POST['pageContent']."'";
		$query = "INSERT INTO zlcom_pagecontent (".$fieldStr.") VALUES (".$valueStr.")";
		mysql_query($query);
		
		$contentid = mysql_insert_id();	
		
		$sysmsg = "Page Content Added Successfully!";
		
		$hdrStr = "Location: index.php?p=8&edit=1&contentid=".$contentid;
		header($hdrStr);	

	}
	
	//Update Page Content
	if($_POST['processID']==15){
		
		$query = "UPDATE zlcom_pagecontent SET pageID = '".$_POST['pageID']."', pageURL = '".$_POST['pageURL']."', metaTitle = '".$_POST['metaTitle']."', metaKey = '".$_POST['metaKey']."', metaDesc = '".$_POST['metaDesc']."', pageHeader = '".$_POST['pageHeader']."', pageContent = '".$_POST['pageContent']."' WHERE contentID = ".$_POST['contentID'];
		mysql_query($query);
		
		$sysmsg = "Page Content Updated Successfully!";

	}
	
	//Update QAQC Sold/List Comp
	if($_POST['processID']==16){
		
		$query = "SELECT * FROM qaqc_soldListComp WHERE validated = 0";
		$result = mysql_query($query);
		$rcount = mysql_num_rows($result);
		$loopCount = 0;
		$validCount = 0;
		if($rcount>0){
			while($row = mysql_fetch_assoc($result)) {
				$qFind = "SELECT * FROM tbl_property WHERE siteAddress = '".$row['siteAddress']."' AND parcelID = '".$row['parcelID']."'";
				$rFind = mysql_query($qFind);
				$rFindCount = mysql_num_rows($rFind);
				if($rFindCount>0){
					$rowFind = mysql_fetch_assoc($rFind);
					$uQry = "UPDATE qaqc_soldListComp SET propertyID = ".$rowFind['propertyID'].", validated = 1 WHERE slcID = ".$row['slcID'];
					mysql_query($uQry);
					$validCount += 1;
				}
				$loopCount += 1;
			}
		}
		$sysmsg = $loopCount." Records processed. ".$validCount." Records validated.";

	}
	
	//Update System Sold/List Comp
	if($_POST['processID']==17){
		
		$query = "SELECT * FROM qaqc_soldListComp WHERE validated = 1";
		$result = mysql_query($query);
		$rcount = mysql_num_rows($result);
		$loopCount = 0;
		$inSoldCount = 0;
		$inListCount = 0;
		$upSoldCount = 0;
		$upListCount = 0;
		if($rcount>0){
			while($row = mysql_fetch_assoc($result)) {
				if($row['soldPrice']>0){
					$qFind = "SELECT * FROM tbl_propSoldComp WHERE propertyID = ".$row['propertyID']." AND soldDate = '".$row['soldDate']."'";
					$rFind = mysql_query($qFind);
					$rFindCount = mysql_num_rows($rFind);
					if($rFindCount==0){
						$iQry = "INSERT INTO tbl_propSoldComp (propertyID,soldDate,soldPrice) VALUES (".$row['propertyID'].",'".$row['soldDate']."',".$row['soldPrice'].")";
						mysql_query($iQry);
						$inSoldCount += 1;
					}else{
						$uQry = "UPDATE tbl_propSoldComp SET soldPrice = ".$row['soldPrice']." WHERE propertyID = ".$row['propertyID']." AND soldDate = '".$row['soldDate']."'";
						mysql_query($uQry);
						$upSoldCount += 1;
					}
				}
				if($row['listPrice']>0){
					$qFind = "SELECT * FROM tbl_propListComp WHERE propertyID = ".$row['propertyID']." AND listDate = '".$row['listDate']."'";
					$rFind = mysql_query($qFind);
					$rFindCount = mysql_num_rows($rFind);
					if($rFindCount==0){
						$iQry = "INSERT INTO tbl_propListComp (propertyID,listDate,listPrice) VALUES (".$row['propertyID'].",'".$row['listDate']."',".$row['listPrice'].")";
						mysql_query($iQry);
						$inListCount += 1;
					}else{
						$uQry = "UPDATE tbl_propListComp SET listPrice = ".$row['listPrice']." WHERE propertyID = ".$row['propertyID']." AND listDate = '".$row['listDate']."'";
						mysql_query($uQry);
						$upListCount += 1;
					}
				}
				$loopCount += 1;
			}
		}
		$sysmsg = $loopCount." Records processed. ".$inSoldCount." Sold Prices Added. ".$upSoldCount." Sold Prices Updated. ".$inListCount." List Prices Added. ".$upSoldCount." List Prices Updated.";

	}
	
	//Update Eval Status
	if($_POST['processID']==18){
		include('zoho/zoho_config.php');
		
		$query = "UPDATE tbl_property SET evalStatus = ".$_POST['evalStatus']." WHERE propertyID = ".$_POST['propertyID'];
		mysql_query($query);
		
		if($_POST['evalStatus']==1){
			$evalStatusStr = "Pending";
		}else{
			$evalStatusStr = "Complete";	
		}
		
		if($_POST['evalStatus']==2){
			//Update Property Evaluation
			$query = "SELECT EV.*, PZM.zh_propertyID FROM tbl_propEval EV INNER JOIN tbl_propZohoMap PZM ON EV.propertyID = PZM.propertyID WHERE EV.propertyID = ".$_POST['propertyID']." ORDER BY EV.evalDate DESC LIMIT 1";
			$result = mysql_query($query);
			$row = mysql_fetch_assoc($result);
			
			$id = $row['zh_propertyID'];
			$zhEvalStatus = $evalStatusStr;
			$zhEvalDate = date("m/d/Y",strtotime($row['evalDate']));
			$zhEvalPriceA = $row['evalPriceA'];
			$zhEvalPriceB = $row['evalPriceB'];
			$zhEvalPriceC = $row['evalPriceC'];
			$zhEvalNotes = $row['evalNotes'];
			
			$my_xml_str = "<?xml version=\"1.0\" encoding=\"UTF-8\" ?><Cases>";
			$my_xml_str = $my_xml_str."<row no=\"1\"><FL val=\"Id\">".$id."</FL><FL val=\"Eval Status\">".$zhEvalStatus."</FL><FL val=\"Eval Date\">".$zhEvalDate."</FL><FL val=\"Eval Price A\">".$zhEvalPriceA."</FL><FL val=\"Eval Price B\">".$zhEvalPriceB."</FL><FL val=\"Eval Price C\">".$zhEvalPriceC."</FL><FL val=\"Eval Notes\">".$zhEvalNotes."</FL><FL val=\"Property Eval\">false</FL></row>";
			$my_xml_str = $my_xml_str."</Cases>";
			
			//set cURL URL variables		
			$xmlDataStr = urlencode($my_xml_str);
			$fieldStr = "newFormat=1&version=4&authtoken=".ZOHO_AUTHTOKEN."&scope=crmapi&xmlData=".$xmlDataStr;
			$urlStr = "https://crm.zoho.com/crm/private/xml/Cases/updateRecords";
			//echo $urlStr."?".$fieldStr;
			
			//open connection
			$ch = curl_init();
			
			//set cURL options
			curl_setopt($ch, CURLOPT_URL, $urlStr);
			curl_setopt($ch, CURLOPT_SSL_CIPHER_LIST, 'rsa_rc4_128_sha'); 
			curl_setopt($ch, CURLOPT_RETURNTRANSFER, TRUE);
			curl_setopt($ch, CURLOPT_POST, TRUE);
			curl_setopt($ch, CURLOPT_POSTFIELDS, $fieldStr);    
			
			//execute cURL post
			$curl_response = curl_exec($ch);
			$error = curl_error($ch);
			if($error){
				throw new Exception('Error in updating records to Zoho CRM');
			}
			
			//close connection
			curl_close($ch);
			
			//Insert Task For Rep
			$query = "SELECT P.*, EV.evalDate FROM tbl_property P INNER JOIN tbl_propEval EV ON P.propertyID = EV.propertyID WHERE P.propertyID = ".$_POST['propertyID']." ORDER BY EV.evalDate DESC LIMIT 1";
			$result = mysql_query($query);
			$row = mysql_fetch_assoc($result);
			
			$ownerid = $row['evalRepID'];
			$ownername = $row['evalRepName'];
			$actionSubject = $row['parcelID']." Property Evaluation Complete!";
			$actionDate = date("m/d/Y");
			$actionSEID = $row['evalActID'];
			$actionSEMODULE = "Accounts";
			$actionStatus = "In Progress";
			$actionPriority = "High";
			$actionNotification = "true";
			$actionDescription = "Property evaluation has been completed on ".$row['parcelID'].": ".$row['siteAddress'].", ".$row['siteCity'].", ".$row['siteState']." ".$row['siteZip'];
			
			$my_xml_str = "<?xml version=\"1.0\" encoding=\"UTF-8\" ?><Tasks>";
			$my_xml_str = $my_xml_str."<row no=\"1\"><FL val=\"SMOWNERID\">".$ownerid."</FL><FL val=\"Task Owner\">".$ownername."</FL><FL val=\"Subject\">".$actionSubject."</FL><FL val=\"Due Date\">".$actionDate."</FL><FL val=\"SEID\">".$actionSEID."</FL><FL val=\"SEMODULE\">".$actionSEMODULE."</FL><FL val=\"Status\">".$actionStatus."</FL><FL val=\"Priority\">".$actionPriority."</FL><FL val=\"Send Notification Email\">".$actionNotification."</FL><FL val=\"Description\">".$actionDescription."</FL></row>";
			$my_xml_str = $my_xml_str."</Tasks>";
			
			//set cURL URL variables		
			$xmlDataStr = urlencode($my_xml_str);
			$fieldStr = "newFormat=1&authtoken=".ZOHO_AUTHTOKEN."&scope=crmapi&xmlData=".$xmlDataStr;
			$urlStr = "https://crm.zoho.com/crm/private/xml/Tasks/insertRecords";
			//echo $urlStr."?".$fieldStr;
			
			//open connection
			$ch = curl_init();
			
			//set cURL options
			curl_setopt($ch, CURLOPT_URL, $urlStr);
			curl_setopt($ch, CURLOPT_SSL_CIPHER_LIST, 'rsa_rc4_128_sha'); 
			curl_setopt($ch, CURLOPT_RETURNTRANSFER, TRUE);
			curl_setopt($ch, CURLOPT_POST, TRUE);
			curl_setopt($ch, CURLOPT_POSTFIELDS, $fieldStr);    
			
			//execute cURL post
			$curl_response = curl_exec($ch);
			$error = curl_error($ch);
			if($error){
				throw new Exception('Error in updating records to Zoho CRM');
			}
			
			//close connection
			curl_close($ch);
			
			$sysmsg = "Property evaluation status has been updated and synced with ZOHO.".$zhEvalDate;
		}

	}
	
	//Sync ZOHO Evals
	if($_POST['processID']==19){
		include('zoho/zoho_config.php');
		
		$searchCondition = "(Property Evaluation|=|true)";
		$selectColumns = "Cases(CASEID,Eval Req Date,Eval Notes,Strap,Verbal Offer,Counter Offer,Modified By,Account Name)";
		$fieldStr = "newFormat=2&authtoken=".ZOHO_AUTHTOKEN."&scope=crmapi&selectColumns=".$selectColumns."&searchCondition=".$searchCondition."&fromIndex=1&toIndex=200";
		$urlStr = "https://crm.zoho.com/crm/private/xml/Cases/getSearchRecords";
		
		//open connection
		$ch = curl_init();
		
		//set cURL options
		curl_setopt($ch, CURLOPT_URL, $urlStr);
		curl_setopt($ch, CURLOPT_SSL_CIPHER_LIST, 'rsa_rc4_128_sha'); 
		curl_setopt($ch, CURLOPT_RETURNTRANSFER, TRUE);
		curl_setopt($ch, CURLOPT_POST, TRUE);
		curl_setopt($ch, CURLOPT_POSTFIELDS, $fieldStr);    
		
		//execute cURL post
		$curl_response = curl_exec($ch);
		$error = curl_error($ch);
		if($error){
			throw new Exception('Error in downloading records to Zoho CRM');
		}
		
		//close connection
		curl_close($ch);
		
		//echo $curl_response;
		/**/
		$xmlString = $curl_response;
		$xml = simplexml_load_string($xmlString);
		$numberOfRecords = count($xml->result->Cases->row);
		$records[][] = array();
		for ($i = 0; $i < $numberOfRecords; $i++) {
			$numberOfValues = count($xml->result->Cases->row[$i]->FL);
			for ($j = 0; $j < $numberOfValues; $j++) {
				switch ((string) $xml->result->Cases->row[$i]->FL[$j]['val']) {
					case 'CASEID':
						$records[$i]['CASEID'] = (string) $xml->result->Cases->row[$i]->FL[$j];
						break;
					case 'Eval Req Date':
						$records[$i]['Eval Req Date'] = (string) $xml->result->Cases->row[$i]->FL[$j];
						break;
					case 'MODIFIEDBY':
						$records[$i]['MODIFIEDBY'] = (string) $xml->result->Cases->row[$i]->FL[$j];
						break;
					case 'Modified By':
						$records[$i]['Modified By'] = (string) $xml->result->Cases->row[$i]->FL[$j];
						break;
					case 'ACCOUNTID':
						$records[$i]['ACCOUNTID'] = (string) $xml->result->Cases->row[$i]->FL[$j];
						break;
					case 'Account Name':
						$records[$i]['Account Name'] = (string) $xml->result->Cases->row[$i]->FL[$j];
						break;
					case 'Eval Notes':
						$records[$i]['Eval Notes'] = (string) $xml->result->Cases->row[$i]->FL[$j];
						break;
					case 'Strap':
						$records[$i]['Strap'] = (string) $xml->result->Cases->row[$i]->FL[$j];
						break;
					case 'Verbal Offer':
						$records[$i]['Verbal Offer'] = (string) $xml->result->Cases->row[$i]->FL[$j];
						break;
					case 'Counter Offer':
						$records[$i]['Counter Offer'] = (string) $xml->result->Cases->row[$i]->FL[$j];
						break;
				}
			}
		}
		
		for ($i = 0; $i < $numberOfRecords; $i++) {
			$parcelID = $records[$i]['Strap'];
			$evalNotes = $records[$i]['Eval Notes'];
			$evalReqDate = $records[$i]['Eval Req Date'];
			$evalRepID = $records[$i]['MODIFIEDBY'];
			$evalRepName = $records[$i]['Modified By'];
			$evalActID = $records[$i]['ACCOUNTID'];
			$evalActName = $records[$i]['Account Name'];
			$verbalOffer = $records[$i]['Verbal Offer'];
			$counterOffer = $records[$i]['Counter Offer'];			
			
			//Find Property
			$query = "SELECT propertyID FROM tbl_property WHERE (evalStatus = 0 OR evalStatus = 2) AND parcelID = '".$parcelID."'";
			$result = mysql_query($query);
			$rcount = mysql_num_rows($result);

			if($rcount>0){
				$row = mysql_fetch_assoc($result);
				$propertyID = $row['propertyID'];
				
				//Update Property
				$uQry = "UPDATE tbl_property SET evalStatus = 1, evalReqDate = '".date("Y-m-d")."', evalRepID = '".$evalRepID."', evalRepName = '".$evalRepName."', evalActID = '".$evalActID."', evalActName = '".$evalActName."', evalNotes = '".$evalNotes."' WHERE propertyID = ".$propertyID;
				mysql_query($uQry);
				
				//Update Verbal Offer
				if($verbalOffer<>""){
					//Check Verbal Offer
					$query = "SELECT * FROM tbl_propVerbalOffer WHERE propertyID = ".$propertyID;
					$result = mysql_query($query);
					$rcount = mysql_num_rows($result);
										
					if($rcount>0){
						$uQry = "UPDATE tbl_propVerbalOffer SET verbalOffer = ".$verbalOffer." WHERE propertyID = ".$propertyID;
						mysql_query($uQry);
					}else{
						$iQry = "INSERT INTO tbl_propVerbalOffer (propertyID,verbalOffer) VALUES (".$propertyID.",".$verbalOffer.")";
						mysql_query($iQry);
					}
				}
				
				
				//Update Counter Offer
				if($counterOffer<>""){
					//Check Verbal Offer
					$query = "SELECT * FROM tbl_propCounterOffer WHERE propertyID = ".$propertyID;
					$result = mysql_query($query);
					$rcountFind2 = mysql_num_rows($result);
					
					if($rcount>0){
						$uQry = "UPDATE tbl_propCounterOffer SET counterOffer = ".$counterOffer." WHERE propertyID = ".$propertyID;
						mysql_query($uQry);
					}else{
						$iQry = "INSERT INTO tbl_propCounterOffer (propertyID,counterOffer) VALUES (".$propertyID.",".$counterOffer.")";
						mysql_query($iQry);
					}
				}
			}
			
		}
		/**/
		
	}
	
	//Update System Sold/List Lat/Lng
	if($_POST['processID']==20){
		
		$query = "SELECT * FROM qaqc_soldListComp WHERE validated = 1";
		$result = mysql_query($query);
		$rcount = mysql_num_rows($result);
		if($rcount>0){
			while($row = mysql_fetch_assoc($result)) {
				$uQry = "UPDATE tbl_property SET lat = ".$row['lat'].", lng = ".$row['lng'].", geocoded = 1 WHERE propertyID = ".$row['propertyID'];
				mysql_query($uQry);
				
				$loopCount++;
			}
		}
		$sysmsg = "Lat/Lng updated for Sold/List Comps.";

	}
	
	//Update Market Value Assessment
	if($_POST['processID']==21){
		
		//Update Assessment Paid:Non-Paid Ratio
		$query = "SELECT * FROM tbl_marketArea";
		$result = mysql_query($query);
		$rcount = mysql_num_rows($result);
		
		$updateStr = "";
		while($row = mysql_fetch_assoc($result)) {
			//Get Water Assessment AVG
			$qAreaAvg = "SELECT P.siteCity, P.siteUnit, AVG(PA.utilitiesWaterBalance) AS avgWaterBalance, COUNT(P.propertyID) AS propCount FROM tbl_property P INNER JOIN tbl_propAttribute PA ON P.propertyID = PA.propertyID WHERE P.siteCity = '".$row['siteCity']."' AND P.siteUnit = '".$row['siteUnit']."' AND PA.utilitiesWaterBalance > 0 GROUP BY P.siteCity, P.siteUnit";
			$rAreaAvg = mysql_query($qAreaAvg);
			$rcAreaAvg = mysql_num_rows($rAreaAvg);
			if($rcAreaAvg>0){
				$rowAreaAvg = mysql_fetch_assoc($rAreaAvg);
				$abWtrAvg = $rowAreaAvg['avgWaterBalance'];
				$abWtrCount = $rowAreaAvg['propCount'];
			}else{
				$abWtrAvg = 0.00;
				$abWtrCount = 0;
			}
			//Get Sewer Assessment AVG
			$qAreaAvg = "SELECT P.siteCity, P.siteUnit, AVG(PA.utilitiesSewerBalance) AS avgSewerBalance, COUNT(P.propertyID) AS propCount FROM tbl_property P INNER JOIN tbl_propAttribute PA ON P.propertyID = PA.propertyID WHERE P.siteCity = '".$row['siteCity']."' AND P.siteUnit = '".$row['siteUnit']."' AND PA.utilitiesSewerBalance > 0 GROUP BY P.siteCity, P.siteUnit";
			$rAreaAvg = mysql_query($qAreaAvg);
			$rcAreaAvg = mysql_num_rows($rAreaAvg);
			if($rcAreaAvg>0){
				$rowAreaAvg = mysql_fetch_assoc($rAreaAvg);
				$abSwrAvg = $rowAreaAvg['avgSewerBalance'];
				$abSwrCount = $rowAreaAvg['propCount'];
			}else{
				$abSwrAvg = 0.00;
				$abSwrCount = 0;
			}
			//Get Irrigation Assessment AVG
			$qAreaAvg = "SELECT P.siteCity, P.siteUnit, AVG(PA.utilitiesIrrigationBalance) AS avgIrrigationBalance, COUNT(P.propertyID) AS propCount FROM tbl_property P INNER JOIN tbl_propAttribute PA ON P.propertyID = PA.propertyID WHERE P.siteCity = '".$row['siteCity']."' AND P.siteUnit = '".$row['siteUnit']."' AND PA.utilitiesIrrigationBalance > 0 GROUP BY P.siteCity, P.siteUnit";
			$rAreaAvg = mysql_query($qAreaAvg);
			$rcAreaAvg = mysql_num_rows($rAreaAvg);
			if($rcAreaAvg>0){
				$rowAreaAvg = mysql_fetch_assoc($rAreaAvg);
				$abIrrAvg = $rowAreaAvg['avgIrrigationBalance'];
				$abIrrCount = $rowAreaAvg['propCount'];
			}else{
				$abIrrAvg = 0.00;
				$abIrrCount = 0;
			}
			//Get Paid Assessment Count
			$qAreaPaid = "SELECT P.siteCity, P.siteUnit, COUNT(P.propertyID) AS propCount FROM tbl_property P INNER JOIN tbl_propAttribute PA ON P.propertyID = PA.propertyID WHERE P.siteCity = '".$row['siteCity']."' AND P.siteUnit = '".$row['siteUnit']."' AND (PA.utilitiesIrrigationBalance = 0 AND PA.utilitiesSewerBalance = 0 AND PA.utilitiesWaterBalance = 0) GROUP BY P.siteCity, P.siteUnit";
			$rAreaPaid = mysql_query($qAreaPaid);
			$rcAreaPaid = mysql_num_rows($rAreaPaid);
			if($rcAreaPaid>0){
				$rowAreaPaid = mysql_fetch_assoc($rAreaPaid);
				$abPaid  = $rowAreaPaid['propCount'];
			}else{
				$abPaid  = 0;
			}
			//Get Non-Paid Assessment Count
			$qAreaNonPaid = "SELECT P.siteCity, P.siteUnit, COUNT(P.propertyID) AS propCount FROM tbl_property P INNER JOIN tbl_propAttribute PA ON P.propertyID = PA.propertyID WHERE P.siteCity = '".$row['siteCity']."' AND P.siteUnit = '".$row['siteUnit']."' AND (PA.utilitiesIrrigationBalance > 0 OR PA.utilitiesSewerBalance > 0 OR PA.utilitiesWaterBalance > 0) GROUP BY P.siteCity, P.siteUnit";
			$rAreaNonPaid = mysql_query($qAreaNonPaid);
			$rcAreaNonPaid = mysql_num_rows($rAreaNonPaid);
			if($rcAreaNonPaid>0){
				$rowAreaNonPaid = mysql_fetch_assoc($rAreaNonPaid);
				$abNonPaid  = $rowAreaNonPaid['propCount'];
			}else{
				$abNonPaid  = 0;
			}
			//Get Property Count
			$qPropCount = "SELECT P.siteCity, P.siteUnit, P.lotTypeID, COUNT(P.propertyID) AS propCount FROM tbl_property P  WHERE P.siteCity = '".$row['siteCity']."' AND P.siteUnit = '".$row['siteUnit']."' AND P.lotTypeID = ".$row['lotTypeID']." GROUP BY P.siteCity, P.siteUnit, P.lotTypeID";
			$rPropCount = mysql_query($qPropCount);
			$rcPropCount = mysql_num_rows($rPropCount);
			if($rcPropCount>0){
				$rowPropCount = mysql_fetch_assoc($rPropCount);
				$propCount  = $rowPropCount['propCount'];
			}else{
				$propCount  = 0;
			}
			
			if($abNonPaid>0){
				$abPaidRatio = ($abPaid/($abNonPaid+$abPaid))*100;
			}else{
				$abPaidRatio = 100;
			}
			$uQry = "UPDATE tbl_marketArea SET propCount = ".$propCount.", abWtrAvg = ".$abWtrAvg.", abWtrCount = ".$abWtrCount.", abSwrAvg = ".$abSwrAvg.", abSwrCount = ".$abSwrCount.", abIrrAvg = ".$abIrrAvg.", abIrrCount = ".$abIrrCount.", abPaidRatio = ".$abPaidRatio." WHERE siteCity = '".$row['siteCity']."' AND siteUnit = '".$row['siteUnit']."'";
			mysql_query($uQry);
			
			$loopCount++;
		}

		$sysmsg = "Market Area Assessment Info Has Been Updated.";

	}
}
?>