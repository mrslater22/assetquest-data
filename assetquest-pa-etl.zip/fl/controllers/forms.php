<?php
function checkReg($email,$pWord) {
	$fmValid = 1;
	if($email == "") {
		$fmValid = 0;
		$error1 = 1;
		$error1msg = "Required Field";
	}
	if($pWord == "") {
		$fmValid = 0;
		$error2 = 1;
		$error2msg = "Required Field";
	}
	return array($fmValid,$error1,$error1msg,$error2,$error2msg);
}

function checkLogin($uname,$pword){
	$fmValid = 1;
	if($uname == "") {
		$fmValid = 0;
		$error1 = 1;
		$error1msg = "Required Field";
	}	
	if($pword == "") {
		$fmValid = 0;
		$error2 = 1;
		$error2msg = "Required Field";
	}
	return array($fmValid,$error1,$error1msg,$error2,$error2msg);
}

function checkProspect($prospectID,$zipCode){
	$fmValid = 1;
	if($prospectID == "") {
		$fmValid = 0;
		$error3 = 1;
		$error3msg = "Required Field";
	}	
	if($zipCode == "") {
		$fmValid = 0;
		$error4 = 1;
		$error4msg = "Required Field";
	}
	return array($fmValid,$error3,$error3msg,$error4,$error4msg);
}

function checkForgot($uname){
	$fmValid = 1;
	if($uname == "") {
		$fmValid = 0;
		$error1 = 1;
		$error1msg = "Required Field";
	}	
	return array($fmValid,$error1,$error1msg);
}

function checkPhone($phone) {
	$fmValid = 1;
	if($phone == "") {
		$fmValid = 0;
		$error1 = 1;
		$error1msg = "Required Field";
	}
	return array($fmValid,$error1,$error1msg);
}
?>