<?php
//Open Database Connection
include("flpoldbopen.php");

//Truncate Master
mysqli_query($con,'TRUNCATE TABLE fl_pol_master;');

//Response Text
echo "Done!";

//Close Database Connection
include("dbclose.php");
?>