<?php
//Open Database Connection
include("flstldbopen.php");

$loopcount = 0;

//Insert Raw County Data
$query = "SELECT * FROM fl_stl_pa WHERE is_processed = 0 LIMIT 1000";
$result = mysqli_query($con,$query);
while($row = mysqli_fetch_assoc($result)) {
	$parcelID = "score_".trim($row['pin']);
	$countyKey = "score_".trim($row['altkey']);
	$strap = "score_".trim($row['pin']);
	$landUseCode = $row['lusedor'];
	$landUseDesc = $row['lusedor_d'];
	$numUnits = 1;
	$frontage = 0;
	$depth = 0;
	$gisAcres = $row['acres_gis'];
	$zoning = $row['zoning'];
	$zoningArea = 'NONE';
	$siteNumber = 'NONE';
	$siteStreet = 'NONE';
	$siteAddress = strtoupper($row['s_address']);
	$siteCity = strtoupper($row['s_city']);
	$siteState = "FLORIDA";
	$siteZip = $row['s_zipcode'];
	$siteCounty = "SAINT LUCIE";
	$siteSubArea = "NONE";
	$siteUnit = "NONE";
	$siteLotType = 'NONE';
	$siteStateCode = "FL";
	$siteCountyCode = "STL";
	$siteCityCode = "NON";
	$siteSubAreaCode = "NON";
	$siteUnitCode = "NON";
	$siteLotTypeCode = "NON";
	$siteUseTypeCode = "NON";
	$siteSizeCode = "000";
	$yearBuilt = $row['yrblt_act'];
	$sfTotal = $row['sqft_tot'];
	$sfUA = $row['sqft_htd'];
	$beds = $row['num_bed'];
	$baths = $row['num_bath'];
	$garage = 0;
	$carport = 0;
	$pool = 0;
	$boatdock = 0;
	$seawall = 0;
	$assessedValue = $row['assd_tot'];
	$recOwnerFullName = $row['o_name1'];
	$recOwnerCO = $row['o_name2'];
	$ownerFullName = $row['o_name1'];
	$ownerCO = $row['o_name2'];
	$ownerAddr1 = $row['o_address1'];
	$ownerAddr2 = $row['o_address2'];
	$ownerCity = $row['o_city'];
	$ownerState = $row['o_state'];
	$ownerZip = $row['o_zipcode'];
	$ownerCountry = $row['o_country'];
	$saleDate = date($row['sale1_date']);
	$saleAmt = $row['sale1_amt'];
	$saleTC = 0;
	
	// Concatinate Leagal Description
	$legalDesc = 'NULL';
	if($row['legal1'] <> 'NULL'){
		if($row['legal2'] <> 'NULL'){
			if($row['legal3'] <> 'NULL'){
				if($row['legal4'] <> 'NULL'){
					if($row['legal5'] <> 'NULL'){
						if($row['legal6'] <> 'NULL'){
							$legalDesc = trim($row['legal1'].' '.$row['legal2'].' '.$row['legal3'].' '.$row['legal4'].' '.$row['legal5'].' '.$row['legal6']);
						}else{
							$legalDesc = trim($row['legal1'].' '.$row['legal2'].' '.$row['legal3'].' '.$row['legal4'].' '.$row['legal5']);
						}
					}else{
						$legalDesc = trim($row['legal1'].' '.$row['legal2'].' '.$row['legal3'].' '.$row['legal4']);
					}
				}else{
					$legalDesc = trim($row['legal1'].' '.$row['legal2'].' '.$row['legal3']);
				}
			}else{
				$legalDesc = trim($row['legal1'].' '.$row['legal2']);
			}
		}else{
			$legalDesc = trim($row['legal1']);
		}
	}
	
	$legalDesc2 = 'NONE';
	$parcelID2 = trim($row['pin']);
	$strap2 = trim($row['pin']);
	$legalDesc30 = substr($legalDesc,0,30);

	$iQuery = "INSERT INTO fl_stl_master (parcelID,countyKey,strap,landUseCode,landUseDesc,numUnits,frontage,depth,gisAcres,zoning,zoningArea,siteNumber,siteStreet,siteAddress,siteCity,siteState,siteZip,siteCounty,siteSubArea,siteUnit,siteLotType,siteStateCode,siteCountyCode,siteCityCode,siteSubAreaCode,siteUnitCode,siteLotTypeCode,siteUseTypeCode,siteSizeCode,yearBuilt,sfTotal,sfUA,beds,baths,garage,carport,pool,boatdock,seawall,assessedValue,recOwnerFullName,recOwnerCO,ownerFullName,ownerCO,ownerAddr1,ownerAddr2,ownerCity,ownerState,ownerZip,ownerCountry,saleDate,saleAmt,legalDesc,legalDesc2,parcelID2,strap2,legalDesc30,saleTC) VALUES ('".$parcelID."','".$countyKey."','".$strap."','".$landUseCode."','".$landUseDesc."',".$numUnits.",".$frontage.",".$depth.",".$gisAcres.",'".$zoning."','".$zoningArea."','".$siteNumber."','".$siteStreet."','".$siteAddress."','".$siteCity."','".$siteState."','".$siteZip."','".$siteCounty."','".$siteSubArea."','".$siteUnit."','".$siteLotType."','".$siteStateCode."','".$siteCountyCode."','".$siteCityCode."','".$siteSubAreaCode."','".$siteUnitCode."','".$siteLotTypeCode."','".$siteUseTypeCode."','".$siteSizeCode."',".$yearBuilt.",".$sfTotal.",".$sfUA.",".$beds.",".$baths.",".$garage.",".$carport.",".$pool.",".$boatdock.",".$seawall.",".$assessedValue.",'".$recOwnerFullName."','".$recOwnerCO."','".$ownerFullName."','".$ownerCO."','".$ownerAddr1."','".$ownerAddr2."','".$ownerCity."','".$ownerState."','".$ownerZip."','".$ownerCountry."','".$saleDate."',".$saleAmt.",'".$legalDesc."','".$legalDesc2."','".$parcelID2."','".$strap2."','".$legalDesc30."','".$saleTC."')";
	$iResult = mysqli_query($con,$iQuery);

	//echo $iQuery;

	$uQuery = "UPDATE fl_stl_pa SET is_processed = 1 WHERE altkey = '".$row['altkey']."'";
	$uResult = mysqli_query($con,$uQuery);

	$loopcount++;
}

//Check Raw County Data Not Processed
$cQuery = "SELECT * FROM fl_stl_pa WHERE is_processed = 0";
$cResult = mysqli_query($con,$cQuery);
$rcount = mysqli_num_rows($cResult);

//Response Text
echo $rcount;

//Close Database Connection
include("dbclose.php");
?>