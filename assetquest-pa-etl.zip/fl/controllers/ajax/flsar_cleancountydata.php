<?php
//Open Database Connection
include("flsardbopen.php");

//Clean Raw County Data
switch($_GET['pid']){
	case 0:	
		//Update TRIM ACCOUNT
		$query = "UPDATE fl_sar_pa SET ACCOUNT = TRIM(ACCOUNT), NAME1 = TRIM(NAME1), NAME_ADD2 = TRIM(NAME_ADD2), NAME_ADD3 = TRIM(NAME_ADD3), NAME_ADD4 = TRIM(NAME_ADD4), NAME_ADD5 = TRIM(NAME_ADD5), CITY = TRIM(CITY), STATE = TRIM(STATE), ZIP = TRIM(ZIP), COUNTRY = TRIM(COUNTRY), LOCN = TRIM(LOCN), LOCS = TRIM(LOCS), LOCD = TRIM(LOCD), UNIT = TRIM(UNIT), LOCCITY = TRIM(LOCCITY), LOCSTATE = TRIM(LOCSTATE), LOCZIP = TRIM(LOCZIP), STCD = TRIM(STCD), NGHB = TRIM(NGHB), SUBD = TRIM(SUBD), TXCD = TRIM(TXCD), DEL_AREA = TRIM(DEL_AREA), SECT = TRIM(SECT), TWSP = TRIM(TWSP), RANG = TRIM(RANG), BLOCK = TRIM(BLOCK), LOT = TRIM(LOT), GULFBAY = TRIM(GULFBAY), ZONING_1 = TRIM(ZONING_1), ZONING_2 = TRIM(ZONING_2), QUAL_CODE = TRIM(QUAL_CODE), LEGALREFER = TRIM(LEGALREFER), BUILD_CLAS = TRIM(BUILD_CLAS), LEGAL1 = TRIM(LEGAL1), LEGAL2 = TRIM(LEGAL2), LEGAL3 = TRIM(LEGAL3), LEGAL4 = TRIM(LEGAL4) WHERE 1";
		$result = mysqli_query($con,$query);
		//Response Text
		echo "<img src='images/ajax_loading.gif' height='20' /> TRIM ACCOUNT";
		break;
	case 1:
		//Update Null NAME1
		$query = "UPDATE fl_sar_pa SET NAME1 = 'NULL' WHERE NAME1 IS NULL OR NAME1 = ''";
		$result = mysqli_query($con,$query);
		//Response Text
		echo "<img src='images/ajax_loading.gif' height='20' /> NAME1 Updated NULL";
		break;
	case 2:
		//Update Null NAME_ADD2
		$query = "UPDATE fl_sar_pa SET NAME_ADD2 = 'NULL' WHERE NAME_ADD2 IS NULL OR NAME_ADD2 = ''";
		$result = mysqli_query($con,$query);
		//Response Text
		echo "<img src='images/ajax_loading.gif' height='20' /> NAME_ADD2 Updated NULL";
		break;
	case 3:
		//Update Null NAME_ADD3
		$query = "UPDATE fl_sar_pa SET NAME_ADD3 = 'NULL' WHERE NAME_ADD3 IS NULL OR NAME_ADD3 = ''";
		$result = mysqli_query($con,$query);
		//Response Text
		echo "<img src='images/ajax_loading.gif' height='20' /> NAME_ADD3 Updated NULL";
		break;
	case 4:
		//Update Null NAME_ADD4
		$query = "UPDATE fl_sar_pa SET NAME_ADD4 = 'NULL' WHERE NAME_ADD4 IS NULL OR NAME_ADD4 = ''";
		$result = mysqli_query($con,$query);
		//Response Text
		echo "<img src='images/ajax_loading.gif' height='20' /> NAME_ADD4 Updated NULL";
		break;
	case 5:
		//Update Null NAME_ADD5
		$query = "UPDATE fl_sar_pa SET NAME_ADD5 = 'NULL' WHERE NAME_ADD5 IS NULL OR NAME_ADD5 = ''";
		$result = mysqli_query($con,$query);
		//Response Text
		echo "<img src='images/ajax_loading.gif' height='20' /> NAME_ADD5 Updated NULL";
		break;
	case 6:
		//Update Null CITY
		$query = "UPDATE fl_sar_pa SET CITY = 'NULL' WHERE CITY IS NULL OR CITY = ''";
		$result = mysqli_query($con,$query);
		//Response Text
		echo "<img src='images/ajax_loading.gif' height='20' /> CITY Updated NULL";
		break;
	case 7:
		//Update Null STATE
		$query = "UPDATE fl_sar_pa SET STATE = 'NULL' WHERE STATE IS NULL OR STATE = ''";
		$result = mysqli_query($con,$query);
		//Response Text
		echo "<img src='images/ajax_loading.gif' height='20' /> STATE Updated NULL";
		break;
	case 8:
		//Update Null ZIP
		$query = "UPDATE fl_sar_pa SET ZIP = 'NULL' WHERE ZIP IS NULL OR ZIP = ''";
		$result = mysqli_query($con,$query);
		//Response Text
		echo "<img src='images/ajax_loading.gif' height='20' /> ZIP Updated NULL";
		break;
	case 9:
		//Update Null COUNTRY
		$query = "UPDATE fl_sar_pa SET COUNTRY = 'NULL' WHERE COUNTRY IS NULL OR COUNTRY = ''";
		$result = mysqli_query($con,$query);
		//Response Text
		echo "<img src='images/ajax_loading.gif' height='20' /> COUNTRY Updated NULL";
		break;
	case 10:
		//Update Null LOCN
		$query = "UPDATE fl_sar_pa SET LOCN = 'NULL' WHERE LOCN IS NULL OR LOCN = ''";
		$result = mysqli_query($con,$query);
		//Response Text
		echo "<img src='images/ajax_loading.gif' height='20' /> LOCN Updated NULL";
		break;
	case 11:
		//Update Null LOCS
		$query = "UPDATE fl_sar_pa SET LOCS = 'NULL' WHERE LOCS IS NULL OR LOCS = ''";
		$result = mysqli_query($con,$query);
		//Response Text
		echo "<img src='images/ajax_loading.gif' height='20' /> LOCS Updated NULL";
		break;
	case 12:
		//Update Null LOCD
		$query = "UPDATE fl_sar_pa SET LOCD = 'NULL' WHERE LOCD IS NULL OR LOCD = ''";
		$result = mysqli_query($con,$query);
		//Response Text
		echo "<img src='images/ajax_loading.gif' height='20' /> ZIP Updated NULL";
		break;
	case 13:
		//Update Null UNIT
		$query = "UPDATE fl_sar_pa SET UNIT = 'NULL' WHERE UNIT IS NULL OR UNIT = ''";
		$result = mysqli_query($con,$query);
		//Response Text
		echo "<img src='images/ajax_loading.gif' height='20' /> UNIT Updated NULL";
		break;
	case 14:
		//Update Null LOCCITY
		$query = "UPDATE fl_sar_pa SET LOCCITY = 'NULL' WHERE LOCCITY IS NULL OR LOCCITY = ''";
		$result = mysqli_query($con,$query);
		//Response Text
		echo "<img src='images/ajax_loading.gif' height='20' /> LOCCITY Updated NULL";
		break;
	case 15:
		//Update Null LOCSTATE
		$query = "UPDATE fl_sar_pa SET LOCSTATE = 'NULL' WHERE LOCSTATE IS NULL OR LOCSTATE = ''";
		$result = mysqli_query($con,$query);
		//Response Text
		echo "<img src='images/ajax_loading.gif' height='20' /> LOCSTATE Updated NULL";
		break;
	case 16:
		//Update Null LOCZIP
		$query = "UPDATE fl_sar_pa SET LOCZIP = 'NULL' WHERE LOCZIP IS NULL OR LOCZIP = ''";
		$result = mysqli_query($con,$query);
		//Response Text
		echo "<img src='images/ajax_loading.gif' height='20' /> LOCZIP Updated NULL";
		break;
	case 17:
		//Update Null STCD
		$query = "UPDATE fl_sar_pa SET STCD = 'NULL' WHERE STCD IS NULL OR STCD = ''";
		$result = mysqli_query($con,$query);
		//Response Text
		echo "<img src='images/ajax_loading.gif' height='20' /> STCD Updated NULL";
		break;
	case 18:
		//Update Null NGHB
		$query = "UPDATE fl_sar_pa SET NGHB = 'NULL' WHERE NGHB IS NULL OR NGHB = ''";
		$result = mysqli_query($con,$query);
		//Response Text
		echo "<img src='images/ajax_loading.gif' height='20' /> NGHB Updated NULL";
		break;
	case 19:
		//Update Null SUBD
		$query = "UPDATE fl_sar_pa SET SUBD = 'NULL' WHERE SUBD IS NULL OR SUBD = ''";
		$result = mysqli_query($con,$query);
		//Response Text
		echo "<img src='images/ajax_loading.gif' height='20' /> SUBD Updated NULL";
		break;
	case 20:
		//Update Null TXCD
		$query = "UPDATE fl_sar_pa SET TXCD = 'NULL' WHERE TXCD IS NULL OR TXCD = ''";
		$result = mysqli_query($con,$query);
		//Response Text
		echo "<img src='images/ajax_loading.gif' height='20' /> TXCD Updated NULL";
		break;
	case 21:
		//Update Null DEL_AREA
		$query = "UPDATE fl_sar_pa SET DEL_AREA = 'NULL' WHERE DEL_AREA IS NULL OR DEL_AREA = ''";
		$result = mysqli_query($con,$query);
		//Response Text
		echo "<img src='images/ajax_loading.gif' height='20' /> DEL_AREA Updated NULL";
		break;
	case 22:
		//Update Null SECT
		$query = "UPDATE fl_sar_pa SET SECT = 'NULL' WHERE SECT IS NULL OR SECT = ''";
		$result = mysqli_query($con,$query);
		//Response Text
		echo "<img src='images/ajax_loading.gif' height='20' /> SECT Updated NULL";
		break;
	case 23:
		//Update Null TWSP
		$query = "UPDATE fl_sar_pa SET TWSP = 'NULL' WHERE TWSP IS NULL OR TWSP = ''";
		$result = mysqli_query($con,$query);
		//Response Text
		echo "<img src='images/ajax_loading.gif' height='20' /> TWSP Updated NULL";
		break;
	case 24:
		//Update Null RANG
		$query = "UPDATE fl_sar_pa SET RANG = 'NULL' WHERE RANG IS NULL OR RANG = ''";
		$result = mysqli_query($con,$query);
		//Response Text
		echo "<img src='images/ajax_loading.gif' height='20' /> RANG Updated NULL";
		break;
	case 25:
		//Update Null BLOCK
		$query = "UPDATE fl_sar_pa SET BLOCK = 'NULL' WHERE BLOCK IS NULL OR BLOCK = ''";
		$result = mysqli_query($con,$query);
		//Response Text
		echo "<img src='images/ajax_loading.gif' height='20' /> BLOCK Updated NULL";
		break;
	case 26:
		//Update Null LOT
		$query = "UPDATE fl_sar_pa SET LOT = 'NULL' WHERE LOT IS NULL OR LOT = ''";
		$result = mysqli_query($con,$query);
		//Response Text
		echo "<img src='images/ajax_loading.gif' height='20' /> LOT Updated NULL";
		break;
	case 27:
		//Update Null GULFBAY
		$query = "UPDATE fl_sar_pa SET GULFBAY = 'NULL' WHERE GULFBAY IS NULL OR GULFBAY = ''";
		$result = mysqli_query($con,$query);
		//Response Text
		echo "<img src='images/ajax_loading.gif' height='20' /> GULFBAY Updated NULL";
		break;
	case 28:	
		//Update Null ZONING_1
		$query = "UPDATE fl_sar_pa SET ZONING_1 = 'NULL' WHERE ZONING_1 IS NULL OR ZONING_1 = ''";
		$result = mysqli_query($con,$query);
		//Response Text
		echo "<img src='images/ajax_loading.gif' height='20' /> ZONING_1 Updated NULL";
		break;
	case 29:	
		//Update Null ZONING_2
		$query = "UPDATE fl_sar_pa SET ZONING_2 = 'NULL' WHERE ZONING_2 IS NULL OR ZONING_2 = ''";
		$result = mysqli_query($con,$query);
		//Response Text
		echo "<img src='images/ajax_loading.gif' height='20' /> ZONING_2 Updated NULL";
		break;
	case 30:	
		//Update Null QUAL_CODE
		$query = "UPDATE fl_sar_pa SET QUAL_CODE = 'NULL' WHERE QUAL_CODE IS NULL OR QUAL_CODE = ''";
		$result = mysqli_query($con,$query);
		//Response Text
		echo "<img src='images/ajax_loading.gif' height='20' /> QUAL_CODE Updated NULL";
		break;
	case 31:	
		//Update Null LEGALREFER
		$query = "UPDATE fl_sar_pa SET LEGALREFER = 'NULL' WHERE LEGALREFER IS NULL OR LEGALREFER = ''";
		$result = mysqli_query($con,$query);
		//Response Text
		echo "<img src='images/ajax_loading.gif' height='20' /> LEGALREFER Updated NULL";
		break;
	case 32:	
		//Update Null BUILD_CLAS
		$query = "UPDATE fl_sar_pa SET BUILD_CLAS = 'NULL' WHERE BUILD_CLAS IS NULL OR BUILD_CLAS = ''";
		$result = mysqli_query($con,$query);
		//Response Text
		echo "<img src='images/ajax_loading.gif' height='20' /> BUILD_CLAS Updated NULL";
		break;
	case 33:	
		//Update Null LEGAL1
		$query = "UPDATE fl_sar_pa SET LEGAL1 = 'NULL' WHERE LEGAL1 IS NULL OR LEGAL1 = ''";
		$result = mysqli_query($con,$query);
		//Response Text
		echo "<img src='images/ajax_loading.gif' height='20' /> LEGAL1 Updated NULL";
		break;
	case 34:	
		//Update Null LEGAL2
		$query = "UPDATE fl_sar_pa SET LEGAL2 = 'NULL' WHERE LEGAL2 IS NULL OR LEGAL2 = ''";
		$result = mysqli_query($con,$query);
		//Response Text
		echo "<img src='images/ajax_loading.gif' height='20' /> LEGAL2 Updated NULL";
		break;
	case 35:	
		//Update Null LEGAL3
		$query = "UPDATE fl_sar_pa SET LEGAL3 = 'NULL' WHERE LEGAL3 IS NULL OR LEGAL3 = ''";
		$result = mysqli_query($con,$query);
		//Response Text
		echo "<img src='images/ajax_loading.gif' height='20' /> LEGAL3 Updated NULL";
		break;
	case 36:	
		//Update Null LEGAL4
		$query = "UPDATE fl_sar_pa SET LEGAL4 = 'NULL' WHERE LEGAL4 IS NULL OR LEGAL4 = ''";
		$result = mysqli_query($con,$query);
		//Response Text
		echo "<img src='images/ajax_loading.gif' height='20' /> LEGAL4 Updated NULL";
		break;
	case 37:	
		//Update 0 POOL
		$query = "UPDATE fl_sar_pa SET POOL = '0' WHERE POOL IS NULL OR POOL = ''";
		$result = mysqli_query($con,$query);
		//Response TextS
		echo "<img src='images/ajax_loading.gif' height='20' /> POOL Updated 0";
		break;
	case 38:	
		//Update 1 POOL
		$query = "UPDATE fl_sar_pa SET POOL = '1' WHERE POOL = 'X'";
		$result = mysqli_query($con,$query);
		//Response Text
		echo "<img src='images/ajax_loading.gif' height='20' /> POOL Updated 1";
		break;
	case 39:
		//Update REPLACE legalDesc quote
		$query = "UPDATE fl_sar_pa SET LEGAL1 = Replace(LEGAL1,'\'',''), LEGAL2 = Replace(LEGAL2,'\'',''), LEGAL3 = Replace(LEGAL3,'\'',''), LEGAL4 = Replace(LEGAL4,'\'','')";
		$result = mysqli_query($con,$query);
		//Response Text
		echo "<img src='images/ajax_loading.gif' height='20' /> 20. ".mysqli_affected_rows($con)." REPLACE LEGAL quote";
		break;
	case 40:
		//Update ownerCountry
		$query = "UPDATE fl_sar_pa JOIN us_states ON fl_sar_pa.STATE = us_states.abv SET fl_sar_pa.COUNTRY = us_states.country WHERE fl_sar_pa.COUNTRY = 'NULL'";
		$result = mysqli_query($con,$query);
		//Response Text
		echo "<img src='images/ajax_loading.gif' height='20' /> 20. ".mysqli_affected_rows($con)." UPDATE COUNTRY";
		break;
	case 41:
		//Update REPLACE OWNER quote
		$query = "UPDATE fl_sar_pa SET NAME1 = Replace(NAME1,'\'',''), NAME_ADD2 = Replace(NAME_ADD2,'\'',''), NAME_ADD3 = Replace(NAME_ADD3,'\'',''), NAME_ADD4 = Replace(NAME_ADD4,'\'',''), NAME_ADD5 = Replace(NAME_ADD5,'\'',''), CITY = Replace(CITY,'\'','')";
		$result = mysqli_query($con,$query);
		//Response Text
		echo "<img src='images/ajax_loading.gif' height='20' /> 20. ".mysqli_affected_rows($con)." REPLACE OWNER quote";
		break;
	case 42:
		//Update remove ' from S_LEGAL
		$query = "UPDATE fl_lee_pa SET S_LEGAL = REPLACE(S_LEGAL, '\'', ' ')";
		$result = mysqli_query($con,$query);
		//Response Text
		echo "<img src='images/ajax_loading.gif' height='20' /> S_LEGAL Updated";
		break;
	default:
		echo "Error Processing...";
}

//Close Database Connection
include("dbclose.php");
?>