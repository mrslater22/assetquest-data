<?php
//ob
ob_start();

//session
session_start();

//Open Database Connection
include("dbopen.php");

//Update Property
$uQry = "UPDATE tbl_property SET evalNotes = '".$_GET['evalNotes']."' WHERE propertyID = ".$_GET['propid'];
mysql_query($uQry);

include("dbclose.php");
?>