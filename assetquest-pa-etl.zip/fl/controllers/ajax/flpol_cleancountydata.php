<?php
//Open Database Connection
include("flpoldbopen.php");

//Clean Raw County Data
switch($_GET['pid']){
	case 0:
		//Update Null subdiv_nm
		$query = "UPDATE fl_pol_pa SET subdiv_nm = 'NULL' WHERE subdiv_nm IS NULL OR subdiv_nm = ''";
		$result = mysqli_query($con,$query);
		//Response Text
		echo "<img src='images/ajax_loading.gif' height='20' /> subdiv_nm Updated to NULL";
		break;
	case 1:
		//Update Null pin
		$query = "UPDATE fl_pol_pa SET pin = 'NULL' WHERE pin IS NULL OR pin = ''";
		$result = mysqli_query($con,$query);
		//Response Text
		echo "<img src='images/ajax_loading.gif' height='20' /> pin Updated to NULL";
		break;
	case 2:
		//Update Null acres_gis
		$query = "UPDATE fl_pol_pa SET acres_gis = 0 WHERE acres_gis IS NULL OR acres_gis = ''";
		$result = mysqli_query($con,$query);
		//Response Text
		echo "<img src='images/ajax_loading.gif' height='20' /> acres_gis Updated to 0";
		break;
	case 3:
		//Update Null o_name1
		$query = "UPDATE fl_pol_pa SET o_name1 = 'NULL' WHERE o_name1 IS NULL OR o_name1 = ''";
		$result = mysqli_query($con,$query);
		//Response Text
		echo "<img src='images/ajax_loading.gif' height='20' /> o_name1 Updated to NULL";
		break;
	case 4:
		//Update Null o_name2
		$query = "UPDATE fl_pol_pa SET o_name2 = 'NULL' WHERE o_name2 IS NULL OR o_name2 = ''";
		$result = mysqli_query($con,$query);
		//Response Text
		echo "<img src='images/ajax_loading.gif' height='20' /> o_name2 Updated to NULL";
		break;
	case 5:
		//Update Null o_name3
		$query = "UPDATE fl_pol_pa SET o_name3 = 'NULL' WHERE o_name3 IS NULL OR o_name3 = ''";
		$result = mysqli_query($con,$query);
		//Response Text
		echo "<img src='images/ajax_loading.gif' height='20' /> o_name3 Updated to NULL";
		break;
	case 6:
		//Update Null o_address1
		$query = "UPDATE fl_pol_pa SET o_address1 = 'NULL' WHERE o_address1 IS NULL OR o_address1 = ''";
		$result = mysqli_query($con,$query);
		//Response Text
		echo "<img src='images/ajax_loading.gif' height='20' /> o_address1 Updated to NULL";
		break;
	case 7:
		//Update Null o_address2
		$query = "UPDATE fl_pol_pa SET o_address2 = 'NULL' WHERE o_address2 IS NULL OR o_address2 = ''";
		$result = mysqli_query($con,$query);
		//Response Text
		echo "<img src='images/ajax_loading.gif' height='20' /> o_address2 Updated to NULL";
		break;
	case 8:
		//Update Null o_address3
		$query = "UPDATE fl_pol_pa SET o_address3 = 'NULL' WHERE o_address3 IS NULL OR o_address3 = ''";
		$result = mysqli_query($con,$query);
		//Response Text
		echo "<img src='images/ajax_loading.gif' height='20' /> o_address3 Updated to NULL";
		break;
	case 9:
		//Update Null o_city
		$query = "UPDATE fl_pol_pa SET o_city = 'NULL' WHERE o_city IS NULL OR o_city = ''";
		$result = mysqli_query($con,$query);
		//Response Text
		echo "<img src='images/ajax_loading.gif' height='20' /> o_city Updated to NULL";
		break;
	case 10:
		//Update Null o_state
		$query = "UPDATE fl_pol_pa SET o_state = 'NULL' WHERE o_state IS NULL OR o_state = ''";
		$result = mysqli_query($con,$query);
		//Response Text
		echo "<img src='images/ajax_loading.gif' height='20' /> o_state Updated to NULL";
		break;
	case 11:
		//Update Null o_zipcode
		$query = "UPDATE fl_pol_pa SET o_zipcode = 'NULL' WHERE o_zipcode IS NULL OR o_zipcode = ''";
		$result = mysqli_query($con,$query);
		//Response Text
		echo "<img src='images/ajax_loading.gif' height='20' /> o_zipcode Updated to NULL";
		break;
	case 12:
		//Update Null o_zipcode4
		$query = "UPDATE fl_pol_pa SET o_zipcode4 = 'NULL' WHERE o_zipcode4 IS NULL OR o_zipcode4 = ''";
		$result = mysqli_query($con,$query);
		//Response Text
		echo "<img src='images/ajax_loading.gif' height='20' /> o_zipcode4 Updated to NULL";
		break;
	case 13:
		//Update Null o_country 
		$query = "UPDATE fl_pol_pa SET o_country = 'NULL' WHERE o_country IS NULL OR o_country = ''";
		$result = mysqli_query($con,$query);
		//Response Text
		echo "<img src='images/ajax_loading.gif' height='20' /> o_country Updated to NULL";
		break;
	case 14:
		//Update Null s_address
		$query = "UPDATE fl_pol_pa SET s_address = 'NULL' WHERE s_address IS NULL OR s_address = ''";
		$result = mysqli_query($con,$query);
		//Response Text
		echo "<img src='images/ajax_loading.gif' height='20' /> s_address Updated to NULL";
		break;
	case 15:
		//Update Null s_city
		$query = "UPDATE fl_pol_pa SET s_city = 'NULL' WHERE s_city IS NULL OR s_city = ''";
		$result = mysqli_query($con,$query);
		//Response Text
		echo "<img src='images/ajax_loading.gif' height='20' /> s_address Updated to NULL";
		break;
	case 16:
		//Update Null s_zipcode
		$query = "UPDATE fl_pol_pa SET s_zipcode = 'NULL' WHERE s_zipcode IS NULL OR s_zipcode = ''";
		$result = mysqli_query($con,$query);
		//Response Text
		echo "<img src='images/ajax_loading.gif' height='20' /> s_zipcode4 Updated to NULL";
		break;
	case 17:
		//Update Null sale1_date
		$query = "UPDATE fl_pol_pa SET sale1_date = '00/00/0000' WHERE sale1_date IS NULL OR sale1_date = ''";
		$result = mysqli_query($con,$query);
		//Response Text
		echo "<img src='images/ajax_loading.gif' height='20' /> sale1_date Updated to 00/00/0000";
		break;
	case 18:
		//Update Null sale1_amt
		$query = "UPDATE fl_pol_pa SET sale1_amt = 0 WHERE sale1_amt IS NULL OR sale1_amt = ''";
		$result = mysqli_query($con,$query);
		//Response Text
		echo "<img src='images/ajax_loading.gif' height='20' /> sale1_amt Updated to 0";
		break;
	case 19:
		//Update Null assd_tot
		$query = "UPDATE fl_pol_pa SET assd_tot = 0 WHERE assd_tot IS NULL OR assd_tot = ''";
		$result = mysqli_query($con,$query);
		//Response Text
		echo "<img src='images/ajax_loading.gif' height='20' /> assd_tot Updated to 0";
		break;
	case 20:
		//Update Null sqft_htd
		$query = "UPDATE fl_pol_pa SET sqft_htd = 0 WHERE sqft_htd IS NULL OR sqft_htd = ''";
		$result = mysqli_query($con,$query);
		//Response Text
		echo "<img src='images/ajax_loading.gif' height='20' /> sqft_htd Updated to 0";
		break;
	case 21:
		//Update Null sqft_tot
		$query = "UPDATE fl_pol_pa SET sqft_tot = 0 WHERE sqft_tot IS NULL OR sqft_tot = ''";
		$result = mysqli_query($con,$query);
		//Response Text
		echo "<img src='images/ajax_loading.gif' height='20' /> sqft_tot Updated to 0";
		break;
	case 22:
		//Update Null yrblt_act
		$query = "UPDATE fl_pol_pa SET yrblt_act = 0 WHERE yrblt_act IS NULL OR yrblt_act = ''";
		$result = mysqli_query($con,$query);
		//Response Text
		echo "<img src='images/ajax_loading.gif' height='20' /> yrblt_act Updated to 0";
		break;
	case 23:
		//Update Null num_bed
		$query = "UPDATE fl_pol_pa SET num_bed = 0 WHERE num_bed IS NULL OR num_bed = ''";
		$result = mysqli_query($con,$query);
		//Response Text
		echo "<img src='images/ajax_loading.gif' height='20' /> num_bed Updated to 0";
		break;
	case 24:
		//Update Null num_bath
		$query = "UPDATE fl_pol_pa SET num_bath = 0 WHERE num_bath IS NULL OR num_bath = ''";
		$result = mysqli_query($con,$query);
		//Response Text
		echo "<img src='images/ajax_loading.gif' height='20' /> num_bath Updated to 0";
		break;
	case 25:
		//Update Null lusedor
		$query = "UPDATE fl_pol_pa SET lusedor = 'NULL' WHERE lusedor IS NULL OR lusedor = ''";
		$result = mysqli_query($con,$query);
		//Response Text
		echo "<img src='images/ajax_loading.gif' height='20' /> lusedor Updated to NULL";
		break;
	case 26:
		//Update Null lusedor_d
		$query = "UPDATE fl_pol_pa SET lusedor_d = 'NULL' WHERE lusedor_d IS NULL OR lusedor_d = ''";
		$result = mysqli_query($con,$query);
		//Response Text
		echo "<img src='images/ajax_loading.gif' height='20' /> lusedor_d Updated to NULL";
		break;
	case 27:
		//Update Null zoning
		$query = "UPDATE fl_pol_pa SET zoning = 'NULL' WHERE zoning IS NULL OR zoning = ''";
		$result = mysqli_query($con,$query);
		//Response Text
		echo "<img src='images/ajax_loading.gif' height='20' /> zoning Updated to NULL";
		break;
	case 28:
		//Update Null legal1
		$query = "UPDATE fl_pol_pa SET legal1 = 'NULL' WHERE legal1 IS NULL OR legal1 = ''";
		$result = mysqli_query($con,$query);
		//Response Text
		echo "<img src='images/ajax_loading.gif' height='20' /> legal1 Updated to NULL";
		break;
	case 29:
		//Update Null legal2
		$query = "UPDATE fl_pol_pa SET legal2 = 'NULL' WHERE legal2 IS NULL OR legal2 = ''";
		$result = mysqli_query($con,$query);
		//Response Text
		echo "<img src='images/ajax_loading.gif' height='20' /> legal2 Updated to NULL";
		break;
	case 30:
		//Update Null legal3
		$query = "UPDATE fl_pol_pa SET legal3 = 'NULL' WHERE legal3 IS NULL OR legal3 = ''";
		$result = mysqli_query($con,$query);
		//Response Text
		echo "<img src='images/ajax_loading.gif' height='20' /> legal3 Updated to NULL";
		break;
	case 31:
		//Update Null legal4
		$query = "UPDATE fl_pol_pa SET legal4 = 'NULL' WHERE legal4 IS NULL OR legal4 = ''";
		$result = mysqli_query($con,$query);
		//Response Text
		echo "<img src='images/ajax_loading.gif' height='20' /> legal4 Updated to NULL";
		break;
	case 32:
		//Update Null legal5
		$query = "UPDATE fl_pol_pa SET legal5 = 'NULL' WHERE legal5 IS NULL OR legal5 = ''";
		$result = mysqli_query($con,$query);
		//Response Text
		echo "<img src='images/ajax_loading.gif' height='20' /> legal5 Updated to NULL";
		break;
	case 33:
		//Update Null legal6
		$query = "UPDATE fl_pol_pa SET legal6 = 'NULL' WHERE legal6 IS NULL OR legal6 = ''";
		$result = mysqli_query($con,$query);
		//Response Text
		echo "<img src='images/ajax_loading.gif' height='20' /> legal6 Updated to NULL";
		break;
	case 34:
		//Update remove ' from legal1, legal2, legal3, legal4, legal5, legal6
		$query = "UPDATE fl_pol_pa SET legal1 = REPLACE(legal1, '\'', ' '), legal2 = REPLACE(legal2, '\'', ' '), legal3 = REPLACE(legal3, '\'', ' '), legal4 = REPLACE(legal4, '\'', ' '), legal5 = REPLACE(legal5, '\'', ' '), legal6 = REPLACE(legal6, '\'', ' ')";
		$result = mysqli_query($con,$query);
		//Response Text
		echo "<img src='images/ajax_loading.gif' height='20' /> legal1, legal2, legal3, legal4, legal5, legal6 Updated";
		break;
	case 35:
		//Update remove ' from o_name1, o_name2, o_name3, o_address1, o_address2, o_address3, o_city, o_country
		$query = "UPDATE fl_pol_pa SET o_name1 = REPLACE(o_name1, '\'', ' '), o_name2 = REPLACE(o_name2, '\'', ' '), o_name3 = REPLACE(o_name3, '\'', ' '), o_address1 = REPLACE(o_address1, '\'', ' '), o_address2 = REPLACE(o_address2, '\'', ' '), o_address3 = REPLACE(o_address3, '\'', ' '), o_city = REPLACE(o_city, '\'', ' '), O_COUNTRY = REPLACE(O_COUNTRY, '\'', ' ')";
		$result = mysqli_query($con,$query);
		//Response Text
		echo "<img src='images/ajax_loading.gif' height='20' /> o_name1, o_name2, o_name3, o_address1, o_address2, o_address3, o_city, o_country Updated";
		break;
	default:
		echo "Error Processing...";
}

//Close Database Connection
include("dbclose.php");
?>