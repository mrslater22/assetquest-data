<?php
//Open Database Connection
include("flcoldbopen.php");

$loopcount = 0;
$avYear = 2017;

//Insert Raw County Data
$query = "SELECT * FROM fl_col_master WHERE siteCityCode = '".$_GET['cd']."' AND is_processed = 0 LIMIT 1000";
$result = mysqli_query($con,$query);
while($row = mysqli_fetch_assoc($result)) {
	$iQuery = "INSERT INTO fl_col_import(parcelID,countyKey,strap,landUseCode,landUseDesc,numUnits,frontage,depth,gisAcres,zoning,zoningArea,siteNumber,siteStreet,siteAddress,siteCity,siteState,siteZip,siteCounty,siteSubArea,siteUnit,siteLotType,siteStateCode,siteCountyCode,siteCityCode,siteSubAreaCode,siteUnitCode,siteLotTypeCode,siteUseTypeCode,siteSizeCode,yearBuilt,sfTotal,sfUA,beds,baths,garage,carport,pool,boatdock,seawall,assessedValue,avYear,recOwnerFullName,recOwnerCO,ownerFullName,ownerCO,ownerAddr1,ownerAddr2,ownerCity,ownerState,ownerZip,ownerCountry,saleDate,saleAmt,legalDesc,parcelID2,strap2,saleTC) VALUES ('".$row['parcelID']."','".$row['countyKey']."','".$row['strap']."','".$row['landUseCode']."','".$row['landUseDesc']."',".$row['numUnits'].",".$row['frontage'].",".$row['depth'].",".$row['gisAcres'].",'".$row['zoning']."','".$row['zoningArea']."','".$row['siteNumber']."','".$row['siteStreet']."','".$row['siteAddress']."','".$row['siteCity']."','".$row['siteState']."','".$row['siteZip']."','".$row['siteCounty']."','".$row['siteSubArea']."','".$row['siteUnit']."','".$row['siteLotType']."','".$row['siteStateCode']."','".$row['siteCountyCode']."','".$row['siteCityCode']."','".$row['siteSubAreaCode']."','".$row['siteUnitCode']."','".$row['siteLotTypeCode']."','".$row['siteUseTypeCode']."','".$row['siteSizeCode']."',".$row['yearBuilt'].",".$row['sfTotal'].",".$row['sfUA'].",".$row['beds'].",".$row['baths'].",".$row['garage'].",".$row['carport'].",".$row['pool'].",".$row['boatdock'].",".$row['seawall'].",".$row['assessedValue'].",".$avYear.",'".$row['recOwnerFullName']."','".$row['recOwnerCO']."','".$row['ownerFullName']."','".$row['ownerCO']."','".$row['ownerAddr1']."','".$row['ownerAddr2']."','".$row['ownerCity']."','".$row['ownerState']."','".$row['ownerZip']."','".$row['ownerCountry']."','".$row['saleDate']."',".$row['saleAmt'].",'".$row['legalDesc']."','".$row['parcelID2']."','".$row['strap2']."','".$row['saleTC']."')";
	$iResult = mysqli_query($con,$iQuery);
	
	$uQuery = "UPDATE fl_col_master SET is_processed = 1 WHERE id = ".$row['id'];
	$uResult = mysqli_query($con,$uQuery);
	
	$loopcount++;
}

//Check Master Data Not Processed
$cQuery = "SELECT * FROM fl_col_master WHERE siteCityCode = '".$_GET['cd']."' AND is_processed = 0";
$cResult = mysqli_query($con,$cQuery);
$rcount = mysqli_num_rows($cResult);

//Response Text
echo $rcount;

//Close Database Connection
include("dbclose.php"); 
?>