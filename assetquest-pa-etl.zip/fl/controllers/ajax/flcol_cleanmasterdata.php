<?php
//Open Database Connection
include("flcoldbopen.php");

//Clean Master Data
switch($_GET['pid']){
	case 0:	
		//Update ownerCountry
		$query = "UPDATE fl_col_master INNER JOIN us_states ON fl_col_master.ownerState = us_states.abv SET fl_col_master.ownerCountry = UCase(us_states.country)";
		$result = mysqli_query($con,$query);
		//Response Text
		echo "<img src='images/ajax_loading.gif' height='20' /> 0. ".mysqli_affected_rows($con)." ownerCountry UPDATED";
		break;
	case 1:
		//Update REPLACE &
		$query = "UPDATE fl_col_master SET recOwnerFullName = Replace(recOwnerFullName,'&','+'), recOwnerCO = Replace(recOwnerCO,'&','+'), ownerFullName = Replace(ownerFullName,'&','+'), ownerCO = Replace(ownerCO,'&','+'), ownerAddr1 = Replace(ownerAddr1,'&','+')";
		$result = mysqli_query($con,$query);
		//Response Text
		echo "<img src='images/ajax_loading.gif' height='20' /> 1. ".mysqli_affected_rows($con)." REPLACE '&'";
		break;
	case 2:
		//Update REPLACE quote
		$query = "UPDATE fl_col_master SET recOwnerFullName = Replace(recOwnerFullName,'\'',''), recOwnerCO = Replace(recOwnerCO,'\'',''), ownerFullName = Replace(ownerFullName,'\'',''), ownerCO = Replace(ownerCO,'\'',''), ownerAddr1 = Replace(ownerAddr1,'\'','')";
		$result = mysqli_query($con,$query);
		//Response Text
		echo "<img src='images/ajax_loading.gif' height='20' /> 2. ".mysqli_affected_rows($con)." REPLACE quote";
		break;
	case 3:
		//Update US 5 Char Zip
		$query = "UPDATE fl_col_master SET ownerZip = substring(ownerZip,1,5) WHERE ownerCountry = 'UNITED STATES'";
		$result = mysqli_query($con,$query);
		//Response Text
		echo "<img src='images/ajax_loading.gif' height='20' /> 3. ".mysqli_affected_rows($con)." REPLACE US 5 char zip";
		break;
	case 4:
		//Update siteCity
		$query = "UPDATE fl_col_master LEFT JOIN fl_col_city_cd ON (fl_col_master.legalDesc2 = fl_col_city_cd.city_cd) SET fl_col_master.siteCity = fl_col_city_cd.siteCity";
		$result = mysqli_query($con,$query);
		//Response Text
		echo "<img src='images/ajax_loading.gif' height='20' /> 4. ".mysqli_affected_rows($con)." siteCity UPDATED";
		break;
	case 5:
		//Update siteCity Null
		$query = "UPDATE fl_col_master SET siteCity = 'NULL' WHERE siteCity IS NULL OR siteCity = ''";
		$result = mysqli_query($con,$query);
		//Response Text
		echo "<img src='images/ajax_loading.gif' height='20' /> 4. ".mysqli_affected_rows($con)." siteCity NULL UPDATED";
		break;	
	case 6:
		//Update siteSubAreaCode
		$query = "UPDATE fl_col_master LEFT JOIN subarea_codes ON (fl_col_master.siteState = subarea_codes.siteState) AND (fl_col_master.siteCounty = subarea_codes.siteCounty) AND (fl_col_master.siteSubArea = subarea_codes.siteSubArea) SET fl_col_master.siteSubAreaCode = subarea_codes.siteSubAreaCode WHERE fl_col_master.siteSubArea <> 'NONE'";
		$result = mysqli_query($con,$query);
		//Response Text
		echo "<img src='images/ajax_loading.gif' height='20' /> 5. ".mysqli_affected_rows($con)." siteSubAreaCode UPDATED";
		break;
	case 7:
		//Update siteCityCode
		$query = "UPDATE fl_col_master LEFT JOIN city_codes ON (fl_col_master.siteState = city_codes.siteState) AND (fl_col_master.siteCounty = city_codes.siteCounty) AND (fl_col_master.siteCity = city_codes.siteCity) SET fl_col_master.siteCityCode = city_codes.siteCityCode";
		$result = mysqli_query($con,$query);
		//Response Text
		echo "<img src='images/ajax_loading.gif' height='20' /> 6. ".mysqli_affected_rows($con)." siteCityCode UPDATED";
		break;
	case 8:
		//Update siteUnit Null
		$query = "UPDATE fl_col_master SET siteUnit = 'NULL' WHERE siteUnit IS NULL OR siteUnit = ''";
		$result = mysqli_query($con,$query);
		//Response Text
		echo "<img src='images/ajax_loading.gif' height='20' /> 4. ".mysqli_affected_rows($con)." siteUnit NULL UPDATED";
		break;
	case 9:
		//Update siteUnitCodes
		$query = "UPDATE fl_col_master INNER JOIN unit_codes ON (fl_col_master.siteState = unit_codes.siteState) AND (fl_col_master.siteCounty = unit_codes.siteCounty) AND (fl_col_master.siteCity = unit_codes.siteCity) AND (fl_col_master.siteUnit = unit_codes.siteUnit) SET fl_col_master.siteUnitCode = unit_codes.siteUnitCode";
		$result = mysqli_query($con,$query);
		//Response Text
		echo "<img src='images/ajax_loading.gif' height='20' /> 5. ".mysqli_affected_rows($con)." UNIT CODES UPDATED";
		break;
	case 10:
		//Update siteUseTypeCodes
		$query = "UPDATE fl_col_master INNER JOIN use_type_codes ON fl_col_master.landUseCode = use_type_codes.landUseTypeCode SET fl_col_master.siteUseType = use_type_codes.siteUseType, fl_col_master.siteUseTypeCode = use_type_codes.siteUseTypeCode, fl_col_master.landUseDesc = use_type_codes.landUseTypeDesc";
		$result = mysqli_query($con,$query);
		//Response Text
		echo "<img src='images/ajax_loading.gif' height='20' /> 6. ".mysqli_affected_rows($con)." USE TYPES + USE TYPE CODES UPDATED";
		break;
	case 11:
		//Update REPLACE %
		$query = "UPDATE fl_col_master SET recOwnerFullName = trim(Replace(recOwnerFullName,'\%','')), recOwnerCO = trim(Replace(recOwnerCO,'\%','')), ownerFullName = trim(Replace(ownerFullName,'\%','')), ownerCO = trim(Replace(ownerCO,'\%','')), ownerAddr1 = trim(Replace(ownerAddr1,'\%',''))";
		$result = mysqli_query($con,$query);
		//Response Text
		echo "<img src='images/ajax_loading.gif' height='20' /> 2. ".mysqli_affected_rows($con)." REPLACE %";
		break;
	default:
		echo "Error Processing...";
}

//Close Database Connection
include("dbclose.php");
?>