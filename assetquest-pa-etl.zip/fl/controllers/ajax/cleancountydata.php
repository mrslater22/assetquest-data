<?php
//Open Database Connection
include("dbopen.php");

//Clean Raw County Data
switch($_GET['pid']){
	case 0:	
		//Update Null ZONING
		$query = "UPDATE fl_lee_pa SET ZONING = '0' WHERE ZONING IS NULL OR ZONING = ''";
		$result = mysql_query($query);
		//Response Text
		echo "<img src='images/ajax_loading.gif' height='20' /> ZONING Updated NULL";
		break;
	case 1:
		//Update Null LANDUSEDES
		$query = "UPDATE fl_lee_pa SET LANDUSEDES = 'NULL' WHERE LANDUSEDES IS NULL OR LANDUSEDES = ''";
		$result = mysql_query($query);
		//Response Text
		echo "<img src='images/ajax_loading.gif' height='20' /> LANDUSEDES Updated NULL";
		break;
	case 2:
		//Update Null LANDISON
		$query = "UPDATE fl_lee_pa SET LANDISON = 'NULL' WHERE LANDISON IS NULL OR LANDISON = ''";
		$result = mysql_query($query);
		//Response Text
		echo "<img src='images/ajax_loading.gif' height='20' /> LANDISON Updated NULL";
		break;
	case 3:
		//Update Null SITEADDR
		$query = "UPDATE fl_lee_pa SET SITEADDR = 'NULL' WHERE SITEADDR IS NULL OR SITEADDR = ''";
		$result = mysql_query($query);
		//Response Text
		echo "<img src='images/ajax_loading.gif' height='20' /> SITEADDR Updated NULL";
		break;
	case 4:
		//Update Null SITENUMBER
		$query = "UPDATE fl_lee_pa SET SITENUMBER = 'NULL' WHERE SITENUMBER IS NULL OR SITENUMBER = ''";
		$result = mysql_query($query);
		//Response Text
		echo "<img src='images/ajax_loading.gif' height='20' /> SITENUMBER Updated NULL";
		break;
	case 5:
		//Update Null SITESTREET
		$query = "UPDATE fl_lee_pa SET SITESTREET = 'NULL' WHERE SITESTREET IS NULL OR SITESTREET = ''";
		$result = mysql_query($query);
		//Response Text
		echo "<img src='images/ajax_loading.gif' height='20' /> SITESTREET Updated NULL";
		break;
	case 6:
		//Update Null SITECITY
		$query = "UPDATE fl_lee_pa SET SITECITY = 'NULL' WHERE SITECITY IS NULL OR SITECITY = ''";
		$result = mysql_query($query);
		//Response Text
		echo "<img src='images/ajax_loading.gif' height='20' /> SITECITY Updated NULL";
		break;
	case 7:
		//Update Null SITEZIP
		$query = "UPDATE fl_lee_pa SET SITEZIP = 'NULL' WHERE SITEZIP IS NULL OR SITEZIP = ''";
		$result = mysql_query($query);
		//Response Text
		echo "<img src='images/ajax_loading.gif' height='20' /> SITEZIP Updated NULL";
		break;
	case 8:
		//Update Null GARAGE
		$query = "UPDATE fl_lee_pa SET GARAGE = 1 WHERE GARAGE = 'Y'";
		$result = mysql_query($query);
		//Response Text
		echo "<img src='images/ajax_loading.gif' height='20' /> GARAGE Updated 1";
		break;
	case 9:
		//Update Null GARAGE
		$query = "UPDATE fl_lee_pa SET GARAGE = 0 WHERE GARAGE IS NULL OR GARAGE = ''";
		$result = mysql_query($query);
		//Response Text
		echo "<img src='images/ajax_loading.gif' height='20' /> GARAGE Updated 0";
		break;
	case 10:
		//Update Null CARPORT
		$query = "UPDATE fl_lee_pa SET CARPORT = 1 WHERE CARPORT = 'Y'";
		$result = mysql_query($query);
		//Response Text
		echo "<img src='images/ajax_loading.gif' height='20' /> CARPORT Updated 1";
		break;
	case 11:
		//Update Null CARPORT
		$query = "UPDATE fl_lee_pa SET CARPORT = 0 WHERE CARPORT IS NULL OR CARPORT = ''";
		$result = mysql_query($query);
		//Response Text
		echo "<img src='images/ajax_loading.gif' height='20' /> CARPORT Updated 0";
		break;
	case 12:
		//Update Null POOL
		$query = "UPDATE fl_lee_pa SET POOL = 1 WHERE POOL = 'Y'";
		$result = mysql_query($query);
		//Response Text
		echo "<img src='images/ajax_loading.gif' height='20' /> POOL Updated 1";
		break;
	case 13:
		//Update Null POOL
		$query = "UPDATE fl_lee_pa SET POOL = 0 WHERE POOL IS NULL OR POOL = ''";
		$result = mysql_query($query);
		//Response Text
		echo "<img src='images/ajax_loading.gif' height='20' /> POOL Updated 0";
		break;
	case 14:
		//Update Null BOATDOCK
		$query = "UPDATE fl_lee_pa SET BOATDOCK = 1 WHERE BOATDOCK = 'Y'";
		$result = mysql_query($query);
		//Response Text
		echo "<img src='images/ajax_loading.gif' height='20' /> BOATDOCK Updated 1";
		break;
	case 15:
		//Update Null BOATDOCK
		$query = "UPDATE fl_lee_pa SET BOATDOCK = 0 WHERE BOATDOCK IS NULL OR BOATDOCK = ''";
		$result = mysql_query($query);
		//Response Text
		echo "<img src='images/ajax_loading.gif' height='20' /> BOATDOCK Updated 0";
		break;
	case 16:
		//Update Null SEAWALL
		$query = "UPDATE fl_lee_pa SET SEAWALL = 1 WHERE SEAWALL = 'Y'";
		$result = mysql_query($query);
		//Response Text
		echo "<img src='images/ajax_loading.gif' height='20' /> SEAWALL Updated 1";
		break;
	case 17:
		//Update Null SEAWALL
		$query = "UPDATE fl_lee_pa SET SEAWALL = 0 WHERE SEAWALL IS NULL OR SEAWALL = ''";
		$result = mysql_query($query);
		//Response Text
		echo "<img src='images/ajax_loading.gif' height='20' /> SEAWALL Updated 0";
		break;
	case 18:
		//Update Null O_OTHERS
		$query = "UPDATE fl_lee_pa SET O_OTHERS = 'NULL' WHERE O_OTHERS IS NULL OR O_OTHERS = ''";
		$result = mysql_query($query);
		//Response Text
		echo "<img src='images/ajax_loading.gif' height='20' /> O_OTHERS Updated NULL";
		break;
	case 19:
		//Update Null O_CAREOF
		$query = "UPDATE fl_lee_pa SET O_CAREOF = 'NULL' WHERE O_CAREOF IS NULL OR O_CAREOF = ''";
		$result = mysql_query($query);
		//Response Text
		echo "<img src='images/ajax_loading.gif' height='20' /> O_CAREOF Updated NULL";
		break;
	case 20:
		//Update Null O_ADDR1
		$query = "UPDATE fl_lee_pa SET O_ADDR1 = 'NULL' WHERE O_ADDR1 IS NULL OR O_ADDR1 = ''";
		$result = mysql_query($query);
		//Response Text
		echo "<img src='images/ajax_loading.gif' height='20' /> O_ADDR1 Updated NULL";
		break;
	case 21:
		//Update Null O_ADDR2
		$query = "UPDATE fl_lee_pa SET O_ADDR2 = 'NULL' WHERE O_ADDR1 IS NULL OR O_ADDR2 = ''";
		$result = mysql_query($query);
		//Response Text
		echo "<img src='images/ajax_loading.gif' height='20' /> O_ADDR2 Updated NULL";
		break;
	case 22:
		//Update Null O_CITY
		$query = "UPDATE fl_lee_pa SET O_CITY = 'NULL' WHERE O_CITY IS NULL OR O_CITY = ''";
		$result = mysql_query($query);
		//Response Text
		echo "<img src='images/ajax_loading.gif' height='20' /> O_CITY Updated NULL";
		break;
	case 23:
		//Update Null O_STATE
		$query = "UPDATE fl_lee_pa SET O_STATE = 'NULL' WHERE O_STATE IS NULL OR O_STATE = ''";
		$result = mysql_query($query);
		//Response Text
		echo "<img src='images/ajax_loading.gif' height='20' /> O_STATE Updated NULL";
		break;
	case 24:
		//Update Null O_ZIP
		$query = "UPDATE fl_lee_pa SET O_ZIP = 'NULL' WHERE O_ZIP IS NULL OR O_ZIP = ''";
		$result = mysql_query($query);
		//Response Text
		echo "<img src='images/ajax_loading.gif' height='20' /> O_ZIP Updated NULL";
		break;
	case 25:
		//Update Null O_COUNTRY
		$query = "UPDATE fl_lee_pa SET O_COUNTRY = 'UNITED STATES' WHERE O_COUNTRY IS NULL OR O_COUNTRY = ''";
		$result = mysql_query($query);
		//Response Text
		echo "<img src='images/ajax_loading.gif' height='20' /> O_COUNTRY Updated NULL";
		break;
	default:
		echo "Error Processing...";
}

//Close Database Connection
include("dbclose.php");
?>