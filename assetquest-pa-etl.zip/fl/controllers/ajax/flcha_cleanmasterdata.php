<?php
//Open Database Connection
include("flchadbopen.php");

//Clean Master Data
switch($_GET['pid']){
	case 0:	
		//Update siteCity
		$query = "UPDATE fl_cha_master JOIN fl_cha_zip_city_state ON fl_cha_master.siteZip = fl_cha_zip_city_state.zipCode SET fl_cha_master.siteCity = fl_cha_zip_city_state.siteCity";
		$result = mysqli_query($con,$query);
		//Response Text
		echo "<img src='images/ajax_loading.gif' height='20' /> 0. ".mysqli_affected_rows($con)." RECORDS UPDATED siteCity";
		break;
	case 1:
		//Update siteSubArea + siteUnit + siteUnitCode
		$query = "UPDATE fl_cha_master JOIN fl_cha_unit_subarea ON fl_cha_master.legalDesc2 = fl_cha_unit_subarea.legalDesc2 SET fl_cha_master.siteSubArea = fl_cha_unit_subarea.siteSubArea, fl_cha_master.siteUnit = fl_cha_unit_subarea.siteUnit, fl_cha_master.siteUnitCode = fl_cha_unit_subarea.siteUnit";
		$result = mysqli_query($con,$query);
		//Response Text
		echo "<img src='images/ajax_loading.gif' height='20' /> 1. ".mysqli_affected_rows($con)." RECORDS UPDATED siteSubArea + siteUnit + siteUnitCode";
		break;
	case 2:
		//Update siteLotType SALT (assessedValue > $10,000)
		$query = "UPDATE fl_cha_master SET siteLotType = 'SALT' WHERE landUseCode = '0000' AND siteLotType = 'FRESHWATER' AND assessedValue > 10000";
		$result = mysqli_query($con,$query);
		//Response Text
		echo "<img src='images/ajax_loading.gif' height='20' /> 2. ".mysqli_affected_rows($con)." RECORDS UPDATED SALT";
		break;
	case 3:
		//Update Remove legalDesc double spaces
		$ds = 1;
		while($ds > 0) {
			$query = "UPDATE fl_cha_master SET legalDesc = REPLACE(legalDesc,'  ',' ') WHERE INSTR(legalDesc,'  ') > 0";
			$result = mysqli_query($con,$query);
			/*
			$cQurey = "SELECT fl_cha_master WHERE INSTR(legalDesc,'  ') > 0";
			$cResult = mysqli_query($con,$cQuery);
			$ds = mysql_num_rows($cResult);
			*/
		}
		//Response Text
		echo "<img src='images/ajax_loading.gif' height='20' /> 3. legalDesc DOUBLE SPACES REMOVED";
		break;
	case 4:
		//Update siteSubAreaCode
		$query = "UPDATE fl_cha_master JOIN subarea_codes ON fl_cha_master.siteSubArea = subarea_codes.siteSubArea SET fl_cha_master.siteSubAreaCode = subarea_codes.siteSubAreaCode";
		$result = mysqli_query($con,$query);
		//Response Text
		echo "<img src='images/ajax_loading.gif' height='20' /> 4. ".mysqli_affected_rows($con)." siteSubAreaCode RECORDS UPDATED";
		break;
	case 5:
		//Update siteCityCode
		$query = "UPDATE fl_cha_master JOIN city_codes ON fl_cha_master.siteCity = city_codes.siteCity SET fl_cha_master.siteCityCode = city_codes.siteCityCode";
		$result = mysqli_query($con,$query);
		//Response Text
		echo "<img src='images/ajax_loading.gif' height='20' /> 5. ".mysqli_affected_rows($con)." siteCityCode RECORDS UPDATED";
		break;
	case 6:
		//Update siteLotTypeCode
		$query = "UPDATE fl_cha_master JOIN lot_type_codes ON fl_cha_master.siteLotType = lot_type_codes.siteLotType SET fl_cha_master.siteLotTypeCode = lot_type_codes.siteLotTypeCode";
		$result = mysqli_query($con,$query);
		//Response Text
		echo "<img src='images/ajax_loading.gif' height='20' /> 6. ".mysqli_affected_rows($con)." siteLotTypeCode RECORDS UPDATED";
		break;
	case 7:
		//Update landUseDesc + siteUseType + siteUseTypeCode
		$query = "UPDATE fl_cha_master JOIN use_type_codes ON fl_cha_master.landUseCode = use_type_codes.landUseTypeCode SET fl_cha_master.landUseDesc = use_type_codes.landUseTypeDesc, fl_cha_master.siteUseType = use_type_codes.siteUseType, fl_cha_master.siteUseTypeCode = use_type_codes.siteUseTypeCode";
		$result = mysqli_query($con,$query);
		//Response Text
		echo "<img src='images/ajax_loading.gif' height='20' /> 7. ".mysqli_affected_rows($con)." siteUseTypeCode RECORDS UPDATED";
		break;
	case 8:
		//Update REPLACE &
		$query = "UPDATE fl_cha_master SET recOwnerFullName = Replace(recOwnerFullName,'&','+'), recOwnerCO = Replace(recOwnerCO,'&','+'), ownerFullName = Replace(ownerFullName,'&','+'), ownerCO = Replace(ownerCO,'&','+'), ownerAddr1 = Replace(ownerAddr1,'&','+')";
		$result = mysqli_query($con,$query);
		//Response Text
		echo "<img src='images/ajax_loading.gif' height='20' /> 8. ".mysqli_affected_rows($con)." RECORDS REPLACED '&'";
		break;
	case 9:
		//Update REPLACE '
		$query = "UPDATE fl_cha_master SET recOwnerFullName = Replace(recOwnerFullName,'\'',''), recOwnerCO = Replace(recOwnerCO,'\'',''), ownerFullName = Replace(ownerFullName,'\'',''), ownerCO = Replace(ownerCO,'\'',''), ownerAddr1 = Replace(ownerAddr1,'\'','')";
		$result = mysqli_query($con,$query);
		//Response Text
		echo "<img src='images/ajax_loading.gif' height='20' /> 9. ".mysqli_affected_rows($con)." RECORDS REPLACED single quote";
		break;
	case 10:
		//Update US 5 Char Zip
		$query = "UPDATE fl_cha_master SET ownerZip = substring(ownerZip,1,5) WHERE ownerCountry = 'UNITED STATES'";
		$result = mysqli_query($con,$query);
		//Response Text
		echo "<img src='images/ajax_loading.gif' height='20' /> 20. ".mysqli_affected_rows($con)." RECORDS UPDATED 5 CHAR Zip";
		break;
	default:
		echo "Error Processing...";
}

//Close Database Connection
include("dbclose.php");
?>