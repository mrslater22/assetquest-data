<?php
//ob
ob_start();

//session
session_start();

//Open Database Connection
include("dbopen.php");

//Insert Pre-Market
$date = date('Y-m-d H:i:s');
$query = "INSERT INTO zlcom_title (fkID,modUID,modDate,createUID) VALUES (".$_GET['propid'].",".$_GET['uid'].",'".$date."',".$_GET['uid'].");";
mysql_query($query);

$titleID = mysql_insert_id();
?>
<a href="/index.php?p=6&titleid=<?php echo $titleID; ?>"><span class="has-tip" data-width="150" title="View Title Info"><img src="<?php echo $_GET['appUrl']; ?>/images/bank.png" width="16" height="16" border="0" /></span></a>
<?php
include("dbclose.php");
?>