<?php
//Open Database Connection
include("floscdbopen.php");

//Truncate Master
mysqli_query($con,'TRUNCATE TABLE fl_osc_master;');

//Response Text
echo "Done!";

//Close Database Connection
include("dbclose.php");
?>