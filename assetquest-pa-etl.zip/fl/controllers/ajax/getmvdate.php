<?php
//ob
ob_start();

//session
session_start();

//Open Database Connection
include("dbopen.php");

//Update Property
$query = "SELECT mvDate FROM tbl_marketValue WHERE maID = ".$_GET['maid']." ORDER BY mvDate DESC LIMIT 1";
$result = mysql_query($query);
$row = mysql_fetch_assoc($result);
$rcount = mysql_num_rows($result);
if($rcount>0){
?>
Market Values Prices Last Updated: <?php echo date("m/d/Y",strtotime($row['mvDate'])); ?>
<?php
}
include("dbclose.php");
?>