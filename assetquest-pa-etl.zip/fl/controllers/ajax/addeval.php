<?php
//ob
ob_start();

//session
session_start();

//Open Database Connection
include("dbopen.php");

//Update Property
$query = "UPDATE tbl_property SET evalStauts = 1 WHERE propertyID = ".$_GET['propid'];
mysql_query($query);

?>
<a href="/index.php?p=9&propid=<?php echo $_GET['propid']; ?>"><span class="has-tip" data-width="150" title="View Eval Info"><img src="<?php echo $_GET['appUrl']; ?>/images/magnifier-medium.png" width="16" height="16" border="0" /></span></a>
<?php
include("dbclose.php");
?>