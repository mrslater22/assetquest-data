<?php
//Open Database Connection
include("flsardbopen.php");

//Truncate Master
mysqli_query($con,'TRUNCATE TABLE fl_sar_master;');

//Response Text
echo "Done!";

//Close Database Connection
include("dbclose.php");
?>