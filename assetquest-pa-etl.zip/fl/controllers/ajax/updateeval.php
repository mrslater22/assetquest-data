<?php
//ob
ob_start();

//session
session_start();

//Open Database Connection
include("dbopen.php");

if($_GET['evalValue']<>""){
	if($_GET['eid']>0){
		//Check Eval Date
		$query = "SELECT * FROM tbl_propEval WHERE evalID = ".$_GET['eid']." AND evalDate = '".date("Y-m-d")."'";
		$result = mysql_query($query);
		$rcount = mysql_num_rows($result);
		if($rcount>0){
			//Update Property
			$uQry = "UPDATE tbl_propEval SET ".$_GET['fieldName']." = ".$_GET['evalValue'].", modUID = ".$_GET['uid'].", modDate = '".date("Y-m-d H:i:s")."' WHERE evalID = ".$_GET['eid'];
			mysql_query($uQry);
		}else{
			//Insert Property
			$iQry = "INSERT INTO tbl_propEval (propertyID,".$_GET['fieldName'].",evalDate,createUID,modUID,modDate) VALUES (".$_GET['propid'].",".$_GET['evalValue'].",'".date("Y-m-d")."',".$_GET['uid'].",".$_GET['uid'].",'".date("Y-m-d H:i:s")."')";
			mysql_query($iQry);
		}
	}else{
		//Insert Property
		$iQry = "INSERT INTO tbl_propEval (propertyID,".$_GET['fieldName'].",evalDate,createUID,modUID,modDate) VALUES (".$_GET['propid'].",".$_GET['evalValue'].",'".date("Y-m-d")."',".$_GET['uid'].",".$_GET['uid'].",'".date("Y-m-d H:i:s")."')";
		mysql_query($iQry);
	}
}
include("dbclose.php");
?>