<?php
//ob
ob_start();

//session
session_start();

//Open Database Connection
include("dbopen.php");

//Check Pre-Market
$qFind = "SELECT * FROM zlcom_premarket WHERE fkID = ".$_GET['propid'];
$rFind = mysql_query($qFind);
$rcount = mysql_num_rows($rFind);
if($rcount==0){
	//Insert Pre-Market
	$date = date('Y-m-d H:i:s');
	$query = "INSERT INTO zlcom_premarket (fkID,typeID,modUID,modDate,createUID) VALUES (".$_GET['propid'].",1,".$_GET['uid'].",'".$date."',".$_GET['uid'].");";
	mysql_query($query);
	$listID = mysql_insert_id();
}else{
	$row = mysql_fetch_array($rFind);
	$listID = $row['listID'];
}
?>
<a href="/index.php?p=4&pmid=<?php echo $permarketID; ?>"><span class="has-tip" data-width="150" title="View Pre-Market Info"><img src="<?php echo $_GET['appUrl']; ?>/images/blog.png" width="16" height="16" border="0" /></span></a>
<?php
include("dbclose.php");
?>