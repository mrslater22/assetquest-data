<?php
//Open Database Connection
include("flmardbopen.php");

//Truncate Master
mysqli_query($con,'TRUNCATE TABLE fl_mar_import;');

//Response Text
echo "Done!";

//Close Database Connection
include("dbclose.php");
?>