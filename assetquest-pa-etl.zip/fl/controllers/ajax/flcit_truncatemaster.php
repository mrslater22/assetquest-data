<?php
//Open Database Connection
include("flcitdbopen.php");

//Truncate Master
mysqli_query($con,'TRUNCATE TABLE fl_cit_master;');

//Response Text
echo "Done!";

//Close Database Connection
include("dbclose.php");
?>