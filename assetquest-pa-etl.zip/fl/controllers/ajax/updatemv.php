<?php
//ob
ob_start();

//session
session_start();

//Open Database Connection
include("dbopen.php");

if($_GET['priceValue']<>""){
	if($_GET['mvid']>0){
		//Check Eval Date
		$query = "SELECT * FROM tbl_marketValue WHERE mvID = ".$_GET['mvid']." AND mvDate = '".date("Y-m-d")."'";
		$result = mysql_query($query);
		$rcount = mysql_num_rows($result);
		if($rcount>0){
			//Update Property
			$uQry = "UPDATE tbl_marketValue SET ".$_GET['fieldName']." = ".$_GET['priceValue'].", modUID = ".$_GET['uid'].", modDate = '".date("Y-m-d H:i:s")."' WHERE mvID = ".$_GET['mvid'];
			mysql_query($uQry);
		}else{
			//Insert Property
			$uQry = "INSERT INTO tbl_marketValue (maID,".$_GET['fieldName'].",mvDate,createUID,modUID,modDate) VALUES (".$_GET['maid'].",".$_GET['priceValue'].",'".date("Y-m-d")."',".$_GET['uid'].",".$_GET['uid'].",'".date("Y-m-d H:i:s")."')";
			mysql_query($uQry);			
		}
	}else{		
		//Insert Property
		$uQry = "INSERT INTO tbl_marketValue (maID,".$_GET['fieldName'].",mvDate,createUID,modUID,modDate) VALUES (".$_GET['maid'].",".$_GET['priceValue'].",'".date("Y-m-d")."',".$_GET['uid'].",".$_GET['uid'].",'".date("Y-m-d H:i:s")."')";
		mysql_query($uQry);		
	}

echo "$".number_format($_GET['priceValue'],0);
}
include("dbclose.php");
?>