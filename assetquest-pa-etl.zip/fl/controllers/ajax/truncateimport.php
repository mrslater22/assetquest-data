<?php
//ob
ob_start();

//session
session_start();

//Open Database Connection
include("dbopen.php");

//Truncate Master
mysql_query('TRUNCATE TABLE fl_lee_import;');
?>
Done!
<?php
include("dbclose.php");
?>