<?php
//Open Database Connection
include("flchadbopen.php");

$loopcount = 0;

//Insert Raw County Data
$query = "SELECT * FROM fl_cha_pa WHERE is_processed = 0 LIMIT 10000";
$result = mysql_query($query);
while($row = mysql_fetch_assoc($result)) {
	$parcelID = "score_".trim($row['accountNum']);
	$countyKey = "score_".trim($row['accountNum']);
	$strap = "score_".trim($row['accountNum']);
	
	//Make 4 Character landUseCode
	$landUseCode = '';
	switch(strlen(trim($row['landUse']))){
		case 1: $landUseCode = '000'.trim($row['landUse']); break;
		case 2: $landUseCode = '00'.trim($row['landUse']); break;
		case 3: $landUseCode = '0'.trim($row['landUse']); break;
		default: $landUseCode = trim($row['landUse']); break;
	}
	
	$landUseDesc = 'NONE'; //Value Not Provided By County Parcel Data
	$numUnits = 1; //Value Not Provided By County Parcel Data
	$frontage = 0; //Value Not Provided By County Parcel Data
	$depth = 0; //Value Not Provided By County Parcel Data
	$gisAcres = 0; //Value Not Provided By County Parcel Data
	$zoning = trim($row['zoningCode']);
	$zoningArea = 'NONE'; //Value Not Provided By County Parcel Data
	$siteNumber = trim($row['siteStreetNum']);
	$siteStreet = trim($row['siteStreetName']);
	$siteAddress = trim(trim($row['siteStreetNum'])." ".trim($row['siteStreetName']));
	$siteCity = 'NONE'; //Value Not Provided By County Parcel Data
	$siteState = "FLORIDA";
	$siteZip = trim($row['mapNum2']);
	$siteCounty = "CHARLOTTE";
	$siteSubArea = "NONE";
	$siteUnit = "NONE";
	
	//Determine siteLotType as DRY, FRESHWATER or SALTWATER
	$siteLotType = 'NONE';
	switch(trim($row['waterfront'])){
		case 'False': $siteLotType = 'DRY'; break;
		case 'True': $siteLotType = 'FRESHWATER'; break;
		default: $siteLotType = 'DRY'; break;
	}
	
	$siteStateCode = "FL";
	$siteCountyCode = "CHA";
	$siteCityCode = "NON";
	$siteSubAreaCode = "NON";
	$siteUnitCode = "NON";
	$siteLotTypeCode = "NON";
	$siteUseTypeCode = "NON";
	$siteSizeCode = "000";
	$yearBuilt = trim($row['buildUseCode3']);
	$sfTotal = trim($row['totalBuildArea']);
	$sfUA = trim($row['buildUseCode2']);
	$beds = 0; //Value Not Provided By County Parcel Data
	$baths = 0; //Value Not Provided By County Parcel Data
	$garage = 0; //Value Not Provided By County Parcel Data
	$carport = 0; //Value Not Provided By County Parcel Data
	if(trim($row['pool'])=='True'){
		$pool = 1;
	}else{
		$pool = 0;
	}
	$boatdock = 0; //Value Not Provided By County Parcel Data
	$seawall = 0; //Value Not Provided By County Parcel Data
	$assessedValue = trim($row['assessedValue']);
	$recOwnerFullName = trim($row['ownerName']);
	$recOwnerCO = trim($row['ownerName2']);
	$ownerFullName = trim($row['ownerName']);
	$ownerCO = trim($row['ownerName2']);
	$ownerAddr1 = trim($row['ownerAddr']);
	$ownerAddr2 = trim($row['ownerSuite']);
	$ownerCity = trim($row['ownerCity']);
	$ownerState = trim($row['ownerState']);
	$ownerZip = trim($row['ownerZipCode']);
	$ownerCountry = trim($row['ownerCountry']);
	$saleDate = date($row['saleDate']);
	$saleAmt = $row['consideration'];
	$saleTC = trim($row['code']);
	if(trim($row['legalDescLong'])<>''){
		$legalDesc = trim($row['legalDescLong']);
	}else{
		$legalDesc = 'NONE';
	}
	if(trim($row['legalDescShort'])<>''){
		$legalDesc2 = substr(trim($row['legalDescShort']),0,7);
	}else{
		$legalDesc2 = 'NONE';
	}
	$parcelID2 = trim($row['accountNum']);
	$strap2 = trim($row['accountNum']);
	$legalDesc30 = substr(trim($row['legalDescLong']),0,30);
	
	$iQuery = "INSERT INTO fl_cha_master (parcelID,countyKey,strap,landUseCode,landUseDesc,numUnits,frontage,depth,gisAcres,zoning,zoningArea,siteNumber,siteStreet,siteAddress,siteCity,siteState,siteZip,siteCounty,siteSubArea,siteUnit,siteLotType,siteStateCode,siteCountyCode,siteCityCode,siteSubAreaCode,siteUnitCode,siteLotTypeCode,siteUseTypeCode,siteSizeCode,yearBuilt,sfTotal,sfUA,beds,baths,garage,carport,pool,boatdock,seawall,assessedValue,recOwnerFullName,recOwnerCO,ownerFullName,ownerCO,ownerAddr1,ownerAddr2,ownerCity,ownerState,ownerZip,ownerCountry,saleDate,saleAmt,legalDesc,legalDesc2,parcelID2,strap2,legalDesc30,saleTC) VALUES ('".addslashes($parcelID)."','".addslashes($countyKey)."','".addslashes($strap)."','".addslashes($landUseCode)."','".addslashes($landUseDesc)."',".addslashes($numUnits).",".addslashes($frontage).",".addslashes($depth).",".addslashes($gisAcres).",'".addslashes($zoning)."','".addslashes($zoningArea)."','".addslashes($siteNumber)."','".addslashes($siteStreet)."','".addslashes($siteAddress)."','".addslashes($siteCity)."','".addslashes($siteState)."','".addslashes($siteZip)."','".addslashes($siteCounty)."','".addslashes($siteSubArea)."','".addslashes($siteUnit)."','".addslashes($siteLotType)."','".addslashes($siteStateCode)."','".addslashes($siteCountyCode)."','".addslashes($siteCityCode)."','".addslashes($siteSubAreaCode)."','".addslashes($siteUnitCode)."','".addslashes($siteLotTypeCode)."','".addslashes($siteUseTypeCode)."','".addslashes($siteSizeCode)."',".addslashes($yearBuilt).",".addslashes($sfTotal).",".addslashes($sfUA).",".addslashes($beds).",".addslashes($baths).",".addslashes($garage).",".addslashes($carport).",".addslashes($pool).",".addslashes($boatdock).",".addslashes($seawall).",".addslashes($assessedValue).",'".addslashes($recOwnerFullName)."','".addslashes($recOwnerCO)."','".addslashes($ownerFullName)."','".addslashes($ownerCO)."','".addslashes($ownerAddr1)."','".addslashes($ownerAddr2)."','".addslashes($ownerCity)."','".addslashes($ownerState)."','".addslashes($ownerZip)."','".addslashes($ownerCountry)."','".addslashes($saleDate)."',".addslashes($saleAmt).",'".addslashes($legalDesc)."','".addslashes($legalDesc2)."','".addslashes($parcelID2)."','".addslashes($strap2)."','".addslashes($legalDesc30)."','".addslashes($saleTC)."')";
	$iResult = mysql_query($iQuery);
	
	$uQuery = "UPDATE fl_cha_pa SET is_processed = 1 WHERE accountNum = '".$row['accountNum']."'";
	$uResult = mysql_query($uQuery);
	
	$loopcount++;
}

//Check Raw County Data Not Processed
$cQuery = "SELECT * FROM fl_cha_pa WHERE is_processed = 0";
$cResult = mysql_query($cQuery);
$rcount = mysql_num_rows($cResult);

//Response Text
echo $rcount;

//Close Database Connection
include("dbclose.php"); 
?>