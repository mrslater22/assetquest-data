<?php
//Open Database Connection
include("flcoldbopen.php");

$loopcount = 0;

//Insert Raw County Data
$query = "SELECT id, parcel_id, use_code, acres, str_num, str_name, str_type, str_ord, city_cd, sitezip, cur_yr_ass, ownerName, ownerCO, ownerAddr1, ownerAddr2, city, st, zip, saleDateMonth, saleDateDay, saleDateYear, sal1_amt, legalDesc, siteSubArea, siteUnit FROM fl_col_pa WHERE is_processed = 0 LIMIT 1000";
$result = mysqli_query($con,$query);
while($row = mysqli_fetch_assoc($result)) {
	$parcelID = "score_".trim($row['parcel_id']);
	$countyKey = "score_".trim($row['parcel_id']);
	$strap = "score_".trim($row['parcel_id']);
	$landUseCode = trim($row['use_code']);
	$landUseDesc = 'NULL'; //Value Not Provided By County Parcel Data
	$numUnits = 1; //Value Not Provided By County Parcel Data
	$frontage = 0; //Value Not Provided By County Parcel Data
	$depth = 0; //Value Not Provided By County Parcel Data
	$gisAcres = number_format($row['acres']/100,2,'.','');
	$zoning = 'NULL'; //Value Not Provided By County Parcel Data
	$zoningArea = 'NULL'; //Value Not Provided By County Parcel Data
	$siteNumber = trim($row['str_num']);
	if(trim($row['str_name'])<>'NULL'){
		if(trim($row['str_ord'])<>'NULL'){
			$siteStreet = trim($row['str_name'])." ".trim($row['str_type'])." ".trim($row['str_ord']);
		}else{
			$siteStreet = trim($row['str_name'])." ".trim($row['str_type']);
		}
		if($siteNumber<>'NULL'){
			$siteAddress = $siteNumber." ".$siteStreet;
		}else{
			$siteAddress = $siteStreet;
		}		
	}else{
		$siteStreet = 'NULL';
		$siteAddress = 'NULL';
	}
	$siteCity = 'NULL'; //Value Not Provided By County Parcel Data
	$siteState = "FLORIDA";
	$siteZip = trim($row['sitezip']);
	$siteCounty = "COLLIER";
	$siteSubArea = trim($row['siteSubArea']);
	$siteUnit = trim($row['siteUnit']);
	$siteLotType = "DRY";
	$siteUseType = "NONE";
	$siteStateCode = "FL";
	$siteCountyCode = "COL";
	$siteCityCode = "NON";
	$siteSubAreaCode = "NON";
	$siteUnitCode = "NON";
	$siteLotTypeCode = "DRY";
	$siteUseTypeCode = "NON";
	$siteSizeCode = "000";
	$yearBuilt = 0; //Value Not Provided By County Parcel Data
	$sfTotal = 0; //Value Not Provided By County Parcel Data
	$sfUA = 0; //Value Not Provided By County Parcel Data
	$beds = 0; //Value Not Provided By County Parcel Data
	$baths = 0; //Value Not Provided By County Parcel Data
	$garage = 0; //Value Not Provided By County Parcel Data
	$carport = 0; //Value Not Provided By County Parcel Data
	$pool = 0; //Value Not Provided By County Parcel Data
	$boatdock = 0; //Value Not Provided By County Parcel Data
	$seawall = 0; //Value Not Provided By County Parcel Data
	$assessedValue = number_format($row['cur_yr_ass']/100,2,'.','');
	$recOwnerFullName = trim($row['ownerName']);
	$recOwnerCO = trim($row['ownerCO']);
	$ownerFullName = trim($row['ownerName']);
	$ownerCO = trim($row['ownerCO']);
	$ownerAddr1 = trim($row['ownerAddr1']);
	$ownerAddr2 = trim($row['ownerAddr2']);
	$ownerCity = trim($row['city']);
	$ownerState = trim($row['st']);
	$ownerZip = trim($row['zip']);
	$ownerCountry = "NULL"; //Value Not Provided By County Parcel Data
	$saleDate = $row['saleDateYear']."-".$row['saleDateMonth']."-".$row['saleDateDay'];
	$saleAmt = number_format($row['sal1_amt']/100,2,'.','');
	$saleTC = 0; //Value Not Provided By County Parcel Data
	$legalDesc = trim($row['legalDesc']);
	$legalDesc2 = trim($row['city_cd']);
	$parcelID2 = trim($row['parcel_id']);
	$strap2 = trim($row['parcel_id']);
	$legalDesc30 = substr($legalDesc,0,30);
	
	$iQuery = "INSERT INTO fl_col_master (parcelID,countyKey,strap,landUseCode,landUseDesc,numUnits,frontage,depth,gisAcres,zoning,zoningArea,siteNumber,siteStreet,siteAddress,siteCity,siteState,siteZip,siteCounty,siteSubArea,siteUnit,siteLotType,siteStateCode,siteCountyCode,siteCityCode,siteSubAreaCode,siteUnitCode,siteLotTypeCode,siteUseTypeCode,siteSizeCode,yearBuilt,sfTotal,sfUA,beds,baths,garage,carport,pool,boatdock,seawall,assessedValue,recOwnerFullName,recOwnerCO,ownerFullName,ownerCO,ownerAddr1,ownerAddr2,ownerCity,ownerState,ownerZip,ownerCountry,saleDate,saleAmt,legalDesc,legalDesc2,parcelID2,strap2,legalDesc30,saleTC) VALUES ('".$parcelID."','".$countyKey."','".$strap."','".$landUseCode."','".$landUseDesc."',".$numUnits.",".$frontage.",".$depth.",".$gisAcres.",'".$zoning."','".$zoningArea."','".$siteNumber."','".$siteStreet."','".$siteAddress."','".$siteCity."','".$siteState."','".$siteZip."','".$siteCounty."','".$siteSubArea."','".$siteUnit."','".$siteLotType."','".$siteStateCode."','".$siteCountyCode."','".$siteCityCode."','".$siteSubAreaCode."','".$siteUnitCode."','".$siteLotTypeCode."','".$siteUseTypeCode."','".$siteSizeCode."',".$yearBuilt.",".$sfTotal.",".$sfUA.",".$beds.",".$baths.",".$garage.",".$carport.",".$pool.",".$boatdock.",".$seawall.",".$assessedValue.",'".$recOwnerFullName."','".$recOwnerCO."','".$ownerFullName."','".$ownerCO."','".$ownerAddr1."','".$ownerAddr2."','".$ownerCity."','".$ownerState."','".$ownerZip."','".$ownerCountry."','".$saleDate."',".$saleAmt.",'".$legalDesc."','".$legalDesc2."','".$parcelID2."','".$strap2."','".$legalDesc30."','".$saleTC."')";
	$iResult = mysqli_query($con,$iQuery);
	
	//echo $iQuery."<br />";
	
	$uQuery = "UPDATE fl_col_pa SET is_processed = 1 WHERE id = '".$row['id']."'";
	$uResult = mysqli_query($con,$uQuery);
	
	$loopcount++;
}

//Check Raw County Data Not Processed
$cQuery = "SELECT * FROM fl_col_pa WHERE is_processed = 0";
$cResult = mysqli_query($con,$cQuery);
$rcount = mysqli_num_rows($cResult);

//Response Text
echo $rcount;

//Close Database Connection
include("dbclose.php"); 
?>