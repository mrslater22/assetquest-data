<?php
//ob
ob_start();

//session
session_start();

//Open Database Connection
include("dbopen.php");

//Check List For Site Unit
$checkList = 0;
$arySiteUnit = explode(",",$_SESSION['siteUnitList']);	
foreach($arySiteUnit as $siteUnit){
	if($siteUnit==$_GET['siteunit']){
		$checkList = 1;
	}
}

if($checkList==1){	
	//Remove Site Unit
	$loopCount = 1;
	foreach($arySiteUnit as $siteUnit){
		if($siteUnit<>$_GET['siteunit']){
			if($loopCount==1){
				$_SESSION['siteUnitList'] = $siteUnit;
			}else{
				$_SESSION['siteUnitList'] = $_SESSION['siteUnitList'].",".$siteUnit;
			}
			$loopCount++;
		}		
	}
}else{
	//Insert Site Unit
	$_SESSION['siteUnitList'] = $_SESSION['siteUnitList'].",".$_GET['siteunit'];
}

echo "Showing Site Units: ".$_SESSION['siteUnitList'];

include("dbclose.php");
?>