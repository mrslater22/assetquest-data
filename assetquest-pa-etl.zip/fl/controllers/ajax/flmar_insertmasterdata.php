<?php
//Open Database Connection
include("flmardbopen.php");

$loopcount = 0;

//Insert Raw County Data
$query = "SELECT * FROM fl_mar_pa WHERE is_processed = 0 LIMIT 1000";
$result = mysqli_query($con,$query);
while($row = mysqli_fetch_assoc($result)) {
	$parcelID = "score_".$row['STRAP'];
	$countyKey = "score_".$row['STRAP'];
	$strap = "score_".substr($row['STRAP'],0,2)."-".substr($row['STRAP'],2,2)."-".substr($row['STRAP'],4,2)."-".substr($row['STRAP'],6,2)."-".substr($row['STRAP'],8,5).".".substr($row['STRAP'],13,4);
	$landUseCode = $row['DORCODE'];
	$landUseDesc = $row['LANDUSEDES'];
	$numUnits = $row['NUMUNITS'];
	$frontage = $row['FRONTAGE'];
	$depth = $row['DEPTH'];
	$gisAcres = $row['GISACRES'];
	$zoning = $row['ZONING'];
	$zoningArea = $row['ZONINGAREA'];
	$siteNumber = $row['SITENUMBER'];
	$siteStreet = $row['SITESTREET'];
	$siteAddress = $row['SITEADDR'];
	$siteCity = $row['SITECITY'];
	$siteState = "FLORIDA";
	$siteZip = $row['SITEZIP'];
	$siteCounty = "MARION";
	$siteSubArea = "NONE";
	$siteUnit = "NONE";

	//Determine siteLotType as DRY, FRESHWATER or SALTWATER
	$siteLotType = 'NONE';
	switch($row['LANDISON']){
		case 'GOLF': $siteLotType = 'DRY'; break;
		case 'CANAL': $siteLotType = 'FRESHWATER'; break;
		case 'LAKE': $siteLotType = 'FRESHWATER'; break;
		case 'CREEK': $siteLotType = 'FRESHWATER'; break;
		case 'BAY': $siteLotType = 'SALTWATER'; break;
		case 'GULF': $siteLotType = 'SALTWATER'; break;
		case 'RIVER': $siteLotType = 'SALTWATER'; break;
		default: $siteLotType = 'DRY'; break;
	}

	$siteStateCode = "FL";
	$siteCountyCode = "MARION";
	$siteCityCode = "NON";
	$siteSubAreaCode = "NON";
	$siteUnitCode = "NON";
	$siteLotTypeCode = "NON";
	$siteUseTypeCode = "NON";
	$siteSizeCode = "000";
	$yearBuilt = $row['MAXBUILTY'];
	$sfTotal = $row['TOTALAREA'];
	$sfUA = $row['HEATEDAREA'];
	$beds = $row['BEDROOMS'];
	$baths = $row['BATHROOMS'];
	$garage = $row['GARAGE'];
	$carport = $row['CARPORT'];
	$pool = $row['POOL'];
	$boatdock = $row['BOATDOCK'];
	$seawall = $row['SEAWALL'];
	$assessedValue = $row['ASSESSED'];
	$recOwnerFullName = $row['O_NAME'];
	$recOwnerCO = $row['O_CAREOF'];
	$ownerFullName = $row['O_NAME'];
	$ownerCO = $row['O_CAREOF'];
	$ownerAddr1 = $row['O_ADDR1'];
	$ownerAddr2 = $row['O_ADDR2'];
	$ownerCity = $row['O_CITY'];
	$ownerState = $row['O_STATE'];
	$ownerZip = $row['O_ZIP'];
	$ownerCountry = $row['O_COUNTRY'];
	$saleDate = date($row['S_1DATE']);
	$saleAmt = $row['S_1AMOUNT'];
	$saleTC = $row['S_1TC'];
	$legalDesc = $row['S_LEGAL'];
	$legalDesc2 = 'NONE';
	$parcelID2 = $row['STRAP'];
	$strap2 = $row['STRAP'];
	$legalDesc30 = substr($row['S_LEGAL'],0,30);

	$iQuery = "INSERT INTO fl_mar_master (parcelID,countyKey,strap,landUseCode,landUseDesc,numUnits,frontage,depth,gisAcres,zoning,zoningArea,siteNumber,siteStreet,siteAddress,siteCity,siteState,siteZip,siteCounty,siteSubArea,siteUnit,siteLotType,siteStateCode,siteCountyCode,siteCityCode,siteSubAreaCode,siteUnitCode,siteLotTypeCode,siteUseTypeCode,siteSizeCode,yearBuilt,sfTotal,sfUA,beds,baths,garage,carport,pool,boatdock,seawall,assessedValue,recOwnerFullName,recOwnerCO,ownerFullName,ownerCO,ownerAddr1,ownerAddr2,ownerCity,ownerState,ownerZip,ownerCountry,saleDate,saleAmt,legalDesc,legalDesc2,parcelID2,strap2,legalDesc30,saleTC) VALUES ('".$parcelID."','".$countyKey."','".$strap."','".$landUseCode."','".$landUseDesc."',".$numUnits.",".$frontage.",".$depth.",".$gisAcres.",'".$zoning."','".$zoningArea."','".$siteNumber."','".$siteStreet."','".$siteAddress."','".$siteCity."','".$siteState."','".$siteZip."','".$siteCounty."','".$siteSubArea."','".$siteUnit."','".$siteLotType."','".$siteStateCode."','".$siteCountyCode."','".$siteCityCode."','".$siteSubAreaCode."','".$siteUnitCode."','".$siteLotTypeCode."','".$siteUseTypeCode."','".$siteSizeCode."',".$yearBuilt.",".$sfTotal.",".$sfUA.",".$beds.",".$baths.",".$garage.",".$carport.",".$pool.",".$boatdock.",".$seawall.",".$assessedValue.",'".$recOwnerFullName."','".$recOwnerCO."','".$ownerFullName."','".$ownerCO."','".$ownerAddr1."','".$ownerAddr2."','".$ownerCity."','".$ownerState."','".$ownerZip."','".$ownerCountry."','".$saleDate."',".$saleAmt.",'".$legalDesc."','".$legalDesc2."','".$parcelID2."','".$strap2."','".$legalDesc30."','".$saleTC."')";
	$iResult = mysqli_query($con,$iQuery);

	//echo $iQuery;

	$uQuery = "UPDATE fl_mar_pa SET is_processed = 1 WHERE STRAP = '".$row['STRAP']."'";
	$uResult = mysqli_query($con,$uQuery);

	$loopcount++;
}

//Check Raw County Data Not Processed
$cQuery = "SELECT * FROM fl_mar_pa WHERE is_processed = 0";
$cResult = mysqli_query($con,$cQuery);
$rcount = mysqli_num_rows($cResult);

//Response Text
echo $rcount;

//Close Database Connection
include("dbclose.php");
?>