<?php
//Open Database Connection
include("flfladbopen.php");

//Truncate Master
mysqli_query($con,'TRUNCATE TABLE fl_fla_import;');

//Response Text
echo "Done!";

//Close Database Connection
include("dbclose.php");
?>