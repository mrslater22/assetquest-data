<?php
//Open Database Connection
include("flfladbopen.php");

//Clean Master Data
switch($_GET['pid']){
	case 0:
		//Update CAPE CORAL UNITS
		$query = "UPDATE fl_fla_master SET siteUnit = Trim(Mid(legalDesc,17,2)) WHERE legalDesc Like 'CAPE CORAL UNIT%'";
		$result = mysqli_query($con,$query);
		//Response Text
		echo "<img src='images/ajax_loading.gif' height='20' /> 0. ".mysqli_affected_rows($con)." CAPE CORAL UNITS UPDATED";
		break;
	case 1:
		//Update CAPE CORAL UNITS 47 PART
		$query = "UPDATE fl_fla_master SET siteUnit = '47-'&Trim(Mid(legalDesc,25,1)) WHERE legalDesc Like 'CAPE CORAL UNIT 47 PART%'";
		$result = mysqli_query($con,$query);
		//Response Text
		echo "<img src='images/ajax_loading.gif' height='20' /> 1. ".mysqli_affected_rows($con)." CAPE CORAL UNITS 47 PART UPDATED";
		break;
	case 2:
		//Update CAPE CORAL UNITS 47 PG
		$query = "UPDATE fl_fla_master SET siteUnit = '47-'&Trim(Mid(legalDesc,23,1)) WHERE legalDesc Like 'CAPE CORAL UNIT 47 PG%'";
		$result = mysqli_query($con,$query);
		//Response Text
		echo "<img src='images/ajax_loading.gif' height='20' /> 2. ".mysqli_affected_rows($con)." CAPE CORAL UNITS 47 PG UPDATED";
		break;
	case 3:
		//Update CAPE CORAL UNITS 47 PT
		$query = "UPDATE fl_fla_master SET siteUnit = '47-'&Trim(Mid(legalDesc,23,1)) WHERE legalDesc Like 'CAPE CORAL UNIT 47 PT%'";
		$result = mysqli_query($con,$query);
		//Response Text
		echo "<img src='images/ajax_loading.gif' height='20' /> 3. ".mysqli_affected_rows($con)." CAPE CORAL UNITS 47 PT UPDATED";
		break;
	case 4:
		//Update CAPE CORAL UNITS 47PT
		$query = "UPDATE fl_fla_master SET siteUnit =  '47-'&Trim(Mid(legalDesc,22,1)) WHERE legalDesc Like 'CAPE CORAL UNIT 47PT%'";
		$result = mysqli_query($con,$query);
		//Response Text
		echo "<img src='images/ajax_loading.gif' height='20' /> 4. ".mysqli_affected_rows($con)." CAPE CORAL UNITS 47PT UPDATED";
		break;
	case 5:
		//Update LEHIGH ACRES UNITS
		$query = "UPDATE fl_fla_master SET siteUnit = Trim(Mid(legalDesc,19,2)) WHERE legalDesc Like 'LEHIGH ACRES UNIT%'";
		$result = mysqli_query($con,$query);
		//Response Text
		echo "<img src='images/ajax_loading.gif' height='20' /> 5. ".mysqli_affected_rows($con)." LEHIGH ACRES UNITS UPDATED";
		break;
	case 6:
		//Update UNITS 03
		$query = "UPDATE fl_fla_master SET siteUnit = '3' WHERE siteUnit = '03'";
		$result = mysqli_query($con,$query);
		//Response Text
		echo "<img src='images/ajax_loading.gif' height='20' /> 6. ".mysqli_affected_rows($con)." UNITS 03 = 3 UPDATED";
		break;
	case 7:
		//Update CAPE CORAL LOT TYPE SALT
		$query = "UPDATE fl_fla_master SET siteLotType = 'SALTWATER' WHERE (siteLotType='FRESHWATER') AND (siteCity='CAPE CORAL') AND ((siteUnit='3') Or (siteUnit='27') Or (siteUnit='30') Or (siteUnit='44') Or (siteUnit='45') Or (siteUnit='58') Or (siteUnit='64') Or (siteUnit='65') Or (siteUnit='67') Or (siteUnit='69') Or (siteUnit='70') Or (siteUnit='72') Or (siteUnit='73') Or (siteUnit='74') Or (siteUnit='75') Or (siteUnit='77') Or (siteUnit='92') Or (siteUnit='93') Or (siteUnit='96') Or (siteUnit='54') Or (siteUnit='54') Or (siteUnit='58') Or (siteUnit='73') Or (siteUnit='93') Or (siteUnit='95') Or (siteUnit='96') Or (siteUnit='1') Or (siteUnit='2') Or (siteUnit='4') Or (siteUnit='5') Or (siteUnit='6') Or (siteUnit='7') Or (siteUnit='8') Or (siteUnit='9') Or (siteUnit='10') Or (siteUnit='11') Or (siteUnit='12') Or (siteUnit='13') Or (siteUnit='14') Or (siteUnit='15') Or (siteUnit='18') Or (siteUnit='19') Or (siteUnit='20') Or (siteUnit='21') Or (siteUnit='22') Or (siteUnit='26') Or (siteUnit='89') Or (siteUnit='59') Or (siteUnit='60') Or (siteUnit='61') Or (siteUnit='76') Or (siteUnit='81') Or (siteUnit='82') Or (siteUnit='83') Or (siteUnit='90') Or (siteUnit='91'))";
		$result = mysqli_query($con,$query);
		//Response Text
		echo "<img src='images/ajax_loading.gif' height='20' /> 7. ".mysqli_affected_rows($con)." CAPE CORAL LOT TYPE = SALT UPDATED";
		break;
	case 8:
		//Update CAPE CORAL SUBAREA NORTHWEST
		$query = "UPDATE fl_fla_master SET siteSubArea = 'NORTHWEST' WHERE (siteCity='CAPE CORAL') AND ((siteUnit='37') Or (siteUnit='38') Or (siteUnit='39') Or (siteUnit='40') Or (siteUnit='41') Or (siteUnit='42') Or (siteUnit='43') Or (siteUnit='48') Or (siteUnit='51') Or (siteUnit='52') Or (siteUnit='53') Or (siteUnit='55') Or (siteUnit='56') Or (siteUnit='57') Or (siteUnit='59') Or (siteUnit='60') Or (siteUnit='61') Or (siteUnit='76') Or (siteUnit='80') Or (siteUnit='81') Or (siteUnit='82') Or (siteUnit='83') Or (siteUnit='90') Or (siteUnit='91') Or (siteUnit='97') Or (siteUnit='98'))";
		$result = mysqli_query($con,$query);
		//Response Text
		echo "<img src='images/ajax_loading.gif' height='20' /> 8. ".mysqli_affected_rows($con)." CAPE CORAL SUBAREA NORTHWEST UPDATED";
		break;
	case 9:
		//Update CAPE CORAL SUBAREA NORTHEAST
		$query = "UPDATE fl_fla_master SET siteSubArea = 'NORTHEAST' WHERE (siteCity='CAPE CORAL') AND ((siteUnit='17') Or (siteUnit='31') Or (siteUnit='32') Or (siteUnit='33') Or (siteUnit='34') Or (siteUnit='35') Or (siteUnit='36') Or (siteUnit='46') Or (siteUnit='47') Or (siteUnit='47-1') Or (siteUnit='47-2') Or (siteUnit='47-3') Or (siteUnit='47-4') Or (siteUnit='84') Or (siteUnit='85') Or (siteUnit='86') Or (siteUnit='87') Or (siteUnit='88'))";
		$result = mysqli_query($con,$query);
		//Response Text
		echo "<img src='images/ajax_loading.gif' height='20' /> 9. ".mysqli_affected_rows($con)." CAPE CORAL SUBAREA NORTHEAST UPDATED";
		break;
	case 10:
		//Update CAPE CORAL SUBAREA SOUTHWEST
		$query = "UPDATE fl_fla_master SET siteSubArea = 'SOUTHWEST' WHERE (siteCity='CAPE CORAL') AND ((siteUnit='3') Or (siteUnit='27') Or (siteUnit='28') Or (siteUnit='29') Or (siteUnit='30') Or (siteUnit='44') Or (siteUnit='45') Or (siteUnit='49') Or (siteUnit='50') Or (siteUnit='54') Or (siteUnit='58') Or (siteUnit='28') Or (siteUnit='62') Or (siteUnit='63') Or (siteUnit='64') Or (siteUnit='65') Or (siteUnit='66') Or (siteUnit='67') Or (siteUnit='68') Or (siteUnit='69') Or (siteUnit='70') Or (siteUnit='71') Or (siteUnit='72') Or (siteUnit='73') Or (siteUnit='74') Or (siteUnit='75') Or (siteUnit='92') Or (siteUnit='93') Or (siteUnit='94') Or (siteUnit='95') Or (siteUnit='96'))";
		$result = mysqli_query($con,$query);
		//Response Text
		echo "<img src='images/ajax_loading.gif' height='20' /> 10. ".mysqli_affected_rows($con)." CAPE CORAL SUBAREA SOUTHWEST UPDATED";
		break;
	case 11:
		//Update CAPE CORAL SUBAREA SOUTHEAST
		$query = "UPDATE fl_fla_master SET siteSubArea = 'SOUTHEAST' WHERE (siteCity='CAPE CORAL') AND ((siteUnit='1') Or (siteUnit='2') Or (siteUnit='4') Or (siteUnit='5') Or (siteUnit='6') Or (siteUnit='7') Or (siteUnit='8') Or (siteUnit='9') Or (siteUnit='10') Or (siteUnit='11') Or (siteUnit='12') Or (siteUnit='13') Or (siteUnit='14') Or (siteUnit='15') Or (siteUnit='16') Or (siteUnit='18') Or (siteUnit='19') Or (siteUnit='20') Or (siteUnit='21') Or (siteUnit='22') Or (siteUnit='23') Or (siteUnit='24') Or (siteUnit='25') Or (siteUnit='26') Or (siteUnit='89'))";
		$result = mysqli_query($con,$query);
		//Response Text
		echo "<img src='images/ajax_loading.gif' height='20' /> 11. ".mysqli_affected_rows($con)." CAPE CORAL SUBAREA SOUTHEAST UPDATED";
		break;
	case 12:
		//Update LEHIGH ACRES SUBAREAS
		$query = "UPDATE fl_fla_master INNER JOIN lehigh_subarea ON fl_fla_master.parcelID2 = lehigh_subarea.STRAP SET fl_fla_master.siteSubArea = lehigh_subarea.subArea WHERE fl_fla_master.siteCity = 'LEHIGH ACRES'";
		$result = mysqli_query($con,$query);
		//Response Text
		echo "<img src='images/ajax_loading.gif' height='20' /> 12. ".mysqli_affected_rows($con)." LEHIGH ACRES SUBAREAS UPDATED";
		break;
	case 13:
		//Update FLAGLER NO UNIT SUBAREAS
		$query = "UPDATE fl_fla_master INNER JOIN fl_fla_unit_subarea ON fl_fla_master.parcelID2 = fl_fla_unit_subarea.STRAP SET fl_fla_master.siteUnit = fl_fla_unit_subarea.siteUnit, fl_fla_master.siteSubArea = fl_fla_unit_subarea.siteSubArea WHERE fl_fla_master.siteUnit='NONE'";
		$result = mysqli_query($con,$query);
		//Response Text
		echo "<img src='images/ajax_loading.gif' height='20' /> 13. ".mysqli_affected_rows($con)." FLAGLER NO UNIT SUBAREAS UPDATED";
		break;
	case 14:
		//Update SUBAREA CODES
		$query = "UPDATE fl_fla_master LEFT JOIN subarea_codes ON (fl_fla_master.siteSubArea = subarea_codes.siteSubArea) AND (fl_fla_master.siteCounty = subarea_codes.siteCounty) AND (fl_fla_master.siteState = subarea_codes.siteState) SET fl_fla_master.siteSubAreaCode = subarea_codes.siteSubAreaCode";
		$result = mysqli_query($con,$query);
		//Response Text
		echo "<img src='images/ajax_loading.gif' height='20' /> 14. ".mysqli_affected_rows($con)." SUBAREA CODES UPDATED";
		break;
	case 15:
		//Update CITY CODES
		$query = "UPDATE fl_fla_master LEFT JOIN city_codes ON (fl_fla_master.siteCity = city_codes.siteCity) AND (fl_fla_master.siteCounty = city_codes.siteCounty) AND (fl_fla_master.siteState = city_codes.siteState) SET fl_fla_master.siteCityCode = city_codes.siteCityCode";
		$result = mysqli_query($con,$query);
		//Response Text
		echo "<img src='images/ajax_loading.gif' height='20' /> 15. ".mysqli_affected_rows($con)." CITY CODES UPDATED";
		break;
	case 16:
		//Update UNIT CODES
		$query = "UPDATE fl_fla_master INNER JOIN unit_codes ON (fl_fla_master.siteState = unit_codes.siteState) AND (fl_fla_master.siteCounty = unit_codes.siteCounty) AND (fl_fla_master.siteCity = unit_codes.siteCity) AND (fl_fla_master.siteUnit = unit_codes.siteUnit) SET fl_fla_master.siteUnitCode = unit_codes.siteUnitCode";
		$result = mysqli_query($con,$query);
		//Response Text
		echo "<img src='images/ajax_loading.gif' height='20' /> 16. ".mysqli_affected_rows($con)." UNIT CODES UPDATED";
		break;
	case 17:
		//Update LOT TYPE CODES
		$query = "UPDATE fl_fla_master LEFT JOIN lot_type_codes ON (fl_fla_master.siteCounty = lot_type_codes.siteCounty) AND (fl_fla_master.siteState = lot_type_codes.siteState) AND (fl_fla_master.siteLotType = lot_type_codes.siteLotType) SET fl_fla_master.siteLotTypeCode = lot_type_codes.siteLotTypeCode";
		$result = mysqli_query($con,$query);
		//Response Text
		echo "<img src='images/ajax_loading.gif' height='20' /> 17. ".mysqli_affected_rows($con)." LOT TYPE CODES UPDATED";
		break;
	case 18:
		//Update USE TYPE CODES
		$query = "UPDATE fl_fla_master INNER JOIN use_type_codes ON fl_fla_master.landUseDesc = use_type_codes.landUseTypeDesc SET fl_fla_master.siteUseType = use_type_codes.siteUseType, fl_fla_master.siteUseTypeCode = use_type_codes.siteUseTypeCode";
		$result = mysqli_query($con,$query);
		//Response Text
		echo "<img src='images/ajax_loading.gif' height='20' /> 18. ".mysqli_affected_rows($con)." USE TYPE CODES UPDATED";
		break;
	case 19:
		//Update REPLACE &
		$query = "UPDATE fl_fla_master SET recOwnerFullName = Replace(recOwnerFullName,'&','+'), recOwnerCO = Replace(recOwnerCO,'&','+'), ownerFullName = Replace(ownerFullName,'&','+'), ownerCO = Replace(ownerCO,'&','+'), ownerAddr1 = Replace(ownerAddr1,'&','+')";
		$result = mysqli_query($con,$query);
		//Response Text
		echo "<img src='images/ajax_loading.gif' height='20' /> 19. ".mysqli_affected_rows($con)." USE REPLACE '&'";
		break;
	case 20:
		//Update REPLACE quote
		$query = "UPDATE fl_fla_master SET recOwnerFullName = Replace(recOwnerFullName,'\'',''), recOwnerCO = Replace(recOwnerCO,'\'',''), ownerFullName = Replace(ownerFullName,'\'',''), ownerCO = Replace(ownerCO,'\'',''), ownerAddr1 = Replace(ownerAddr1,'\'','')";
		$result = mysqli_query($con,$query);
		//Response Text
		echo "<img src='images/ajax_loading.gif' height='20' /> 20. ".mysqli_affected_rows($con)." USE REPLACE quote";
		break;
	case 21:
		//Update US 5 Char Zip
		$query = "UPDATE fl_fla_master SET ownerZip = substring(ownerZip,1,5) WHERE ownerCountry = 'UNITED STATES'";
		$result = mysqli_query($con,$query);
		//Response Text
		echo "<img src='images/ajax_loading.gif' height='20' /> 20. ".mysqli_affected_rows($con)." REPLACE quote";
		break;
	default:
		echo "Error Processing...";
}

//Close Database Connection
include("dbclose.php");
?>