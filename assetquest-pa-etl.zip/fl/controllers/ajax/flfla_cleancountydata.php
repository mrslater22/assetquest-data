<?php
//Open Database Connection
include("flfladbopen.php");

//Clean Raw County Data
switch($_GET['pid']){
	case 0:
		//Update Null HOUSE_NO
		$query = "UPDATE fl_fla_pa SET HOUSE_NO = '0' WHERE HOUSE_NO IS NULL OR HOUSE_NO = ''";
		$result = mysqli_query($con,$query);
		//Response Text
		echo "<img src='images/ajax_loading.gif' height='20' /> HOUSE_NO Updated NULL";
		break;
	case 1:
		//Update Null STREET
		$query = "UPDATE fl_fla_pa SET STREET = 'NULL' WHERE STREET IS NULL OR STREET = ''";
		$result = mysqli_query($con,$query);
		//Response Text
		echo "<img src='images/ajax_loading.gif' height='20' /> STREET Updated NULL";
		break;
	case 2:
		//Update Null ST_MD
		$query = "UPDATE fl_fla_pa SET ST_MD = 'NULL' WHERE ST_MD IS NULL OR ST_MD = ''";
		$result = mysqli_query($con,$query);
		//Response Text
		echo "<img src='images/ajax_loading.gif' height='20' /> ST_MD Updated NULL";
		break;
	case 3:
		//Update Null ST_DIR
		$query = "UPDATE fl_fla_pa SET ST_DIR = 'NULL' WHERE ST_DIR IS NULL OR ST_DIR = ''";
		$result = mysqli_query($con,$query);
		//Response Text
		echo "<img src='images/ajax_loading.gif' height='20' /> ST_DIR Updated NULL";
		break;
	case 4:
		//Update Null ST_CITY
		$query = "UPDATE fl_fla_pa SET ST_CITY = 'NULL' WHERE ST_CITY IS NULL OR ST_CITY = ''";
		$result = mysqli_query($con,$query);
		//Response Text
		echo "<img src='images/ajax_loading.gif' height='20' /> ST_CITY Updated NULL";
		break;
	case 5:
		//Update Null ST_ZIP5
		$query = "UPDATE fl_fla_pa SET ST_ZIP5 = 'NULL' WHERE ST_ZIP5 IS NULL OR ST_ZIP5 = ''";
		$result = mysqli_query($con,$query);
		//Response Text
		echo "<img src='images/ajax_loading.gif' height='20' /> ST_ZIP5 Updated NULL";
		break;
	case 6:
		//Update Null SRCD1
		$query = "UPDATE fl_fla_pa SET SRCD1 = 'NULL' WHERE SRCD1 IS NULL OR SRCD1 = ''";
		$result = mysqli_query($con,$query);
		//Response Text
		echo "<img src='images/ajax_loading.gif' height='20' /> SRCD1 Updated NULL";
		break;
	case 7:
		//Update Null ADDRESS_1
		$query = "UPDATE fl_fla_pa SET ADDRESS_1 = 'NULL' WHERE ADDRESS_1 IS NULL OR ADDRESS_1 = ''";
		$result = mysqli_query($con,$query);
		//Response Text
		echo "<img src='images/ajax_loading.gif' height='20' /> ADDRESS_1 Updated NULL";
		break;
	case 8:
		//Update Null ADDRESS_2
		$query = "UPDATE fl_fla_pa SET ADDRESS_2 = 'NULL' WHERE ADDRESS_2 IS NULL OR ADDRESS_2 = ''";
		$result = mysqli_query($con,$query);
		//Response Text
		echo "<img src='images/ajax_loading.gif' height='20' /> ADDRESS_2 Updated NULL";
		break;
	case 9:
		//Update Null ADDRESS_3
		$query = "UPDATE fl_fla_pa SET ADDRESS_3 = 'NULL' WHERE ADDRESS_3 IS NULL OR ADDRESS_3 = ''";
		$result = mysqli_query($con,$query);
		//Response Text
		echo "<img src='images/ajax_loading.gif' height='20' /> ADDRESS_3 Updated NULL";
		break;
	case 10:
		//Update Null CITY_NAME
		$query = "UPDATE fl_fla_pa SET CITY_NAME = 'NULL' WHERE CITY_NAME IS NULL OR CITY_NAME = ''";
		$result = mysqli_query($con,$query);
		//Response Text
		echo "<img src='images/ajax_loading.gif' height='20' /> CITY_NAME Updated NULL";
		break;
	case 11:
		//Update Null ST
		$query = "UPDATE fl_fla_pa SET ST = 'NULL' WHERE CITY_NAME IS NULL OR ST = ''";
		$result = mysqli_query($con,$query);
		//Response Text
		echo "<img src='images/ajax_loading.gif' height='20' /> ST Updated NULL";
		break;
	case 12:
		//Update Null ZIPCODE
		$query = "UPDATE fl_fla_pa SET ZIPCODE = 'NULL' WHERE ZIPCODE IS NULL OR ZIPCODE = ''";
		$result = mysqli_query($con,$query);
		//Response Text
		echo "<img src='images/ajax_loading.gif' height='20' /> ZIPCODE Updated NULL";
		break;
	case 13:
		//Update Null CNTRY
		$query = "UPDATE fl_fla_pa SET CNTRY = 'UNITED STATES' WHERE CNTRY IS NULL OR CNTRY = ''";
		$result = mysqli_query($con,$query);
		//Response Text
		echo "<img src='images/ajax_loading.gif' height='20' /> CNTRY Updated UNITED STATES";
		break;
	case 14:
		//Update Null SALEDT1
		$query = "UPDATE fl_fla_pa SET SALEDT1 = '19000101' WHERE SALEDT1 IS NULL OR SALEDT1 = ''";
		$result = mysqli_query($con,$query);
		//Response Text
		echo "<img src='images/ajax_loading.gif' height='20' /> SALEDT1 Updated 19000101";
		break;
	default:
		echo "Error Processing...";
}

//Close Database Connection
include("dbclose.php");
?>