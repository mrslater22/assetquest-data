<?php
define('DB_CRM_HOST', 'flleedb.db.8618275.hostedresource.com');
define('DB_CRM_USER', 'flleedb');
define('DB_CRM_PASS', 'D8@bA53!');
define('DB_CRM_NAME', 'flleedb');
define('DB_CRM_ERROR', 'Error: Could not connect to the CRM database.');

$con = mysql_connect(DB_CRM_HOST,DB_CRM_NAME,DB_CRM_PASS);
$dbName = DB_CRM_NAME;
mysql_select_db($dbName, $con) or die(DB_CRM_ERROR);
?>