<?php
//ob
ob_start();

//session
session_start();

//Open Database Connection
include("dbopen.php");

//Get Current Quote Request Status
$query = "SELECT * FROM tbl_property WHERE propertyID = ".$_GET['propid'];
$result = mysql_query($query);
$rcount = mysql_num_rows($result);
$row = mysql_fetch_assoc($result);

if($row['quoteReq']==1){	
	$query = "UPDATE tbl_property SET quoteReq = 0 WHERE propertyID = ".$_GET['propid'];
	mysql_query($query);
}else{
	$query = "UPDATE tbl_property SET quoteReq = 1 WHERE propertyID = ".$_GET['propid'];
	mysql_query($query);
}

include("dbclose.php");
?>