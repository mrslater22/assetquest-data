<?php
//ob
ob_start();

//session
session_start();

//Open Database Connection
include("dbopen.php");

//Update Property
$query = "SELECT evalDate FROM tbl_propEval WHERE propertyID = ".$_GET['propid']." ORDER BY evalDate DESC LIMIT 1";
$result = mysql_query($query);
$row = mysql_fetch_assoc($result);
$rcount = mysql_num_rows($result);
if($rcount>0){
?>
Eval Prices Last Updated: <?php echo date("m/d/Y",strtotime($row['evalDate'])); ?>
<?php
}
include("dbclose.php");
?>