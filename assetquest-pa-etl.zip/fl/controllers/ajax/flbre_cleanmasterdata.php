<?php
//Open Database Connection
include("flbredbopen.php");

//Clean Master Data
switch($_GET['pid']){
	case 0:
		//Update SUBAREA CODES
		$query = "UPDATE fl_bre_master LEFT JOIN subarea_codes ON (fl_bre_master.siteSubArea = subarea_codes.siteSubArea) AND (fl_bre_master.siteCounty = subarea_codes.siteCounty) AND (fl_bre_master.siteState = subarea_codes.siteState) SET fl_bre_master.siteSubAreaCode = subarea_codes.siteSubAreaCode";
		$result = mysqli_query($con,$query);
		//Response Text
		echo "<img src='images/ajax_loading.gif' height='20' /> 0. ".mysqli_affected_rows($con)." SUBAREA CODES UPDATED";
		break;
	case 1:
		//Update CITY CODES
		$query = "UPDATE fl_bre_master LEFT JOIN city_codes ON (fl_bre_master.siteCity = city_codes.siteCity) AND (fl_bre_master.siteCounty = city_codes.siteCounty) AND (fl_bre_master.siteState = city_codes.siteState) SET fl_bre_master.siteCityCode = city_codes.siteCityCode";
		$result = mysqli_query($con,$query);
		//Response Text
		echo "<img src='images/ajax_loading.gif' height='20' /> 1. ".mysqli_affected_rows($con)." CITY CODES UPDATED";
		break;
	case 2:
		//Add Site Units
		$query = "UPDATE fl_bre_master BM INNER JOIN fl_bre_unit_subarea BUS ON BM.STRAP = BUS.parcelID2 SET BM.siteUnit = BUS.siteUnit WHERE BUS.siteAddress != ' '";
		$result = mysqli_query($con,$query);
		//Response Text
		echo "<img src='images/ajax_loading.gif' height='20' /> 7. ".mysqli_affected_rows($con)." Site Units Added";
		break;
	case 3:
		//Update UNIT CODES
		$query = "UPDATE fl_bre_master INNER JOIN unit_codes ON (fl_bre_master.siteState = unit_codes.siteState) AND (fl_bre_master.siteCounty = unit_codes.siteCounty) AND (fl_bre_master.siteCity = unit_codes.siteCity) AND (fl_bre_master.siteUnit = unit_codes.siteUnit) SET fl_bre_master.siteUnitCode = unit_codes.siteUnitCode";
		$result = mysqli_query($con,$query);
		//Response Text
		echo "<img src='images/ajax_loading.gif' height='20' /> 2. ".mysqli_affected_rows($con)." UNIT CODES UPDATED";
		break;
	case 4:
		//Update LOT TYPE CODES
		$query = "UPDATE fl_bre_master LEFT JOIN lot_type_codes ON (fl_bre_master.siteCounty = lot_type_codes.siteCounty) AND (fl_bre_master.siteState = lot_type_codes.siteState) AND (fl_bre_master.siteLotType = lot_type_codes.siteLotType) SET fl_bre_master.siteLotTypeCode = lot_type_codes.siteLotTypeCode";
		$result = mysqli_query($con,$query);
		//Response Text
		echo "<img src='images/ajax_loading.gif' height='20' /> 3. ".mysqli_affected_rows($con)." LOT TYPE CODES UPDATED";
		break;
	case 5:
		//Update USE TYPE CODES
		$query = "UPDATE fl_bre_master INNER JOIN use_type_codes ON fl_bre_master.landUseCode = use_type_codes.landUseTypeCode SET fl_bre_master.siteUseType = use_type_codes.siteUseType, fl_bre_master.siteUseTypeCode = use_type_codes.siteUseTypeCode";
		$result = mysqli_query($con,$query);
		//Response Text
		echo "<img src='images/ajax_loading.gif' height='20' /> 4. ".mysqli_affected_rows($con)." USE TYPE CODES UPDATED";
		break;
	case 6:
		//Update REPLACE &
		$query = "UPDATE fl_bre_master SET recOwnerFullName = Replace(recOwnerFullName,'&','+'), recOwnerCO = Replace(recOwnerCO,'&','+'), ownerFullName = Replace(ownerFullName,'&','+'), ownerCO = Replace(ownerCO,'&','+'), ownerAddr1 = Replace(ownerAddr1,'&','+')";
		$result = mysqli_query($con,$query);
		//Response Text
		echo "<img src='images/ajax_loading.gif' height='20' /> 5. ".mysqli_affected_rows($con)." USE REPLACE '&'";
		break;
	case 7:
		//Update REPLACE quote
		$query = "UPDATE fl_bre_master SET recOwnerFullName = Replace(recOwnerFullName,'\'',''), recOwnerCO = Replace(recOwnerCO,'\'',''), ownerFullName = Replace(ownerFullName,'\'',''), ownerCO = Replace(ownerCO,'\'',''), ownerAddr1 = Replace(ownerAddr1,'\'','')";
		$result = mysqli_query($con,$query);
		//Response Text
		echo "<img src='images/ajax_loading.gif' height='20' /> 6. ".mysqli_affected_rows($con)." USE REPLACE quote";
		break;
	case 8:
		//Update US 5 Char Zip
		$query = "UPDATE fl_bre_master SET ownerZip = substring(ownerZip,1,5) WHERE ownerCountry = 'UNITED STATES'";
		$result = mysqli_query($con,$query);
		//Response Text
		echo "<img src='images/ajax_loading.gif' height='20' /> 7. ".mysqli_affected_rows($con)." REPLACE quote";
		break;
	default:
		echo "Error Processing...";
}

//Close Database Connection
include("dbclose.php");
?>