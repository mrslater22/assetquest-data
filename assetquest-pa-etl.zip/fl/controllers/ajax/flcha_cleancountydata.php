<?php
//Open Database Connection
include("flchadbopen.php");

//Clean Raw County Data
switch($_GET['pid']){
	case 0:	
		//Update Null ownerName
		$query = "UPDATE fl_cha_pa SET ownerName = 'NULL' WHERE ownerName IS NULL OR ownerName = ''";
		$result = mysqli_query($con,$query);
		//Response Text
		echo "<img src='images/ajax_loading.gif' height='20' /> ownerName Updated NULL";
		break;
	case 1:
		//Update Null ownerName2
		$query = "UPDATE fl_cha_pa SET ownerName2 = 'NULL' WHERE ownerName2 IS NULL OR ownerName2 = ''";
		$result = mysqli_query($con,$query);
		//Response Text
		echo "<img src='images/ajax_loading.gif' height='20' /> ownerName2 Updated NULL";
		break;
	case 2:
		//Update Null ownerSuite
		$query = "UPDATE fl_cha_pa SET ownerSuite = 'NULL' WHERE ownerSuite IS NULL OR ownerSuite = ''";
		$result = mysqli_query($con,$query);
		//Response Text
		echo "<img src='images/ajax_loading.gif' height='20' /> ownerSuite Updated NULL";
		break;
	case 3:
		//Update Null ownerAddr
		$query = "UPDATE fl_cha_pa SET ownerAddr = 'NULL' WHERE ownerAddr IS NULL OR ownerAddr = ''";
		$result = mysqli_query($con,$query);
		//Response Text
		echo "<img src='images/ajax_loading.gif' height='20' /> ownerAddr Updated NULL";
		break;
	case 4:
		//Update Null ownerCity
		$query = "UPDATE fl_cha_pa SET ownerCity = 'NULL' WHERE ownerCity IS NULL OR ownerCity = ''";
		$result = mysqli_query($con,$query);
		//Response Text
		echo "<img src='images/ajax_loading.gif' height='20' /> ownerCity Updated NULL";
		break;
	case 5:
		//Update Null ownerState
		$query = "UPDATE fl_cha_pa SET ownerState = 'NULL' WHERE ownerState IS NULL OR ownerState = ''";
		$result = mysqli_query($con,$query);
		//Response Text
		echo "<img src='images/ajax_loading.gif' height='20' /> ownerState Updated NULL";
		break;
	case 6:
		//Update Null ownerCountry
		$query = "UPDATE fl_cha_pa SET ownerCountry = 'NULL' WHERE ownerCountry IS NULL OR ownerCountry = ''";
		$result = mysqli_query($con,$query);
		//Response Text
		echo "<img src='images/ajax_loading.gif' height='20' /> ownerCountry Updated NULL";
		break;
	case 7:
		//Update Null ownerZipCode
		$query = "UPDATE fl_cha_pa SET ownerZipCode = 'NULL' WHERE ownerZipCode IS NULL OR ownerZipCode = ''";
		$result = mysqli_query($con,$query);
		//Response Text
		echo "<img src='images/ajax_loading.gif' height='20' /> ownerZipCode Updated NULL";
		break;
	case 8:
		//Update Null siteStreetNum
		$query = "UPDATE fl_cha_pa SET siteStreetNum = '0' WHERE siteStreetNum IS NULL OR siteStreetNum = ''";
		$result = mysqli_query($con,$query);
		//Response Text
		echo "<img src='images/ajax_loading.gif' height='20' /> siteStreetNum Updated 0";
		break;
	case 9:
		//Update Null siteStreetName
		$query = "UPDATE fl_cha_pa SET siteStreetName = 'NULL' WHERE siteStreetName IS NULL OR siteStreetName = ''";
		$result = mysqli_query($con,$query);
		//Response Text
		echo "<img src='images/ajax_loading.gif' height='20' /> siteStreetName Updated NULL";
		break;
	case 10:
		//Update Null businessAddr
		$query = "UPDATE fl_cha_pa SET businessAddr = 'NULL' WHERE businessAddr IS NULL OR businessAddr = ''";
		$result = mysqli_query($con,$query);
		//Response Text
		echo "<img src='images/ajax_loading.gif' height='20' /> businessAddr Updated NULL";
		break;
	case 11:
		//Update Null qualified
		$query = "UPDATE fl_cha_pa SET qualified = 'NULL' WHERE qualified IS NULL OR qualified = ''";
		$result = mysqli_query($con,$query);
		//Response Text
		echo "<img src='images/ajax_loading.gif' height='20' /> qualified Updated NULL";
		break;
	case 12:
		//Update Null code
		$query = "UPDATE fl_cha_pa SET code = 'NULL' WHERE code IS NULL OR code = ''";
		$result = mysqli_query($con,$query);
		//Response Text
		echo "<img src='images/ajax_loading.gif' height='20' /> code Updated NULL";
		break;
	case 13:
		//Update Null oRecBook
		$query = "UPDATE fl_cha_pa SET oRecBook = 'NULL' WHERE oRecBook IS NULL OR oRecBook = ''";
		$result = mysqli_query($con,$query);
		//Response Text
		echo "<img src='images/ajax_loading.gif' height='20' /> oRecBook Updated NULL";
		break;
	case 14:
		//Update Null oRecPage
		$query = "UPDATE fl_cha_pa SET oRecPage = 'NULL' WHERE oRecPage IS NULL OR oRecPage = ''";
		$result = mysqli_query($con,$query);
		//Response Text
		echo "<img src='images/ajax_loading.gif' height='20' /> oRecPage Updated NULL";
		break;
	case 15:
		//Update Null qualified2
		$query = "UPDATE fl_cha_pa SET qualified2 = 'NULL' WHERE qualified2 IS NULL OR qualified2 = ''";
		$result = mysqli_query($con,$query);
		//Response Text
		echo "<img src='images/ajax_loading.gif' height='20' /> qualified2 Updated NULL";
		break;
	case 16:
		//Update Null code2
		$query = "UPDATE fl_cha_pa SET code2 = 'NULL' WHERE code2 IS NULL OR code2 = ''";
		$result = mysqli_query($con,$query);
		//Response Text
		echo "<img src='images/ajax_loading.gif' height='20' /> code2 Updated NULL";
		break;
	case 17:
		//Update Null oRecBook2
		$query = "UPDATE fl_cha_pa SET oRecBook2 = 'NULL' WHERE oRecBook2 IS NULL OR oRecBook2 = ''";
		$result = mysqli_query($con,$query);
		//Response Text
		echo "<img src='images/ajax_loading.gif' height='20' /> oRecBook2 Updated NULL";
		break;
	case 18:
		//Update Null oRecPage2
		$query = "UPDATE fl_cha_pa SET oRecPage2 = 'NULL' WHERE oRecPage2 IS NULL OR oRecPage2 = ''";
		$result = mysqli_query($con,$query);
		//Response Text
		echo "<img src='images/ajax_loading.gif' height='20' /> oRecPage2 Updated NULL";
		break;
	case 19:
		//Update Null yearPoolBuilt
		$query = "UPDATE fl_cha_pa SET yearPoolBuilt = 'NULL' WHERE yearPoolBuilt IS NULL OR yearPoolBuilt = ''";
		$result = mysqli_query($con,$query);
		//Response Text
		echo "<img src='images/ajax_loading.gif' height='20' /> yearPoolBuilt Updated NULL";
		break;
	case 20:
		//Update Null buildUseCode
		$query = "UPDATE fl_cha_pa SET buildUseCode = 'NULL' WHERE buildUseCode IS NULL OR buildUseCode = ''";
		$result = mysqli_query($con,$query);
		//Response Text
		echo "<img src='images/ajax_loading.gif' height='20' /> buildUseCode Updated NULL";
		break;
	case 21:
		//Update 0 buildUseCode2
		$query = "UPDATE fl_cha_pa SET buildUseCode2 = '0' WHERE buildUseCode2 IS NULL OR buildUseCode2 = ''";
		$result = mysqli_query($con,$query);
		//Response Text
		echo "<img src='images/ajax_loading.gif' height='20' /> buildUseCode2 Updated 0";
		break;
	case 22:
		//Update 0 buildUseCode3
		$query = "UPDATE fl_cha_pa SET buildUseCode3 = '0' WHERE buildUseCode3 IS NULL OR buildUseCode3 = ''";
		$result = mysqli_query($con,$query);
		//Response Text
		echo "<img src='images/ajax_loading.gif' height='20' /> buildUseCode3 Updated 0";
		break;
	case 23:
		//Update 0 totalBuildArea
		$query = "UPDATE fl_cha_pa SET totalBuildArea = '0' WHERE totalBuildArea IS NULL OR totalBuildArea = ''";
		$result = mysqli_query($con,$query);
		//Response Text
		echo "<img src='images/ajax_loading.gif' height='20' /> totalBuildArea Updated 0";
		break;
	case 24:
		//Update ownerCountry US
		$query = "UPDATE fl_cha_pa JOIN us_states ON fl_cha_pa.ownerState = us_states.abv SET fl_cha_pa.ownerCountry = 'UNITED STATES'";
		$result = mysqli_query($con,$query);
		//Response Text
		echo "<img src='images/ajax_loading.gif' height='20' /> ownerCountry Updated UNITED STATES";
		break;
	case 25:
		//Update REPLACE OWNER quote
		$query = "UPDATE fl_cha_pa SET ownerName = Replace(ownerName,'\'',''), ownerName2 = Replace(ownerName2,'\'',''), ownerAddr = Replace(ownerAddr,'\'','')";
		$result = mysqli_query($con,$query);
		//Response Text
		echo "<img src='images/ajax_loading.gif' height='20' /> 20. ".mysql_affected_rows()." REPLACE OWNER quote";
		break;
	default:
		echo "Error Processing...";
}

//Close Database Connection
include("dbclose.php");
?>