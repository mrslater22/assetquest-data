<?php
//ob
ob_start();

//session
session_start();

//Open Database Connection
include("dbopen.php");

//Update Property
$query = "SELECT mvID, maID, ".$_GET['fieldName']." AS mvPrice, mvDate FROM tbl_marketValue WHERE maID = ".$_GET['maid']." ORDER BY mvDate DESC LIMIT 1";
$result = mysql_query($query);
$row = mysql_fetch_assoc($result);
$rcount = mysql_num_rows($result);
if($rcount>0){
	if($_GET['fieldName']=="marketValue"){
?>
<div id="marketValue1" style="display:block;" onclick="divActionGroup(2,'marketValue',2); document.getElementById('marketValue').focus();"><h4>$<?php echo number_format($row['mvPrice'],0); ?></h4></div>
<div id="marketValue2" style="display:none; margin-top:12px;"><input type="text" id="marketValue" name="marketValue" value="<?php echo number_format($row['mvPrice'],0,"",""); ?>" onblur="divActionGroup(2,'marketValue',1);" onchange="updateMV(<?php echo $row['mvID']; ?>,<?php echo $row['maID']; ?>,'<?php echo $row['mvDate']; ?>','marketValue',this.value,<?php echo $_GET['uid']; ?>);" style="padding:0px; margin:0px; background-color: #f2f2f2; border:0px; height:30px; width:100%; font-size:24px; font-weight:bold;" /></div>
<?php
	}else{
?>
<div id="<?php echo $_GET['fieldName']; ?>1" style="display:block;" onclick="divActionGroup(2,'<?php echo $_GET['fieldName']; ?>',2); document.getElementById('<?php echo $_GET['fieldName']; ?>').focus();">$<?php echo number_format($row['mvPrice'],0); ?></div>
<div id="<?php echo $_GET['fieldName']; ?>2" style="display:none;"><input type="text" id="<?php echo $_GET['fieldName']; ?>" name="<?php echo $_GET['fieldName']; ?>" value="<?php echo number_format($row['mvPrice'],0,"",""); ?>" onblur="divActionGroup(2,'<?php echo $_GET['fieldName']; ?>',1);" onchange="updateMV(<?php echo $row['mvID']; ?>,<?php echo $row['maID']; ?>,'<?php echo $row['mvDate']; ?>','<?php echo $_GET['fieldName']; ?>',this.value,<?php echo $_GET['uid']; ?>);" style="padding:0px; margin:0px; background-color: #f2f2f2; border:0px; height:18px; width:100%; font-size:12px; text-align:center;" /></div>
<?php
	}
}
include("dbclose.php");
?>