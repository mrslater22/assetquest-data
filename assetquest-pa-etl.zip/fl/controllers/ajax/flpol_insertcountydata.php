<?php
//Open Database Connection
include("flpoldbopen.php");

$loopcount = 0;

//Insert Raw County Data
$query = "SELECT * FROM fl_pol_pa WHERE is_processed = 0 LIMIT 10000";
$result = mysql_query($query);
while($row = mysql_fetch_assoc($result)) {
	$parcelID = "score_".trim($row['pin']);
	$countyKey = "score_".trim($row['pin']);
	$strap = "score_".trim($row['pin']);
	$landUseCode = $row['lusedor'];
	$landUseDesc = $row['lusedor_d'];
	$numUnits = 1;
	$frontage = 0;
	$depth = 0;
	$gisAcres = $row['acres_gis'];
	$zoning = $row['zoning'];
	$zoningArea = 'NONE';
	$siteNumber = 'NONE';
	$siteStreet = 'NONE';
	$siteAddress = $row['s_address'];
	$siteCity = $row['s_city'];
	$siteState = "FLORIDA";
	$siteZip = $row['s_zipcode'];
	$siteCounty = "POLK";
	$siteSubArea = "NONE";
	$siteUnit = "NONE";
	$siteLotType = 'NONE';
	$siteStateCode = "FL";
	$siteCountyCode = "POL";
	$siteCityCode = "NON";
	$siteSubAreaCode = "NON";
	$siteUnitCode = "NON";
	$siteLotTypeCode = "NON";
	$siteUseTypeCode = "NON";
	$siteSizeCode = "000";
	$yearBuilt = $row['yrblt_act'];
	$sfTotal = $row['sqft_tot'];
	$sfUA = $row['sqft_htd'];
	$beds = $row['num_bed'];
	$baths = $row['num_bath'];
	$garage = 0;
	$carport = 0;
	$pool = 0;
	$boatdock = 0;
	$seawall = 0;
	$assessedValue = $row['assd_tot'];
	$recOwnerFullName = $row['o_name1'];
	$recOwnerCO = $row['o_name2'];
	$ownerFullName = $row['o_name1'];
	$ownerCO = $row['o_name2'];
	$ownerAddr1 = $row['o_address1'];
	$ownerAddr2 = $row['o_address2'];
	$ownerCity = $row['o_city'];
	$ownerState = $row['o_state'];
	$ownerZip = $row['o_zipcode'];
	$ownerCountry = $row['o_country'];
	$saleDate = date($row['sale1_date']);
	$saleAmt = $row['sale1_amt'];
	$saleTC = 0;
	
	//Concatinate Legal Description
	if($row['legal6']<>''||!null($row['legal6'])){
		if($row['legal5']<>''||!null($row['legal5'])){
			if($row['legal4']<>''||!null($row['legal4'])){
				if($row['legal3']<>''||!null($row['legal3'])){
					if($row['legal2']<>''||!null($row['legal2'])){
						$legalDesc = trim($row['legal1'])." ".trim($row['legal2'])." ".trim($row['legal3'])." ".trim($row['legal4'])." ".trim($row['legal5'])." ".trim($row['legal6']);
					}else{
						$legalDesc = trim($row['legal1'])." ".trim($row['legal2'])." ".trim($row['legal3'])." ".trim($row['legal4'])." ".trim($row['legal5']);
					}
				}else{
					$legalDesc = trim($row['legal1'])." ".trim($row['legal2'])." ".trim($row['legal3'])." ".trim($row['legal4']);
				}
			}else{
				$legalDesc = trim($row['legal1'])." ".trim($row['legal2'])." ".trim($row['legal3']);
			}
		}else{
			$legalDesc = trim($row['legal1'])." ".trim($row['legal2']);
		}
	}else{
		$legalDesc = trim($row['legal1']);
	}
	
	$legalDesc2 = 'NONE';
	$parcelID2 = $row['pin'];
	$strap2 = $row['pin'];
	$legalDesc30 = substr($legalDesc,0,30);

	$iQuery = "INSERT INTO fl_pol_master (parcelID,countyKey,strap,landUseCode,landUseDesc,numUnits,frontage,depth,gisAcres,zoning,zoningArea,siteNumber,siteStreet,siteAddress,siteCity,siteState,siteZip,siteCounty,siteSubArea,siteUnit,siteLotType,siteStateCode,siteCountyCode,siteCityCode,siteSubAreaCode,siteUnitCode,siteLotTypeCode,siteUseTypeCode,siteSizeCode,yearBuilt,sfTotal,sfUA,beds,baths,garage,carport,pool,boatdock,seawall,assessedValue,recOwnerFullName,recOwnerCO,ownerFullName,ownerCO,ownerAddr1,ownerAddr2,ownerCity,ownerState,ownerZip,ownerCountry,saleDate,saleAmt,legalDesc,legalDesc2,parcelID2,strap2,legalDesc30,saleTC) VALUES ('".$parcelID."','".$countyKey."','".$strap."','".$landUseCode."','".$landUseDesc."',".$numUnits.",".$frontage.",".$depth.",".$gisAcres.",'".$zoning."','".$zoningArea."','".$siteNumber."','".$siteStreet."','".$siteAddress."','".$siteCity."','".$siteState."','".$siteZip."','".$siteCounty."','".$siteSubArea."','".$siteUnit."','".$siteLotType."','".$siteStateCode."','".$siteCountyCode."','".$siteCityCode."','".$siteSubAreaCode."','".$siteUnitCode."','".$siteLotTypeCode."','".$siteUseTypeCode."','".$siteSizeCode."',".$yearBuilt.",".$sfTotal.",".$sfUA.",".$beds.",".$baths.",".$garage.",".$carport.",".$pool.",".$boatdock.",".$seawall.",".$assessedValue.",'".$recOwnerFullName."','".$recOwnerCO."','".$ownerFullName."','".$ownerCO."','".$ownerAddr1."','".$ownerAddr2."','".$ownerCity."','".$ownerState."','".$ownerZip."','".$ownerCountry."','".$saleDate."',".$saleAmt.",'".$legalDesc."','".$legalDesc2."','".$parcelID2."','".$strap2."','".$legalDesc30."','".$saleTC."')";
	$iResult = mysql_query($iQuery);

	$uQuery = "UPDATE fl_pol_pa SET is_processed = 1 WHERE pin = '".$row['pin']."'";
	$uResult = mysql_query($uQuery);

	$loopcount++;
}

//Check Raw County Data Not Processed
$cQuery = "SELECT * FROM fl_pol_pa WHERE is_processed = 0";
$cResult = mysql_query($cQuery);
$rcount = mysql_num_rows($cResult);

//Response Text
echo $rcount;

//Close Database Connection
include("dbclose.php");
?>