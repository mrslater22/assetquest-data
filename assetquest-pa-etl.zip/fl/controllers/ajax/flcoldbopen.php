<?php
define('DB_CRM_HOST', 'flcoldb.db.8618275.27a.hostedresource.net');
define('DB_CRM_USER', 'flcoldb');
define('DB_CRM_PASS', 'D8@bA53!');
define('DB_CRM_NAME', 'flcoldb');
define('DB_CRM_ERROR', 'Error: Could not connect to the CRM database.');

$con = mysqli_connect(DB_CRM_HOST,DB_CRM_USER,DB_CRM_PASS,DB_CRM_NAME);
if (!$con) {
    echo "Error: Unable to connect to MySQL." . PHP_EOL;
    echo "Debugging errno: " . mysqli_connect_errno() . PHP_EOL;
    echo "Debugging error: " . mysqli_connect_error() . PHP_EOL;
    exit;
}
?>