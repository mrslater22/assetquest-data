<?php
//Open Database Connection
include("flsardbopen.php");

//Clean Master Data
switch($_GET['pid']){
	case 0:	
		//Update UNITS
		$query = "UPDATE fl_sar_master SET siteUnit = Trim(Mid(legalDesc,InStr(legalDesc,'ADD TO')-5,4)) WHERE legalDesc Like '%ADD TO%'";
		$result = mysqli_query($con,$query);
		//Response Text
		echo "<img src='images/ajax_loading.gif' height='20' /> 0. ".mysqli_affected_rows($con)." UNITS UPDATED";
		break;
	case 1:
		//Update 11TH UNIT
		$query = "UPDATE fl_sar_master SET siteUnit = '11TH' WHERE legalDesc Like '%11 TH ADD TO PO%'";
		$result = mysqli_query($con,$query);
		//Response Text
		echo "<img src='images/ajax_loading.gif' height='20' /> 1. ".mysqli_affected_rows($con)." 11TH UNIT UPDATED";
		break;
	case 2:
		//Update 51ST UNIT
		$query = "UPDATE fl_sar_master SET siteUnit = '51ST' WHERE legalDesc Like '%51 ST ADD %'";
		$result = mysqli_query($con,$query);
		//Response Text
		echo "<img src='images/ajax_loading.gif' height='20' /> 2. ".mysqli_affected_rows($con)." 51ST UNIT UPDATED";
		break;
	case 3:
		//Update LOT TYPE DRY, FRESHWATER, SALTWATER
		$query = "UPDATE fl_sar_master JOIN lot_type_codes ON fl_sar_master.legalDesc2 = lot_type_codes.GULFBAY SET fl_sar_master.siteLotType = lot_type_codes.siteLotType, fl_sar_master.siteLotTypeCode = lot_type_codes.siteLotTypeCode";
		$result = mysqli_query($con,$query);
		//Response Text
		echo "<img src='images/ajax_loading.gif' height='20' /> 3. ".mysqli_affected_rows($con)." LOT TYPES + LOT TYPE CODES UPDATED";
		break;
	case 4:
		//Update CITY CODES
		$query = "UPDATE fl_sar_master LEFT JOIN city_codes ON (fl_sar_master.siteCity = city_codes.siteCity) AND (fl_sar_master.siteCounty = city_codes.siteCounty) AND (fl_sar_master.siteState = city_codes.siteState) SET fl_sar_master.siteCityCode = city_codes.siteCityCode";
		$result = mysqli_query($con,$query);
		//Response Text
		echo "<img src='images/ajax_loading.gif' height='20' /> 4. ".mysqli_affected_rows($con)." CITY CODES UPDATED";
		break;
	case 5:
		//Update UNIT CODES
		$query = "UPDATE fl_sar_master INNER JOIN unit_codes ON (fl_sar_master.siteState = unit_codes.siteState) AND (fl_sar_master.siteCounty = unit_codes.siteCounty) AND (fl_sar_master.siteCity = unit_codes.siteCity) AND (fl_sar_master.siteUnit = unit_codes.siteUnit) SET fl_sar_master.siteUnitCode = unit_codes.siteUnitCode";
		$result = mysqli_query($con,$query);
		//Response Text
		echo "<img src='images/ajax_loading.gif' height='20' /> 5. ".mysqli_affected_rows($con)." UNIT CODES UPDATED";
		break;
	case 6:
		//Update USE TYPE CODES
		$query = "UPDATE fl_sar_master INNER JOIN use_type_codes ON fl_sar_master.landUseCode = use_type_codes.landUseTypeCode SET fl_sar_master.landUseDesc = use_type_codes.landUseTypeDesc, fl_sar_master.siteUseType = use_type_codes.siteUseType, fl_sar_master.siteUseTypeCode = use_type_codes.siteUseTypeCode";
		$result = mysqli_query($con,$query);
		//Response Text
		echo "<img src='images/ajax_loading.gif' height='20' /> 6. ".mysqli_affected_rows($con)." USE TYPES + USE TYPE CODES UPDATED";
		break;
	case 7:
		//Update REPLACE &
		$query = "UPDATE fl_sar_master SET recOwnerFullName = Replace(recOwnerFullName,'&','+'), recOwnerCO = Replace(recOwnerCO,'&','+'), ownerFullName = Replace(ownerFullName,'&','+'), ownerCO = Replace(ownerCO,'&','+'), ownerAddr1 = Replace(ownerAddr1,'&','+')";
		$result = mysqli_query($con,$query);
		//Response Text
		echo "<img src='images/ajax_loading.gif' height='20' /> 19. ".mysqli_affected_rows($con)." REPLACE '&'";
		break;
	case 8:
		//Update REPLACE quote
		$query = "UPDATE fl_sar_master SET recOwnerFullName = Replace(recOwnerFullName,'\'',''), recOwnerCO = Replace(recOwnerCO,'\'',''), ownerFullName = Replace(ownerFullName,'\'',''), ownerCO = Replace(ownerCO,'\'',''), ownerAddr1 = Replace(ownerAddr1,'\'','')";
		$result = mysqli_query($con,$query);
		//Response Text
		echo "<img src='images/ajax_loading.gif' height='20' /> 20. ".mysqli_affected_rows($con)." REPLACE quote";
		break;
	case 9:
		//Update US 5 Char Zip
		$query = "UPDATE fl_sar_master SET ownerZip = substring(ownerZip,1,5) WHERE ownerCountry = 'UNITED STATES'";
		$result = mysqli_query($con,$query);
		//Response Text
		echo "<img src='images/ajax_loading.gif' height='20' /> 20. ".mysqli_affected_rows($con)." REPLACE quote";
		break;
	default:
		echo "Error Processing...";
}

//Close Database Connection
include("dbclose.php");
?>