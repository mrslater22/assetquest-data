<?php
//Open Database Connection
include("flcoldbopen.php");

//Clean Raw County Data
switch($_GET['pid']){
	case 0:	
		//Update Null sitezip
		$query = "UPDATE fl_col_pa SET sitezip = 'NULL' WHERE sitezip IS NULL OR sitezip = ''";
		$result = mysqli_query($con,$query);
		//Response Text
		echo "<img src='images/ajax_loading.gif' height='20' /> sitezip Updated NULL";
		break;
	case 1:
		//Update Null name_1
		$query = "UPDATE fl_col_pa SET name_1 = 'NULL' WHERE name_1 IS NULL OR name_1 = ''";
		$result = mysqli_query($con,$query);
		//Response Text
		echo "<img src='images/ajax_loading.gif' height='20' /> name_1 Updated NULL";
		break;
	case 2:
		//Update Null name_2
		$query = "UPDATE fl_col_pa SET name_2 = 'NULL' WHERE name_2 IS NULL OR name_2 = ''";
		$result = mysqli_query($con,$query);
		//Response Text
		echo "<img src='images/ajax_loading.gif' height='20' /> name_2 Updated NULL";
		break;
	case 3:
		//Update Null name_3
		$query = "UPDATE fl_col_pa SET name_3 = 'NULL' WHERE name_3 IS NULL OR name_3 = ''";
		$result = mysqli_query($con,$query);
		//Response Text
		echo "<img src='images/ajax_loading.gif' height='20' /> name_3 Updated NULL";
		break;
	case 4:
		//Update Null name_4
		$query = "UPDATE fl_col_pa SET name_4 = 'NULL' WHERE name_4 IS NULL OR name_4 = ''";
		$result = mysqli_query($con,$query);
		//Response Text
		echo "<img src='images/ajax_loading.gif' height='20' /> name_4 Updated NULL";
		break;
	case 5:
		//Update Null name_5
		$query = "UPDATE fl_col_pa SET name_5 = 'NULL' WHERE name_5 IS NULL OR name_5 = ''";
		$result = mysqli_query($con,$query);
		//Response Text
		echo "<img src='images/ajax_loading.gif' height='20' /> name_5 Updated NULL";
		break;
	case 6:
		//Update Null legal_1
		$query = "UPDATE fl_col_pa SET legal_1 = 'NULL' WHERE legal_1 IS NULL OR legal_1 = ''";
		$result = mysqli_query($con,$query);
		//Response Text
		echo "<img src='images/ajax_loading.gif' height='20' /> legal_1 Updated NULL";
		break;
	case 7:
		//Update Null legal_2
		$query = "UPDATE fl_col_pa SET legal_2 = 'NULL' WHERE legal_2 IS NULL OR legal_2 = ''";
		$result = mysqli_query($con,$query);
		//Response Text
		echo "<img src='images/ajax_loading.gif' height='20' /> legal_2 Updated NULL";
		break;
	case 8:
		//Update Null legal_3
		$query = "UPDATE fl_col_pa SET legal_3 = 'NULL' WHERE legal_3 IS NULL OR legal_3 = ''";
		$result = mysqli_query($con,$query);
		//Response Text
		echo "<img src='images/ajax_loading.gif' height='20' /> legal_3 Updated NULL";
		break;
	case 9:
		//Update Null legal_4
		$query = "UPDATE fl_col_pa SET legal_4 = 'NULL' WHERE legal_4 IS NULL OR legal_4 = ''";
		$result = mysqli_query($con,$query);
		//Response Text
		echo "<img src='images/ajax_loading.gif' height='20' /> legal_4 Updated NULL";
		break;
	case 10:
		//Update Null str_name
		$query = "UPDATE fl_col_pa SET str_name = 'NULL' WHERE str_name IS NULL OR str_name = ''";
		$result = mysqli_query($con,$query);
		//Response Text
		echo "<img src='images/ajax_loading.gif' height='20' /> str_name Updated NULL";
		break;
	case 11:
		//Update Null str_type
		$query = "UPDATE fl_col_pa SET str_type = 'NULL' WHERE str_type IS NULL OR str_type = ''";
		$result = mysqli_query($con,$query);
		//Response Text
		echo "<img src='images/ajax_loading.gif' height='20' /> str_type Updated NULL";
		break;
	case 12:
		//Update Null str_ord
		$query = "UPDATE fl_col_pa SET str_ord = 'NULL' WHERE str_ord IS NULL OR str_ord = ''";
		$result = mysqli_query($con,$query);
		//Response Text
		echo "<img src='images/ajax_loading.gif' height='20' /> str_ord Updated NULL";
		break;
	case 13:
		//Update Null str_num
		$query = "UPDATE fl_col_pa SET str_num = 'NULL' WHERE str_num IS NULL OR str_num = ''";
		$result = mysqli_query($con,$query);
		//Response Text
		echo "<img src='images/ajax_loading.gif' height='20' /> str_num Updated NULL";
		break;
	case 14:
		//Update Null ownerName
		$query = "UPDATE fl_col_pa SET ownerName = 'NULL' WHERE ownerName IS NULL OR ownerName = ''";
		$result = mysqli_query($con,$query);
		//Response Text
		echo "<img src='images/ajax_loading.gif' height='20' /> ownerName Updated NULL";
		break;
	case 15:
		//Update Null ownerCO
		$query = "UPDATE fl_col_pa SET ownerCO = 'NULL' WHERE ownerCO IS NULL OR ownerCO = ''";
		$result = mysqli_query($con,$query);
		//Response Text
		echo "<img src='images/ajax_loading.gif' height='20' /> ownerCO Updated NULL";
		break;
	case 16:
		//Update Null ownerAddr1
		$query = "UPDATE fl_col_pa SET ownerAddr1 = 'NULL' WHERE ownerAddr1 IS NULL OR ownerAddr1 = ''";
		$result = mysqli_query($con,$query);
		//Response Text
		echo "<img src='images/ajax_loading.gif' height='20' /> ownerAddr1 Updated NULL";
		break;
	case 17:
		//Update Null ownerAddr2
		$query = "UPDATE fl_col_pa SET ownerAddr2 = 'NULL' WHERE ownerAddr2 IS NULL OR ownerAddr2 = ''";
		$result = mysqli_query($con,$query);
		//Response Text
		echo "<img src='images/ajax_loading.gif' height='20' /> ownerAddr2 Updated NULL";
		break;
	case 18:
		//Update Null legalDesc
		$query = "UPDATE fl_col_pa SET legalDesc = 'NULL' WHERE legalDesc IS NULL OR legalDesc = ''";
		$result = mysqli_query($con,$query);
		//Response Text
		echo "<img src='images/ajax_loading.gif' height='20' /> legalDesc Updated NULL";
		break;
	case 19:
		//Update 00 saleDateMonth
		$query = "UPDATE fl_col_pa SET saleDateMonth = '00' WHERE saleDateMonth IS NULL OR saleDateMonth = ''";
		$result = mysqli_query($con,$query);
		//Response Text
		echo "<img src='images/ajax_loading.gif' height='20' /> saleDateMonth Updated 00";
		break;
	case 20:
		//Update 00 saleDateDay
		$query = "UPDATE fl_col_pa SET saleDateDay = '00' WHERE saleDateDay IS NULL OR saleDateDay = ''";
		$result = mysqli_query($con,$query);
		//Response Text
		echo "<img src='images/ajax_loading.gif' height='20' /> saleDateDay Updated 00";
		break;
	case 21:
		//Update 0000 saleDateYear
		$query = "UPDATE fl_col_pa SET saleDateYear = '0000' WHERE saleDateYear IS NULL OR saleDateYear = ''";
		$result = mysqli_query($con,$query);
		//Response Text
		echo "<img src='images/ajax_loading.gif' height='20' /> saleDateYear Updated 0000";
		break;
	case 22:
		//Update Null siteSubArea
		$query = "UPDATE fl_col_pa SET siteSubArea = 'NULL' WHERE siteSubArea IS NULL OR siteSubArea = ''";
		$result = mysqli_query($con,$query);
		//Response Text
		echo "<img src='images/ajax_loading.gif' height='20' /> siteSubArea Updated NULL";
		break;
	case 23:
		//Update Null siteUnitStr
		$query = "UPDATE fl_col_pa SET siteUnitStr = 'NULL' WHERE siteUnitStr IS NULL OR siteUnitStr = ''";
		$result = mysqli_query($con,$query);
		//Response Text
		echo "<img src='images/ajax_loading.gif' height='20' /> siteUnitStr Updated NULL";
		break;
	case 24:
		//Update Null siteUnit
		$query = "UPDATE fl_col_pa SET siteUnit = 'NULL' WHERE siteUnit IS NULL OR siteUnit = ''";
		$result = mysqli_query($con,$query);
		//Response Text
		echo "<img src='images/ajax_loading.gif' height='20' /> siteUnit Updated NULL";
		break;
	case 25:
		//Update Null city
		$query = "UPDATE fl_col_pa SET city = 'NULL' WHERE city IS NULL OR city = ''";
		$result = mysqli_query($con,$query);
		//Response Text
		echo "<img src='images/ajax_loading.gif' height='20' /> city Updated NULL";
		break;
	case 26:
		//Update Null st
		$query = "UPDATE fl_col_pa SET st = 'NULL' WHERE st IS NULL OR st = ''";
		$result = mysqli_query($con,$query);
		//Response Text
		echo "<img src='images/ajax_loading.gif' height='20' /> st Updated NULL";
		break;
	case 27:
		//Update Null zip
		$query = "UPDATE fl_col_pa SET zip = 'NULL' WHERE zip IS NULL OR zip = ''";
		$result = mysqli_query($con,$query);
		//Response Text
		echo "<img src='images/ajax_loading.gif' height='20' /> zip Updated NULL";
		break;
	case 28:
		//Update Null plus4
		$query = "UPDATE fl_col_pa SET plus4 = 'NULL' WHERE plus4 IS NULL OR plus4 = ''";
		$result = mysqli_query($con,$query);
		//Response Text
		echo "<img src='images/ajax_loading.gif' height='20' /> plus4 Updated NULL";
		break;
	case 29:
		//Update Null ownerAddrCode
		$query = "UPDATE fl_col_pa SET ownerAddrCode = 'NULL' WHERE ownerAddrCode IS NULL OR ownerAddrCode = ''";
		$result = mysqli_query($con,$query);
		//Response Text
		echo "<img src='images/ajax_loading.gif' height='20' /> ownerAddrCode Updated NULL";
		break;
	case 30:
		//Update ownerAddrCode
		$query = "UPDATE fl_col_pa SET ownerAddrCode = If(name_5<>'NULL',5,If(name_4<>'NULL',If((((Left(name_4,1) REGEXP ('^[0-9]'))) Or (Left(name_4,6)='PO BOX')) And (Right(name_4,2)<>'FL'),4,34),If(name_3<>'NULL',If((((Left(name_3,1) REGEXP ('^[0-9]'))) Or (Left(name_3,6)='PO BOX')) And (Right(name_3,2)<>'FL'),3,23),2)))";
		$result = mysqli_query($con,$query);
		//Response Text
		echo "<img src='images/ajax_loading.gif' height='20' /> ownerAddrCode Updated";
		break;
	case 31:
		//Update ownerName, ownerCO, ownerAddr1, ownerAddr2
		$query = "UPDATE fl_col_pa SET ownerName = name_1, ownerCO = If(ownerAddrCode = '3' Or ownerAddrCode = '34' Or ownerAddrCode = '4' Or ownerAddrCode = '5',Trim(name_2),'NULL'), ownerAddr1 = If(ownerAddrCode='5',Trim(name_5),If(ownerAddrCode = '4',Trim(name_4),If((ownerAddrCode = '3') Or (ownerAddrCode = '34'),Trim(name_3),If((ownerAddrCode = '2') Or (ownerAddrCode = '23'),Trim(name_2),'NULL')))), ownerAddr2 = If(ownerAddrCode ='34',Trim(name_4),If(ownerAddrCode = '23',Trim(name_3),'NULL'))";
		$result = mysqli_query($con,$query);
		//Response Text
		echo "<img src='images/ajax_loading.gif' height='20' /> ownerName, ownerCO, ownerAddr1, ownerAddr2 Updated";
		break;
	case 32:
		//Update saleDateMonth, saleDateDay, saleDateYear
		$query = "UPDATE fl_col_pa SET saleDateMonth = Mid(sal1_dt,5,2), saleDateDay = Right(sal1_dt,2), saleDateYear = Left(sal1_dt,4) WHERE sal1_dt <> '00000000'";
		$result = mysqli_query($con,$query);
		//Response Text
		echo "<img src='images/ajax_loading.gif' height='20' /> saleDateMonth, saleDateDay, saleDateYear Updated";
		break;
	case 33:
		//Update legalDesc
		$query = "UPDATE fl_col_pa SET legalDesc = concat(legal_1,If(legal_2 <> 'NULL',concat(' ',legal_2),''),If(legal_3 <> 'NULL',concat(' ',legal_3),''),If(legal_4 <> 'NULL',concat(' ',legal_4),''))";
		$result = mysqli_query($con,$query);
		//Response Text
		echo "<img src='images/ajax_loading.gif' height='20' /> legalDesc Updated";
		break;
	case 34:
		//Update siteUnitStr
		$query = "UPDATE fl_col_pa SET siteUnitStr = trim(If(InStr(legalDesc,'UNIT ')>0,Mid(legalDesc,InStr(legalDesc,'UNIT ')+5,4),'NULL'))";
		$result = mysqli_query($con,$query);
		//Response Text
		echo "<img src='images/ajax_loading.gif' height='20' /> siteUnitStr Updated";
		break;
	case 35:
		//Update siteUnit	
		$query = "SELECT id,siteUnitStr FROM fl_col_pa WHERE siteUnitStr <> 'NULL'";
		$result = mysqli_query($con,$query);
		while($row = mysqli_fetch_array($result)) {
			$siteUnit = preg_replace('/[^0-9]+/', '', $row['siteUnitStr']);
			$query2 = "UPDATE fl_col_pa SET siteUnit = '".$siteUnit."' WHERE id = ".$row['id'];
			$result2 = mysqli_query($con,$query2);
			//echo $query2;
		}
		//Response Text
		echo "<img src='images/ajax_loading.gif' height='20' /> siteUnit Updated";
		break;
	case 36:
		//Update siteSubAreaStr
		$query = "UPDATE fl_col_pa SET siteSubAreaStr = If(InStr(legalDesc,'UNIT')>0,trim(Left(legalDesc,InStr(legalDesc,'UNIT')-1)),'NULL')";
		$result = mysqli_query($con,$query);
		//Response Text
		echo "<img src='images/ajax_loading.gif' height='20' /> siteSubAreaStr Updated";
		break;
	case 37:
		//Update siteSubArea
		$query = "UPDATE fl_col_pa JOIN subarea_codes ON fl_col_pa.siteSubAreaStr = subarea_codes.siteSubAreaStr SET fl_col_pa.siteSubArea = subarea_codes.siteSubArea";
		$result = mysqli_query($con,$query);
		//Response Text
		echo "<img src='images/ajax_loading.gif' height='20' /> siteSubAreaStr Updated";
		break;
	case 38:
		//Update remove ' from legalDesc
		$query = "UPDATE fl_col_pa SET legal_1 = REPLACE(legal_1, '\'', ' '), legal_2 = REPLACE(legal_2, '\'', ' '), legal_3 = REPLACE(legal_3, '\'', ' '), legal_4 = REPLACE(legal_4, '\'', ' '), legalDesc = REPLACE(legalDesc, '\'', ' ')";
		$result = mysqli_query($con,$query);
		//Response Text
		echo "<img src='images/ajax_loading.gif' height='20' /> legalDesc Updated";
		break;
	case 39:
		//Update remove ' from ownerName, ownerCO, ownerAddr1, ownerAddr2, city
		$query = "UPDATE fl_col_pa SET ownerName = REPLACE(ownerName, '\'', ' '), ownerCO = REPLACE(ownerCO, '\'', ' '), ownerAddr1 = REPLACE(ownerAddr1, '\'', ' '), ownerAddr2 = REPLACE(ownerAddr2, '\'', ' '), city = REPLACE(city, '\'', ' ')";
		$result = mysqli_query($con,$query);
		//Response Text
		echo "<img src='images/ajax_loading.gif' height='20' /> ownerName, ownerCO, ownerAddr1, ownerAddr2 Updated";
		break;
	case 40:
		//Update remove ' from str_name, siteSubArea, siteSubAreaStr
		$query = "UPDATE fl_col_pa SET str_name = REPLACE(str_name, '\'', ' '), siteSubArea = REPLACE(siteSubArea, '\'', ' '), siteSubAreaStr = REPLACE(siteSubAreaStr, '\'', ' ')";
		$result = mysqli_query($con,$query);
		//Response Text
		echo "<img src='images/ajax_loading.gif' height='20' /> siteSubArea, siteSubAreaStr Updated";
		break;
	case 41:
		//Update REPLACE &
		$query = "UPDATE fl_col_pa SET ownerName = Replace(ownerName,'&','+'), legalDesc = Replace(legalDesc,'&','+'), siteSubAreaStr = Replace(siteSubAreaStr,'&','+'), siteSubArea = Replace(siteSubArea,'&','+'), ownerCO = Replace(ownerCO,'&','+')";
		$result = mysqli_query($con,$query);
		//Response Text
		echo "<img src='images/ajax_loading.gif' height='20' /> 43. ".mysqli_affected_rows($con)." USE REPLACE '&'";
		break;
	case 42:
		//Update REPLACE %
		$query = "UPDATE fl_col_pa SET ownerName = Replace(ownerName,'%',''), ownerCO = Replace(ownerCO,'%','')";
		$result = mysqli_query($con,$query);
		//Response Text
		echo "<img src='images/ajax_loading.gif' height='20' /> 44. ".mysqli_affected_rows($con)." USE REPLACE '%'";
		break;
	case 43:
		//Update REPLACE =
		$query = "UPDATE fl_col_pa SET ownerName = Replace(ownerName,'=+',' +'), ownerCO = Replace(ownerCO,'=+',' +')";
		$result = mysqli_query($con,$query);
		//Response Text
		echo "<img src='images/ajax_loading.gif' height='20' /> 44. ".mysqli_affected_rows($con)." USE REPLACE '=+'";
		break;
	default:
		echo "Error Processing...";
}

//Close Database Connection
include("dbclose.php");
?>