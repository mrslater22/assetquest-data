<?php
//Open Database Connection
include("flchadbopen.php");

//Truncate Master
mysqli_query($con,'TRUNCATE TABLE fl_cha_master;');

//Response Text
echo "Done!";

//Close Database Connection
include("dbclose.php");
?>