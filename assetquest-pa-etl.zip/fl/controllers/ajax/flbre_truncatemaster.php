<?php
//Open Database Connection
include("flbredbopen.php");

//Truncate Master
mysqli_query($con,'TRUNCATE TABLE fl_bre_master;');

//Response Text
echo "Done!";

//Close Database Connection
include("dbclose.php");
?>