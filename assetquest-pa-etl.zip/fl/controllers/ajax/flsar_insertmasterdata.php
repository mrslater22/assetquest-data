<?php
//Open Database Connection
include("flsardbopen.php");

$loopcount = 0;

//Insert Raw County Data
$query = "SELECT * FROM fl_sar_pa WHERE is_processed = 0 LIMIT 1000";
$result = mysqli_query($con,$query);
while($row = mysqli_fetch_assoc($result)) {
	$parcelID = "score_".trim($row['ACCOUNT']);
	$countyKey = "score_".trim($row['ACCOUNT']);
	$strap = "score_".trim($row['ACCOUNT']);
	$landUseCode = trim($row['STCD']);
	$landUseDesc = 'NONE'; //Value Not Provided By County Parcel Data
	$numUnits = 1; //Value Not Provided By County Parcel Data
	$frontage = 0; //Value Not Provided By County Parcel Data
	$depth = 0; //Value Not Provided By County Parcel Data
	$gisAcres = 0; //Value Not Provided By County Parcel Data
	$zoning = trim($row['ZONING_1']);
	$zoningArea = trim($row['ZONING_2']);
	$siteNumber = trim($row['LOCN']);
	if(trim($row['LOCD'])<>'NULL'){
		$siteStreet = trim($row['LOCS'])." ".trim($row['LOCD']);
	}else{
		$siteStreet = trim($row['LOCS']);
	}
	if($siteNumber<>'0'){
		$siteAddress = $siteNumber." ".$siteStreet;
	}else{
		$siteAddress = $siteStreet;
	}
	$siteCity = trim($row['LOCCITY']);
	$siteState = "FLORIDA";
	$siteZip = trim($row['LOCZIP']);
	$siteCounty = "SARASOTA";
	$siteSubArea = "NONE";
	$siteUnit = "NONE";
	$siteLotType = "NONE";
	$siteStateCode = "FL";
	$siteCountyCode = "SAR";
	$siteCityCode = "NON";
	$siteSubAreaCode = "NON";
	$siteUnitCode = "NON";
	$siteLotTypeCode = "NON";
	$siteUseTypeCode = "NON";
	$siteSizeCode = "000";
	$yearBuilt = trim($row['YRBL']);
	$sfTotal = trim($row['GRND_AREA']);
	$sfUA = trim($row['LIVING']);
	$beds = trim($row['BEDR']);
	$baths = trim($row['BATH']);
	$garage = 0; //Value Not Provided By County Parcel Data
	$carport = 0; //Value Not Provided By County Parcel Data
	$pool = $row['POOL'];
	$boatdock = 0; //Value Not Provided By County Parcel Data
	$seawall = 0; //Value Not Provided By County Parcel Data
	$assessedValue = trim($row['ASSD']);
	if(trim($row['NAME_ADD2'])<>'NULL'){
		if(trim($row['NAME_ADD3'])<>'NULL'){
			$recOwnerFullName = trim($row['NAME1'])." + ".trim($row['NAME_ADD2'])." + ".trim($row['NAME_ADD3']);
		}else{
			$recOwnerFullName = trim($row['NAME1'])." + ".trim($row['NAME_ADD2']);
		}
	}else{
		$recOwnerFullName = trim($row['NAME1']);
	}
	if(trim($row['NAME_ADD5'])<>'NULL'){
		$recOwnerCO = trim($row['NAME_ADD4']);
		$ownerAddr1 = trim($row['NAME_ADD5']);
	}else{
		$recOwnerCO = "NULL";
		$ownerAddr1 = trim($row['NAME_ADD4']);
	}
	$ownerFullName = $recOwnerFullName;
	$ownerCO = $recOwnerCO;
	$ownerAddr2 = "NULL";
	$ownerCity = trim($row['CITY']);
	$ownerState = trim($row['STATE']);
	$ownerZip = trim($row['ZIP']);
	$ownerCountry = trim($row['COUNTRY']);
	$saleDate = date($row['SALE_DATE']);
	$saleAmt = trim($row['SALE_AMT']);
	$saleTC = trim($row['QUAL_CODE']);
	if(trim($row['LEGAL2'])<>'NULL'){
		if(trim($row['LEGAL3'])<>'NULL'){
			if(trim($row['LEGAL4'])<>'NULL'){
				$legalDesc = trim($row['LEGAL1'])." ".trim($row['LEGAL2'])." ".trim($row['LEGAL3'])." ".trim($row['LEGAL4']);
			}else{
				$legalDesc = trim($row['LEGAL1'])." ".trim($row['LEGAL2'])." ".trim($row['LEGAL3']);
			}
		}else{
			$legalDesc = trim($row['LEGAL1'])." ".trim($row['LEGAL2']);
		}
	}else{
		$legalDesc = trim($row['LEGAL1']);
	}	
	$legalDesc2 = trim($row['GULFBAY']);
	$parcelID2 = trim($row['ACCOUNT']);
	$strap2 = trim($row['ACCOUNT']);
	$legalDesc30 = substr($legalDesc,0,30);
	
	$iQuery = "INSERT INTO fl_sar_master (parcelID,countyKey,strap,landUseCode,landUseDesc,numUnits,frontage,depth,gisAcres,zoning,zoningArea,siteNumber,siteStreet,siteAddress,siteCity,siteState,siteZip,siteCounty,siteSubArea,siteUnit,siteLotType,siteStateCode,siteCountyCode,siteCityCode,siteSubAreaCode,siteUnitCode,siteLotTypeCode,siteUseTypeCode,siteSizeCode,yearBuilt,sfTotal,sfUA,beds,baths,garage,carport,pool,boatdock,seawall,assessedValue,recOwnerFullName,recOwnerCO,ownerFullName,ownerCO,ownerAddr1,ownerAddr2,ownerCity,ownerState,ownerZip,ownerCountry,saleDate,saleAmt,legalDesc,legalDesc2,parcelID2,strap2,legalDesc30,saleTC) VALUES ('".$parcelID."','".$countyKey."','".$strap."','".$landUseCode."','".$landUseDesc."',".$numUnits.",".$frontage.",".$depth.",".$gisAcres.",'".$zoning."','".$zoningArea."','".$siteNumber."','".$siteStreet."','".$siteAddress."','".$siteCity."','".$siteState."','".$siteZip."','".$siteCounty."','".$siteSubArea."','".$siteUnit."','".$siteLotType."','".$siteStateCode."','".$siteCountyCode."','".$siteCityCode."','".$siteSubAreaCode."','".$siteUnitCode."','".$siteLotTypeCode."','".$siteUseTypeCode."','".$siteSizeCode."',".$yearBuilt.",".$sfTotal.",".$sfUA.",".$beds.",".$baths.",".$garage.",".$carport.",".$pool.",".$boatdock.",".$seawall.",".$assessedValue.",'".$recOwnerFullName."','".$recOwnerCO."','".$ownerFullName."','".$ownerCO."','".$ownerAddr1."','".$ownerAddr2."','".$ownerCity."','".$ownerState."','".$ownerZip."','".$ownerCountry."','".$saleDate."',".$saleAmt.",'".$legalDesc."','".$legalDesc2."','".$parcelID2."','".$strap2."','".$legalDesc30."','".$saleTC."')";
	$iResult = mysqli_query($con,$iQuery);
	
	//echo $iQuery."<br />";
	
	$uQuery = "UPDATE fl_sar_pa SET is_processed = 1 WHERE ACCOUNT = '".$row['ACCOUNT']."'";
	$uResult = mysqli_query($con,$uQuery);
	
	$loopcount++;
}

//Check Raw County Data Not Processed
$cQuery = "SELECT * FROM fl_sar_pa WHERE is_processed = 0";
$cResult = mysqli_query($con,$cQuery);
$rcount = mysqli_num_rows($cResult);

//Response Text
echo $rcount;

//Close Database Connection
include("dbclose.php"); 
?>