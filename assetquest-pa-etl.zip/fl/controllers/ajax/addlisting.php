<?php
//ob
ob_start();

//session
session_start();

//Open Database Connection
include("dbopen.php");

//Check Listing
$qFind = "SELECT * FROM zlcom_listing WHERE fkID = ".$_GET['propid'];
$rFind = mysql_query($qFind);
$rcount = mysql_num_rows($rFind);
if($rcount==0){
	//Insert Listing
	$date = date('Y-m-d H:i:s');
	$query = "INSERT INTO zlcom_listing (fkID,typeID,modUID,modDate,createUID) VALUES (".$_GET['propid'].",1,".$_GET['uid'].",'".$date."',".$_GET['uid'].");";
	mysql_query($query);
	$listID = mysql_insert_id();
}else{
	$row = mysql_fetch_array($rFind);
	$listID = $row['listID'];
}
?>
<a href="/index.php?p=5&listid=<?php echo $listID; ?>"><span class="has-tip" data-width="150" title="View Listing Info"><img src="<?php echo $_GET['appUrl']; ?>/images/clipboard.png" width="16" height="16" border="0" /></span></a>
<?php
include("dbclose.php");
?>