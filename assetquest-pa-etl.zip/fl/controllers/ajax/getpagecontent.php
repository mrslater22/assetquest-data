<?php
include("dbopen.php");

$query = "SELECT * FROM zlcom_pagecontent WHERE contentID = ".$_GET['contentid'];
$result = mysql_query($query);
$row = mysql_fetch_assoc($result);
?>
<<??>?xml version="1.0" encoding="UTF-8"?>
<content>
	<contentID><?php echo $row['contentID']; ?></contentID>
    <pageID><?php echo $row['pageID']; ?></pageID>
    <pageURL><?php echo $row['pageURL']; ?></pageURL>
    <metaTitle><?php echo $row['metaTitle']; ?></metaTitle>
    <metaKey><?php echo $row['metaKey']; ?></metaKey>
    <metaDesc><?php echo $row['metaDesc']; ?></metaDesc>
    <pageHeader><?php echo $row['pageHeader']; ?></pageHeader>
	<pageContent><?php echo $row['pageContent']; ?></pageContent>
</content>
<?php
include("dbclose.php"); 
?>