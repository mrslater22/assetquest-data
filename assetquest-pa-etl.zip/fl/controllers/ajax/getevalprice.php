<?php
//ob
ob_start();

//session
session_start();

//Open Database Connection
include("dbopen.php");

//Update Property
$query = "SELECT evalID, propertyID, ".$_GET['fieldName']." AS evalPrice, evalDate FROM tbl_propEval WHERE propertyID = ".$_GET['propid']." ORDER BY evalDate DESC LIMIT 1";
$result = mysql_query($query);
$row = mysql_fetch_assoc($result);
$rcount = mysql_num_rows($result);
if($rcount>0){
?>
<div id="<?php echo $_GET['fieldName']; ?>1" style="display:block;" onclick="divActionGroup(2,'<?php echo $_GET['fieldName']; ?>',2); document.getElementById('<?php echo $_GET['fieldName']; ?>').focus();">$<?php echo number_format($row['evalPrice'],0); ?></div>
<div id="<?php echo $_GET['fieldName']; ?>2" style="display:none;"><input type="text" id="<?php echo $_GET['fieldName']; ?>" name="<?php echo $_GET['fieldName']; ?>" value="<?php echo number_format($row['evalPrice'],0,"",""); ?>" onblur="divActionGroup(2,'<?php echo $_GET['fieldName']; ?>',1);" onchange="updateEval(<?php echo $row['evalID']; ?>,<?php echo $row['propertyID']; ?>,'<?php echo $row['evalDate']; ?>','<?php echo $_GET['fieldName']; ?>',this.value,<?php echo $_GET['uid']; ?>);" style="padding:0px; margin:0px; background-color: #f2f2f2; border:0px; height:18px; width:100%; font-size:12px; text-align:center;" /></div>
<?php
}
include("dbclose.php");
?>