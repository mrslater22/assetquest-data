<?php
//Open Database Connection
include("flpoldbopen.php");

//Clean Master Data
switch($_GET['pid']){
	case 0:
		//Update UNIT + SUBAREA CODES
		$query = "UPDATE fl_pol_master OSCM LEFT JOIN fl_pol_unit_subarea USAC ON OSCM.strap2 = USAC.pin SET OSCM.siteSubArea = USAC.siteSubArea, OSCM.siteSubAreaCode = USAC.siteSubAreaCode, OSCM.siteUnit = USAC.siteUnit, OSCM.siteUnitCode = USAC.siteUnitCode";
		$result = mysqli_query($con,$query);
		//Response Text
		echo "<img src='images/ajax_loading.gif' height='20' /> 0. ".mysqli_affected_rows($con)." UNIT + SUBAREA CODES UPDATED";
		break;
	case 1:
		//Update CITY CODES
		$query = "UPDATE fl_pol_master LEFT JOIN city_codes ON (fl_pol_master.siteCity = city_codes.siteCity) AND (fl_pol_master.siteCounty = city_codes.siteCounty) AND (fl_pol_master.siteState = city_codes.siteState) SET fl_pol_master.siteCityCode = city_codes.siteCityCode";
		$result = mysqli_query($con,$query);
		//Response Text
		echo "<img src='images/ajax_loading.gif' height='20' /> 1. ".mysqli_affected_rows($con)." CITY CODES UPDATED";
		break;
	case 2:
		//Update LOT TYPE CODES
		$query = "UPDATE fl_pol_master LEFT JOIN lot_type_codes ON (fl_pol_master.siteCounty = lot_type_codes.siteCounty) AND (fl_pol_master.siteState = lot_type_codes.siteState) AND (fl_pol_master.siteLotType = lot_type_codes.siteLotType) SET fl_pol_master.siteLotTypeCode = lot_type_codes.siteLotTypeCode";
		$result = mysqli_query($con,$query);
		//Response Text
		echo "<img src='images/ajax_loading.gif' height='20' /> 3. ".mysqli_affected_rows($con)." LOT TYPE CODES UPDATED";
		break;
	case 3:
		//Update USE TYPE CODES
		$query = "UPDATE fl_pol_master INNER JOIN use_type_codes ON fl_pol_master.landUseCode = use_type_codes.landUseTypeCode SET fl_pol_master.siteUseType = use_type_codes.siteUseType, fl_pol_master.siteUseTypeCode = use_type_codes.siteUseTypeCode";
		$result = mysqli_query($con,$query);
		//Response Text
		echo "<img src='images/ajax_loading.gif' height='20' /> 4. ".mysqli_affected_rows($con)." USE TYPE CODES UPDATED";
		break;
	case 4:
		//Update REPLACE &
		$query = "UPDATE fl_pol_master SET recOwnerFullName = Replace(recOwnerFullName,'&','+'), recOwnerCO = Replace(recOwnerCO,'&','+'), ownerFullName = Replace(ownerFullName,'&','+'), ownerCO = Replace(ownerCO,'&','+'), ownerAddr1 = Replace(ownerAddr1,'&','+')";
		$result = mysqli_query($con,$query);
		//Response Text
		echo "<img src='images/ajax_loading.gif' height='20' /> 5. ".mysqli_affected_rows($con)." USE REPLACE '&'";
		break;
	case 5:
		//Update REPLACE quote
		$query = "UPDATE fl_pol_master SET recOwnerFullName = Replace(recOwnerFullName,'\'',''), recOwnerCO = Replace(recOwnerCO,'\'',''), ownerFullName = Replace(ownerFullName,'\'',''), ownerCO = Replace(ownerCO,'\'',''), ownerAddr1 = Replace(ownerAddr1,'\'','')";
		$result = mysqli_query($con,$query);
		//Response Text
		echo "<img src='images/ajax_loading.gif' height='20' /> 6. ".mysqli_affected_rows($con)." USE REPLACE quote";
		break;
	case 6:
		//Update US 5 Char Zip
		$query = "UPDATE fl_pol_master SET ownerZip = substring(ownerZip,1,5) WHERE ownerCountry = 'UNITED STATES'";
		$result = mysqli_query($con,$query);
		//Response Text
		echo "<img src='images/ajax_loading.gif' height='20' /> 7. ".mysqli_affected_rows($con)." REPLACE quote";
		break;
	case 7:
		//Update REPLACE dash
		$query = "UPDATE fl_pol_master SET parcelID = Replace(parcelID,'-',''), parcelID2 = Replace(parcelID2,'-','')";
		$result = mysqli_query($con,$query);
		//Response Text
		echo "<img src='images/ajax_loading.gif' height='20' /> 7. ".mysqli_affected_rows($con)." REPLACE dash";
		break;
	default:
		echo "Error Processing...";
}

//Close Database Connection
include("dbclose.php");
?>