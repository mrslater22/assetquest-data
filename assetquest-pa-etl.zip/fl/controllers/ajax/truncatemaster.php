<?php
//Open Database Connection
include("dbopen.php");

//Truncate Master
mysql_query('TRUNCATE TABLE fl_lee_master;');

//Response Text
echo "Done!";

//Close Database Connection
include("dbclose.php");
?>