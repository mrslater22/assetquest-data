<?php if (isset($_POST['processID'])) { ?>
	<?php if ($fmErrorType1 = 1) { ?> 
	<script type="text/javascript">divAction("nameMsg");</script>
	<?php } elseif ($fmErrorType2 = 1) { ?>
	<script type="text/javascript">divAction("emailMsg");</script>
	<?php } ?>
<?php } ?>