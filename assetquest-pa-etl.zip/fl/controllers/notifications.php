<?php
function sendWelcome($uid,$urlStr) {
	$query = "SELECT * FROM tbl_user WHERE userID = ".$uid;
	$result = mysql_query($query);
	$rcount = mysql_num_rows($result);
	$row = mysql_fetch_array($result);
	if($rcount>0){
		$to      = $row['email'];
		$subject = "Congratulations, Welcome To Your Asset Quest Virtual Portfolio! Please Validate Your Account.";
		$message = "
		<div style='padding:5px 0px;'>Dear Valued Customer,</div>
		<div style='padding:5px 0px;'>Welcome to your Asset Quest Virtual Portfolio!</div>
		<div style='padding:5px 0px;'>To validate your Virtual Portfolio account, please click on the link below:</div>
		<div style='padding:5px 0px;'>&raquo;&nbsp;<a href='http://".$urlStr."/index.php?p=9&uid=".$row['userID']."&vcd=".$row['vCode']."'>Click Here To Validate Account</a></div>
		<div style='padding:5px 0px;'>Best Regards!</div>
		<div style='padding:5px 0px;'>The Asset Quest Customer Support Team</div>
		";
		// To send HTML mail, the Content-type header must be set
		$headers  = 'MIME-Version: 1.0' . "\r\n";
		$headers .= 'Content-type: text/html; charset=iso-8859-1' . "\r\n";
		
		// Additional headers
		$headers .= "To: " . $row['email'] . "\r\n";
		$headers .= "From: Asset Quest Customer Support <support@assetquest.com>" . "\r\n";
		$headers .= "Cc: " . "\r\n";
		$headers .= "Bcc: " . "\r\n";
		
		mail($to, $subject, $message, $headers);
	}
}

function sendValidation($uid,$urlStr) {
	$query = "SELECT * FROM tbl_user WHERE userID = ".$uid;
	$result = mysql_query($query);
	$rcount = mysql_num_rows($result);
	$row = mysql_fetch_array($result);
	if($rcount>0){
		$to      = $row['email'];
		$subject = "Asset Quest Virtual Portal Account Validation Link";
		$message = "
		<div style='padding:5px 0px;'>Dear Valued Customer,</div>
		<div style='padding:5px 0px;'>To validate your Asset Quest Virtual Portal account, please click on the link below:</div>
		<div style='padding:5px 0px;'>&raquo;&nbsp;<a href='http://".$urlStr."/index.php?p=9&uid=".$row['userID']."&vcd=".$row['vCode']."'>Click Here To Validate Account</a></div>
		<div style='padding:5px 0px;'>Best Regards!</div>
		<div style='padding:5px 0px;'>The Asset Quest Customer Support Team</div>
		";
		// To send HTML mail, the Content-type header must be set
		$headers  = 'MIME-Version: 1.0' . "\r\n";
		$headers .= 'Content-type: text/html; charset=iso-8859-1' . "\r\n";
		
		// Additional headers
		$headers .= "To: " . $row['email'] . "\r\n";
		$headers .= "From: Virtual Portal Customer Support <support@Virtual Portal.com>" . "\r\n";
		$headers .= "Cc: " . "\r\n";
		$headers .= "Bcc: " . "\r\n";
		
		mail($to, $subject, $message, $headers);
	}
}

function sendPassword($uid,$pword) {
	$query = "SELECT * FROM tbl_user WHERE userID = ".$uid;
	$result = mysql_query($query);
	$rcount = mysql_num_rows($result);
	$row = mysql_fetch_array($result);
	if($rcount>0){
		$to      = $row['email'];
		$subject = "Asset Quest Virtual Portal Account Forgot Password Service";
		$message = "
		<div style='padding:5px 0px;'>Dear Valued Customer,</div>
		<div style='padding:5px 0px;'>Your account password has been reset and your temporary passwod is: ".$pword."</div>
		<div style='padding:5px 0px;'>Best Regards!</div>
		<div style='padding:5px 0px;'>The Asset Quest Customer Support Team</div>
		";
		// To send HTML mail, the Content-type header must be set
		$headers  = 'MIME-Version: 1.0' . "\r\n";
		$headers .= 'Content-type: text/html; charset=iso-8859-1' . "\r\n";
		
		// Additional headers
		$headers .= "To: " . $row['email'] . "\r\n";
		$headers .= "From: Virtual Portal Customer Support <support@Virtual Portal.com>" . "\r\n";
		$headers .= "Cc: " . "\r\n";
		$headers .= "Bcc: " . "\r\n";
		
		mail($to, $subject, $message, $headers);
	}
}

function sendOfferReq($uid,$urlStr) {
	$query = "SELECT U.*, P.*, APM.pDate, APM.pPrice, A.prospectID, AV.price2012 FROM tbl_user U LEFT JOIN tbl_userPortMap UPM ON U.userID = UPM.userID LEFT JOIN tbl_portfolio PORT ON UPM.portfolioID = PORT.portfolioID LEFT JOIN tbl_portPropMap PPM ON PORT.portfolioID = PPM.aPortfolioID LEFT JOIN tbl_property P ON PPM.propertyID = P.propertyID LEFT JOIN tbl_assessedValue AV ON P.propertyID = AV.propertyID WHERE U.userID = ".$uid." AND APM.apmTypeID = 1 AND quoteReq = 1 ORDER BY siteState, siteCity, siteAddress";
	$result = mysql_query($query);
	$rcount = mysql_num_rows($result);
	$row = mysql_fetch_array($result);
	if($rcount>0){
		$to      = "sales@assetquest.com";
		$subject = $row['firstName']." - Offer Request";
		$message = "<div><strong>Name:</strong> ".$row['firstName']."</div><div><strong>Prospect ID:</strong> ".$row['prospectID']."</div><div><strong>Phone:</strong> ".$row['phone']."</div><div><strong>Email:</strong> ".$row['email']."</div><div>Offer Request Details:</div>";
		while($row = mysql_fetch_assoc($result)) {
			$message = $message."<div>&bull;&nbsp;".$row['parcelID']." | ".$row['siteAddress'].", ".$row['siteCity'].", ".$row['siteState']." ".$row['siteZip']." | ".$row['pDate']." | ".$row['pPrice']." | ".$row['price2012']."</div>";
		}
		// To send HTML mail, the Content-type header must be set
		$headers  = 'MIME-Version: 1.0' . "\r\n";
		$headers .= 'Content-type: text/html; charset=iso-8859-1' . "\r\n";
		
		// Additional headers
		$headers .= "To: " . $row['email'] . "\r\n";
		$headers .= "From: Asset Quest Webmaster <webmaster@assetquest.com>" . "\r\n";
		$headers .= "Cc: " . "\r\n";
		$headers .= "Bcc: " . "\r\n";
		
		mail($to, $subject, $message, $headers);
	}
}
?>