<?php
function generateRandom($length=9, $strength=0) {
	$vowels = 'aeuy';
	$consonants = 'bdghjmnpqrstvz';
	if ($strength & 1) {
		$consonants .= 'BDGHJLMNPQRSTVWXZ';
	}
	if ($strength & 2) {
		$vowels .= "AEUY";
	}
	if ($strength & 4) {
		$consonants .= '23456789';
	}
	if ($strength & 8) {
		$consonants .= '@#$%';
	}
 
	$password = '';
	$alt = time() % 2;
	for ($i = 0; $i < $length; $i++) {
		if ($alt == 1) {
			$password .= $consonants[(rand() % strlen($consonants))];
			$alt = 0;
		} else {
			$password .= $vowels[(rand() % strlen($vowels))];
			$alt = 1;
		}
	}
	return $password;
}

function checkProspectExist($prospectID,$zipCode){
	$query = "SELECT * FROM tbl_user U LEFT JOIN tbl_userPortMap UPM ON U.userID = UPM.userID LEFT JOIN tbl_portfolio PORT ON UPM.portfolioID = A.portfolioID WHERE U.zip = '".$zipCode."' AND A.prospectID = ".$prospectID;
	$result = mysql_query($query);
	$rcount = mysql_num_rows($result);
	$row = mysql_fetch_array($result);
	if($rcount>0){
		$uid = $row['userID'];
	}else{
		$uid = 0;	
	}

	return $uid;
}

function checkUser($checkType,$checkValue){
	//Check uNameClean
	if($checkType==1){
		$findQry = "SELECT * FROM tbl_user WHERE uNameClean = '".$checkValue."'";
		$find = mysql_query($findQry);
		if(mysql_num_rows($find)==0){
			$checkFlag = 0;
		}else{
			$checkFlag = 1;	
		}
	}
	return $checkFlag;
}

function createUserAccount($fName,$lName,$email,$uName,$uNameClean,$pWord,$vCode) {
	$pWord_hash = md5($pWord);
	$fieldStr = "fName,lName,email,uName,uNameClean,pWord,validateCode,createDate";
	$valueStr ="'".$fName."','".$lName."','".$email."','".$uName."','".$uNameClean."','".$pWord_hash."','".$vCode."','".date('Y-m-d')."'";
	$query = "INSERT INTO tbl_user (".$fieldStr.") VALUES (".$valueStr.")";
	mysql_query($query);
	
	$uid = mysql_insert_id();

	return $uid;
}

function createUserAccount_FB($fbid,$fName,$lName,$uName,$uNameClean,$pWord,$vCode) {
	$pWord_hash = md5($pWord);
	$fieldStr = "fbID,fName,lName,uName,uNameClean,pWord,validateCode,createDate";
	$valueStr = $fbid.",'".$fName."','".$lName."','".$uName."','".$uNameClean."','".$pWord_hash."','".$vCode."','".date('Y-m-d')."'";
	$query = "INSERT INTO tbl_user (".$fieldStr.") VALUES (".$valueStr.")";
	mysql_query($query);
	
	$uid = mysql_insert_id();

	return $uid;
}

function setUserSession($uid){
	$query = "SELECT * FROM tbl_user WHERE userID = ".$uid;
	$result = mysql_query($query);
	$rcount = mysql_num_rows($result);
	$row = mysql_fetch_array($result);
	if($rcount>0){
		$_SESSION['uid'] = $row['userID'];
		$_SESSION['uName'] = $row['uName'];
		$_SESSION['firstName'] = $row['firstName'];
		$_SESSION['lastName'] = $row['lastName'];
		$_SESSION['email'] = $row['email'];
		$_SESSION['isAdmin'] = $row['isAQAdmin'];
		$_SESSION['isEditor'] = $row['isAQEditor'];
		$_SESSION['isValid'] = $row['isValid'];
		$_SESSION['isActive'] = $row['isActive'];
	}
}

function validateUser($uid,$vcd){
	//Check validation code
	$findQry = "SELECT * FROM tbl_user WHERE userID = ".$uid." AND vCode = '".$vcd."'";
	$find = mysql_query($findQry);
	if(mysql_num_rows($find)==0){
		$checkFlag = 0;
	}else{
		$query = "UPDATE tbl_user SET isValid = 1 WHERE userID = ".$uid;
		mysql_query($query);
		$_SESSION['isValid'] = 1;
		$checkFlag = 1;	
	}
	return $checkFlag;
}

function updateEmail($uid,$email){
	$uNameClean = addslashes(strip_tags(strtolower($email)));
	$query = "UPDATE tbl_user SET uName = '".$email."', uNameClean = '".$uNameClean."', email = '".$email."', isValid = 0 WHERE userID = ".$uid;
	mysql_query($query);
	$_SESSION['email'] = $email;
	return 1;
}

function updatePhone($uid,$phone){
	$query = "UPDATE tbl_user SET phone = '".$phone."' WHERE userID = ".$uid;
	mysql_query($query);
	return 1;
}

function updateUserInfo($uid,$email,$uName,$uNameClean,$pWord,$vCode){
	$pWord_hash = md5($pWord);
	$query = "UPDATE tbl_user SET email = '".$email."', uName = '".$uName."', uNameClean = '".$uNameClean."', pWord = '".$pWord_hash."', vCode = '".$vCode."' WHERE userID = ".$uid;
	mysql_query($query);

	return $uid;
}

function login($uNameClean,$pWord){
	$pWord_hash = md5($pWord);
	$findQry = "SELECT * FROM tbl_user WHERE uNameClean = '".$uNameClean."' AND pWord = '".$pWord_hash."'";
	$find = mysql_query($findQry);
	if(mysql_num_rows($find)==0){
		$checkFlag = 0;
	}else{
		$row = mysql_fetch_array($find);
		if($row['isAQAdmin']==1||$row['isAQEditor']==1){
			setUserSession($row['userID']);
			$checkFlag = 1;
		}else{
			$checkFlag = 2;
		}
	}
	return $checkFlag;
}

function login_FB($fbid){
	$findQry = "SELECT * FROM tbl_user WHERE fbID = ".$fbid;
	$find = mysql_query($findQry);
	$row = mysql_fetch_array($find);
	setUserSession($row['userID']);
}

function logout(){
	session_unset();
	session_destroy();
}

function resetPassword($uNameClean){
	$findQry = "SELECT * FROM tbl_user WHERE uNameClean = '".$uNameClean."'";
	$find = mysql_query($findQry);
	if(mysql_num_rows($find)==0){
		$checkFlag = 0;
		$uid = 0;
		$pword = "";
	}else{
		$row = mysql_fetch_array($find);
		$pword = generateRandom();
		$uid = $row['userID'];
		$checkFlag = 1;
		
		$pWord_hash = md5($pword);
		$query = "UPDATE tbl_user SET pWord = '".$pWord_hash."' WHERE userID = ".$uid;
		mysql_query($query);
	}
	return array($checkFlag,$uid,$pword);
}
?>