<h2>Geocode Manager</h2>
<?php
$mapKey = "ABQIAAAAVuBbKeZsoI7nMIA7_HrmEBSpd8EWr76Z2A11Da1J9MKR6XoFyRT_oT0UV4mGh4TA1bIDPwTQ57akOQ";
$error = "Error: Could not connect to the database.";
$con = mysql_connect("aqmaster.db.8618275.hostedresource.com","aqmaster","Gr@t!a123");
$dbName = "aqmaster";
mysql_select_db($dbName, $con) or die($error);

define("MAPS_HOST", "maps.google.com");
define("KEY", $mapKey);

// Select all the rows in the markers table
$query = "SELECT P.* FROM tbl_property P INNER JOIN zlcom_listing L ON (P.propertyID = L.fkID AND L.typeID = 1) WHERE L.isActive = 1 AND geocoded = 0";
$result = mysql_query($query);
if (!$result) {
  die("Invalid query: " . mysql_error());
}

// Initialize delay in geocode speed
$delay = 0;
$base_url = "http://" . MAPS_HOST . "/maps/geo?output=xml" . "&key=" . KEY;

// Iterate through the rows, geocoding each address
while ($row = @mysql_fetch_assoc($result)) {
  $geocode_pending = true;

  while ($geocode_pending) {
    $address = $row["siteAddress"].", ".$row["siteCity"].", ".$row["siteState"];
    $id = $row["propertyID"];
    $request_url = $base_url . "&q=" . urlencode($address);
    $xml = simplexml_load_file($request_url) or die("url not loading");

    $status = $xml->Response->Status->code;
    if (strcmp($status, "200") == 0) {
      // Successful geocode
      $geocode_pending = false;
      $coordinates = $xml->Response->Placemark->Point->coordinates;
      $coordinatesSplit = explode(",", $coordinates);
      // Format: Longitude, Latitude, Altitude
      $lat = $coordinatesSplit[1];
      $lng = $coordinatesSplit[0];

      $query = sprintf("UPDATE tbl_property " .
             " SET lat = '%s', lng = '%s', geocoded = 1 " .
             " WHERE propertyID = '%s' LIMIT 1;",
             mysql_real_escape_string($lat),
             mysql_real_escape_string($lng),
             mysql_real_escape_string($id));
      $update_result = mysql_query($query);
      if (!$update_result) {
        die("Invalid query: " . mysql_error());
      }
	  echo "Address " . $address . " geocoded. <br />";
    } else if (strcmp($status, "620") == 0) {
      // sent geocodes too fast
      $delay += 100000;
    } else {
      // failure to geocode
      $geocode_pending = false;
      echo "Address " . $address . " failed to geocoded. ";
      echo "Received status " . $status . "<br />";
    }
    usleep($delay);
  }
}

mysql_close($con);
?>