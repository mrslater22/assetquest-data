<?php
define('DB_CRM_HOST', 'aqmaster.db.8618275.hostedresource.com');
define('DB_CRM_USER', 'aqmaster');
define('DB_CRM_PASS', 'L@ndS@les1');
define('DB_CRM_NAME', 'aqmaster');
define('DB_CRM_ERROR', 'Error: Could not connect to the CRM database.');

$error = "Error: Could not connect to the database.";
$con = mysql_connect(DB_CRM_HOST,DB_CRM_NAME,DB_CRM_PASS);
$dbName = DB_CRM_NAME;
mysql_select_db($dbName, $con) or die($error);

$sysmsg = "";

if(isset($_POST['submit'])){
	$query = "UPDATE tbl_property SET lat = ".$_POST['fmLat'].", lng = ".$_POST['fmLng']." WHERE propertyID = ".$_POST['fmPropID'];
	mysql_query($query);
	$sysmsg = "Update Complete.";
}
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Asset Quest GeoCoder</title>
<meta name="viewport" content="initial-scale=1.0, user-scalable=no" />

<script type="text/javascript" src="http://maps.google.com/maps/api/js?key=AIzaSyBgTLgZnzlrtuDXMSY2gnlDWNXyqCVGwZw&sensor=false"></script>
<?php
if(isset($_GET['propid'])){
	$query = "SELECT * FROM tbl_property WHERE propertyID = ".$_GET['propid'];
	$result = mysql_query($query);
	$row = mysql_fetch_assoc($result);
	
	$cPropID = $row['propertyID'];
	$cLat = $row['lat'];
	$cLng = $row['lng'];
	$cAddress = $row['siteAddress'];
	$cStrap = $row['parcelID'];
?>
<script type="text/javascript">
var geocoder = new google.maps.Geocoder();

function geocodePosition(pos) {
  geocoder.geocode({
    latLng: pos
  }, function(responses) {
    if (responses && responses.length > 0) {
      updateMarkerAddress(responses[0].formatted_address);
    } else {
      updateMarkerAddress('Cannot determine address at this location.');
    }
  });
}

function updateMarkerStatus(str) {
  /*
  document.getElementById('markerStatus').innerHTML = str;
  */
}

function updateMarkerPosition(latLng) {
  /*
  document.getElementById('info').innerHTML = [
    latLng.lat(),
    latLng.lng()
  ].join(', ');
  */
  document.getElementById('fmLat').value = latLng.lat();
  document.getElementById('fmLng').value = latLng.lng();
}

function updateMarkerAddress(str) {
 /*
 document.getElementById('address').innerHTML = str;
 */
}

function initialize() {
  var latLng = new google.maps.LatLng(<?php echo $cLat; ?>, <?php echo $cLng; ?>);
  var map = new google.maps.Map(document.getElementById('mapCanvas'), {
    zoom: 18,
    center: latLng,
    mapTypeId: google.maps.MapTypeId.ROADMAP
  });
  var marker = new google.maps.Marker({
    position: latLng,
    title: '<?php echo $cAddress; ?> (<?php echo $cStrap; ?>)',
    map: map,
    draggable: true
  });
  
  // Update current position info.
  updateMarkerPosition(latLng);
  geocodePosition(latLng);
  
  // Add dragging event listeners.
  google.maps.event.addListener(marker, 'dragstart', function() {
    updateMarkerAddress('Dragging...');
  });
  
  google.maps.event.addListener(marker, 'drag', function() {
    updateMarkerStatus('Dragging...');
    updateMarkerPosition(marker.getPosition());
  });
  
  google.maps.event.addListener(marker, 'dragend', function() {
    updateMarkerStatus('Drag ended');
    geocodePosition(marker.getPosition());
  });
}

// Onload handler to fire off the app.
google.maps.event.addDomListener(window, 'load', initialize);
</script>
<?php
}
?>
</head>
<body>
  <style>
  #mapCanvas {
    width: 800px;
    height: 600px;
    float: left;
  }
  #infoPanel {
    float: left;
    margin-left: 10px;
	height: 600px;
	overflow:scroll;
  }
  #infoPanel div {
    margin-bottom: 5px;
  }
  </style>
  
  <h1>Asset Quest Geo Coder - BKB1 Portfolio</h1>
  <div>
    <form name="updateLatLng" method="post" action="index.php?propid=<?php echo $cPropID; ?>">
        <b>Update coordinates:</b>
        <input id="fmLat" type="text" name="fmLat" size="20" value="<?php echo $cLat; ?>" />
        <input id="fmLng" type="text" name="fmLng" size="20" value="<?php echo $cLng; ?>" />
        <input type="hidden" name="fmPropID" value="<?php echo $cPropID; ?>" />
        <input type="submit" name="submit" value="Update" />
        <?php if($sysmsg<>""){echo "<span style=\"color:#CC0000;\">".$sysmsg."</span>";}?>
    </form>
  </div>
  
  <div id="mapCanvas"></div>
  
  <div id="infoPanel">    
    <b>Properties:</b>
<?php
$query = "SELECT P.* FROM tbl_user U LEFT JOIN tbl_userPortMap UPM ON U.userID = UPM.userID LEFT JOIN tbl_portfolio PORT ON UPM.portfolioID = PORT.portfolioID LEFT JOIN tbl_portPropMap PPM ON PORT.portfolioID = PPM.aPortfolioID LEFT JOIN tbl_property P ON PPM.propertyID = P.propertyID WHERE U.userID = 211133 AND APM.apmTypeID = 1 ORDER BY P.siteAddress";
$result = mysql_query($query);
$loopCount = 0;
while ($row = mysql_fetch_assoc($result)) {
	if($row['propertyID']==$cPropID){
		$bgColor = "00CC00";
	}else{
		$bgColor = "FFFFFF";
	}
	$paLink = "";
	if($row['countyCode']=="FL-LEE"){
		$paLink = "http://www.leepa.org/Display/DisplayParcel.aspx?STRAP=".$row['parcelID'];
	}elseif($row['countyCode']=="FL-CHA"){
		$paLink = "http://www.ccappraiser.com/Show_parcel.asp?acct=".$row['parcelID']."%20%20&gen=T&tax=T&bld=T&oth=T&sal=T&lnd=T&leg=T";
	}elseif($row['countyCode']=="FL-SAR"){
		$paLink = "http://www.sc-pa.com/search/parcel_detail.asp?year=2013&propid=".$row['parcelID'];
	}
?>
    <div style="background-color:#<?php echo $bgColor; ?>; padding:5px; font-size:12px;"><a name="prop<?php echo $row['propertyID']; ?>"></a><a href="index.php?propid=<?php echo $row['propertyID']; ?>#prop<?php echo $row['propertyID']; ?>"><?php echo $row['siteAddress']; ?>, <?php echo $row['siteCity']; ?>, <?php echo $row['siteState']; ?> <?php echo $row['siteZip']; ?></a> (<?php echo $row['parcelID']; ?>)<?php if($paLink<>""){ ?> <a href="<?php echo $paLink; ?>" target="_blank"><img src="/images/icon_pa.png" width="16" height="14" border="0" /></a><?php } ?></div>
<?php
	$loopCount++;
}
?>
  </div>
  <div style="clear:both;"><?php echo $loopCount; ?> Properties</div>
</body>

</html>
<?php
mysql_close($con);
?>