<?php

// Store default API User/Pass here
define('DEFAULT_ZOHO_USER', 'cjraider');
define('DEFAULT_ZOHO_PASS', 'erin0513');
// See http://zohocrmapi.wiki.zoho.com/Generating-API-Ticket.html
// For instructions on generating a Zoho API Key
define('DEFAULT_ZOHO_API_KEY', 'I9jq6fcZASIvkqZXsnqMOapsXschfoRvkQaMGWeIdlI$');  

define('DEFAULT_ZOHO_AUTHTOKEN', 'e70668b77a34ff135d4ef9885ee76559');
// To create persistance for tickets, create a ticket table in your DB,
// an empty ticket table will not persist tickets (persistance is recommended by zoho)
//define('ZOHO_TICKET_TABLE', 'zoho_tickets');
define('ZOHO_TICKET_TABLE', 'zoho_tickets');

// DB Credentials if you want Zoho Ticket to be persisted in the database
/* Zoho tickets are valid for one week.  Caching the ticket in a local database
 * will speed up API calls over generating a new API ticket every time a class is
 * instantiated.
 */
define('DB_HOST', 'zlprod.db.8618275.hostedresource.com');
define('DB_USER', 'zlprod');
define('DB_PASS', 'Z@doo123');
define('DB_NAME', 'zlprod');
?>