<?php
require('zoho_config.php');
//Database Info
define('DB_CRM_HOST', 'zlprod.db.8618275.hostedresource.com');
define('DB_CRM_USER', 'zlprod');
define('DB_CRM_PASS', 'Gr@t!a123');
define('DB_CRM_NAME', 'zlprod');
define('DB_CRM_ERROR', 'Error: Could not connect to the CRM database.');
//Connect To Database
$con = mysql_connect(DB_CRM_HOST,DB_CRM_NAME,DB_CRM_PASS);
$dbName = DB_CRM_NAME;
mysql_select_db($dbName, $con) or die(DB_CRM_ERROR);
//require_once('class_zoho_crm.php');

$query = "SELECT * FROM zoho_actowner WHERE batch = ".$_GET['batch']." AND processFlag = 0";
$result = mysql_query($query);
$rcount = mysql_num_rows($result);

if($rcount>0){
	$idListAry = array();
	$loopCount = 0;
	
	$my_xml_str = "<?xml version=\"1.0\" encoding=\"UTF-8\" ?><Accounts>";	
	
	while($row = mysql_fetch_assoc($result)) {

		$id = $row['zh_accountID'];
		$ownerID = $row['zh_accountOwnerID'];
		$ownerName = $row['zh_accountOwnerName'];
		
		$loopCount = $loopCount + 1;
		
		$my_xml_str = $my_xml_str."<row no=\"".$loopCount."\"><FL val=\"Id\">".$id."</FL><FL val=\"SMOWNERID\">".$ownerID."</FL><FL val=\"Account Owner\">".$ownerName."</FL></row>";
		
		//populate processed id array
		$aryPos = $loopCount - 1;
		$idListAry[$aryPos]= $row['id'];
	
	}
	
	$my_xml_str = $my_xml_str."</Accounts>";
	
	//set cURL URL variables		
	$xmlDataStr = urlencode($my_xml_str);
	$fieldStr = "newFormat=1&version=4&authtoken=e70668b77a34ff135d4ef9885ee76559&scope=crmapi&xmlData=".$xmlDataStr;
	$urlStr = "https://crm.zoho.com/crm/private/xml/Accounts/updateRecords";
	//echo $urlStr."?".$fieldStr;
	
	//open connection
	$ch = curl_init();
	
	//set cURL options
	curl_setopt($ch, CURLOPT_URL, $urlStr);
	curl_setopt($ch, CURLOPT_SSL_CIPHER_LIST, 'rsa_rc4_128_sha'); 
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, TRUE);
	curl_setopt($ch, CURLOPT_POST, TRUE);
	curl_setopt($ch, CURLOPT_POSTFIELDS, $fieldStr);    
	
	//execute cURL post
	$curl_response = curl_exec($ch);
	$error = curl_error($ch);
	if($error){
		throw new Exception('Error in inserting records to Zoho CRM');
	}
	
	//close connection
	curl_close($ch);
	
	//update process flag
	foreach($idListAry as $value){
		$query = "UPDATE zoho_actowner SET processFlag = 1 WHERE id = ".$value;
		mysql_query($query);
	}

}
?>
<html>
<?php $nextBatch = $_GET['batch'] + 1; ?>
<head>
    <title>updateRecords - Accounts (Multi)</title>
<?php if($_GET['batch']<17){ ?>
    <META HTTP-EQUIV=Refresh CONTENT="60; URL=../../zoho/?batch=<?php echo $nextBatch; ?>">
<?php } ?>
</head>
<body>
<h1>updateRecords - Accounts (Multi) - Batch <?php echo $_GET['batch']; ?></h1>
<?php echo "<h2>DONE! ".$loopCount." account records have been processed.</h2>"; ?>
</body>
</html>
<?php mysql_close($con); ?>