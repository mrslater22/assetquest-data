<?php
define('DB_CRM_HOST', 'flleedb.db.8618275.hostedresource.com');
define('DB_CRM_USER', 'flleedb');
define('DB_CRM_PASS', 'D8@bA53!');
define('DB_CRM_NAME', 'flleedb');
define('DB_CRM_ERROR', 'Error: Could not connect to the CRM database.');
?>