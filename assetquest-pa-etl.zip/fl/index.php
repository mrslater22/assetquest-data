<?php 
//ob
ob_start();

//session
session_start();

include("config.php");
include("dbopen.php");
include("configs/global.php");
include("controllers/process.php");
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<?php include("modules/head.php"); ?>
</head>
<body>
<?php 
include("layout/header.php");
include("layout/body.php");
include("layout/footer.php"); 
?>
</body>
</html>
<?php 
include("controllers/postprocess.php");
include("dbclose.php");
?>
