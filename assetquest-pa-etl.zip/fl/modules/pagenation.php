<!-- Pagenation -->
<?php
if($pid==3){
	$query = "SELECT COUNT(P.propertyID) AS resultCount FROM tbl_property P WHERE ".$conditions;
}elseif($pid==4){
	$query = "SELECT COUNT(P.propertyID) AS propCount FROM tbl_property P INNER JOIN aqcrm_premarket PM ON (P.propertyID = PM.fkID AND PM.typeID = 1) WHERE ".$conditions;
}elseif($pid==6){
	$query = "SELECT COUNT(P.propertyID) AS resultCount FROM tbl_property P INNER JOIN aqcrm_title T ON (P.propertyID = T.fkID) WHERE ".$conditions;
}elseif($pid==9){
	if($listID == 1){
		$query = "SELECT COUNT(P.propertyID) AS resultCount FROM tbl_property P WHERE P.evalStatus = 1 AND ".$conditions;
	}else{
		$query = "SELECT COUNT(P.propertyID) AS resultCount FROM tbl_property P WHERE P.evalStatus = 2 AND ".$conditions;
	}
}

$result = mysql_query($query);
$rcount = mysql_num_rows($result);
$row = mysql_fetch_assoc($result);
$resultCount = $row['resultCount'];

if($resultCount>0&&$resultCount<=1000){
	$pageCount = ceil($resultCount/$_SESSION['maxrows']);
	$cPage = ($_SESSION['startrow']/$_SESSION['maxrows'])+1;
	
	//Get Previous Page Start Row
	if($_SESSION['startrow']==0){
		$prevStartRow = 0;
	}else{
		$prevStartRow = $_SESSION['startrow']-$_SESSION['maxrows'];
	}
	
	//Get Next Page Start Row
	if($pageCount>1){
		if($_SESSION['startrow']==($pageCount-1)*$_SESSION['maxrows']){
			$nextStartRow = ($pageCount-1)*$_SESSION['maxrows'];
		}else{
			$nextStartRow = $_SESSION['startrow']+$_SESSION['maxrows'];
		}		
	}else{
		$nextStartRow = 0;
	}
	
?>

<ul class="pagination">
<?php
if($_SESSION['startrow']==0){
?>
	<li class="arrow unavailable"><a href="<?php echo $urlStr; ?>/index.php?p=<?php echo $pid; ?>&startrow=<?php echo $prevStartRow; ?>">&laquo;</a></li>
<?php
}else{
?>
	<li class="arrow"><a href="<?php echo $urlStr; ?>/index.php?p=<?php echo $pid; ?>&startrow=<?php echo $prevStartRow; ?>" title="Previous Page">&laquo;</a></li>
<?php
}
	
$hellipFlag1 = 0;
$hellipFlag2 = 0;
for($i=1;$i<=$pageCount;$i++){
	$loopStartRow = ($i-1)*$_SESSION['maxrows'];	
	if($pageCount<=10){
		if($i==$cPage){
?>
	<li class="current"><a href="<?php echo $urlStr; ?>/index.php?p=<?php echo $pid; ?>&startrow=<?php echo $loopStartRow; ?>"><?php echo $i; ?></a></li>
<?php
		}else{
?>
	<li><a href="<?php echo $urlStr; ?>/index.php?p=<?php echo $pid; ?>&startrow=<?php echo $loopStartRow; ?>" title="Go To Page <?php echo $i; ?>"><?php echo $i; ?></a></li>
<?php
		}
	}else{
		if($cPage<=5){ // Current Page Within The First 5 Pages
			if($i==$cPage){
?>
	<li class="current"><a href="<?php echo $urlStr; ?>/index.php?p=<?php echo $pid; ?>&startrow=<?php echo $loopStartRow; ?>"><?php echo $i; ?></a></li>
<?php
			}elseif($i<=6){
?>
	<li><a href="<?php echo $urlStr; ?>/index.php?p=<?php echo $pid; ?>&startrow=<?php echo $loopStartRow; ?>" title="Go To Page <?php echo $i; ?>"><?php echo $i; ?></a></li>
<?php
			}elseif($i==$pageCount){
?>
	<li><a href="<?php echo $urlStr; ?>/index.php?p=<?php echo $pid; ?>&startrow=<?php echo $loopStartRow; ?>" title="Go To Page <?php echo $i; ?>"><?php echo $i; ?></a></li>
<?php
			}elseif($hellipFlag2==0){
				$hellipFlag2=1;
?>
	<li>&hellip;</li>
<?php
			}
			
		}elseif($cPage>5&&($pageCount-$cPage)>=5){
			
			if($i==1){
?>
	<li><a href="<?php echo $urlStr; ?>/index.php?p=<?php echo $pid; ?>&startrow=<?php echo $loopStartRow; ?>"><?php echo $i; ?></a></li>
<?php
			}elseif($hellipFlag1==0){
				$hellipFlag1=1;
?>
	<li>&hellip;</li>
<?php
			}elseif(($cPage-$i)<=3&&($cPage-$i)>0){
?>
	<li><a href="<?php echo $urlStr; ?>/index.php?p=<?php echo $pid; ?>&startrow=<?php echo $loopStartRow; ?>" title="Go To Page <?php echo $i; ?>"><?php echo $i; ?></a></li>
<?php
			}elseif($i==$cPage){
?>
	<li class="current"><a href="<?php echo $urlStr; ?>/index.php?p=<?php echo $pid; ?>&startrow=<?php echo $loopStartRow; ?>"><?php echo $i; ?></a></li>
<?php
			}elseif(($i-$cPage)<=3&&($i-$cPage)>0){
?>
	<li><a href="<?php echo $urlStr; ?>/index.php?p=<?php echo $pid; ?>&startrow=<?php echo $loopStartRow; ?>" title="Go To Page <?php echo $i; ?>"><?php echo $i; ?></a></li>
<?php
			}elseif($i==$pageCount){
?>
	<li><a href="<?php echo $urlStr; ?>/index.php?p=<?php echo $pid; ?>&startrow=<?php echo $loopStartRow; ?>" title="Go To Page <?php echo $i; ?>"><?php echo $i; ?></a></li>
<?php
			}elseif(($i-$cPage)>3&&$hellipFlag2==0){
				$hellipFlag2=1;
?>
	<li>&hellip;</li>
<?php
			}	
		}elseif(($pageCount-$cPage)<5){ // Current Page Within The Last 5 Pages
			if($i==1){
?>
	<li><a href="<?php echo $urlStr; ?>/index.php?p=<?php echo $pid; ?>&startrow=<?php echo $loopStartRow; ?>"><?php echo $i; ?></a></li>
<?php
			}elseif($hellipFlag1==0){
				$hellipFlag1=1;
?>
	<li>&hellip;</li>
<?php
			}elseif($i==$cPage){
?>
	<li class="current"><a href="<?php echo $urlStr; ?>/index.php?p=<?php echo $pid; ?>&startrow=<?php echo $loopStartRow; ?>"><?php echo $i; ?></a></li>
<?php
			}elseif(($cPage-$i)<=6){
?>
	<li><a href="<?php echo $urlStr; ?>/index.php?p=<?php echo $pid; ?>&startrow=<?php echo $loopStartRow; ?>" title="Go To Page <?php echo $i; ?>"><?php echo $i; ?></a></li>
<?php
			}	
		}
	}
}

if($_SESSION['startrow']==($pageCount-1)*20){
?>
	<li class="arrow unavailable"><a href="<?php echo $urlStr; ?>/index.php?p=<?php echo $pid; ?>&startrow=<?php echo $nextStartRow; ?>">&raquo;</a></li>
<?php
}else{
?>
	<li class="arrow"><a href="<?php echo $urlStr; ?>/index.php?p=<?php echo $pid; ?>&startrow=<?php echo $nextStartRow; ?>" title="Next Page">&raquo;</a></li>
<?php
}
?>
</ul>

<?php
}
?>