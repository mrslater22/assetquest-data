<?php
//Set Defaults
$pTitle = "SCORE FL-LEE DATA MANAGER";
$pKeywords = "";
$pDescription = "";
?>
<title><?php echo $pTitle; ?></title>
<meta name="keywords" content="<?php echo $pKeywords; ?>" />
<meta name="description" content="<?php echo $pDescription; ?>" />
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta http-equiv="Content-Style-Type" content="text/css" />
<link rel="shortcut icon" href="<?php echo $urlStr; ?>/favicon.ico" />

<!-- Included CSS Files (Compressed) -->
<link rel="stylesheet" href="<?php echo $urlStr; ?>/stylesheets/foundation.css">
<link rel="stylesheet" href="<?php echo $urlStr; ?>/stylesheets/app.css">

<!-- Included JS Files (Uncompressed) -->
<!--
<script src="<?php echo $urlStr; ?>/javascripts/foundation.min.js"></script>
<script src="<?php echo $urlStr; ?>/javascripts/jquery.foundation.mediaQueryToggle.js"></script>
<script src="<?php echo $urlStr; ?>/javascripts/jquery.foundation.reveal.js"></script>
<script src="<?php echo $urlStr; ?>/javascripts/jquery.foundation.buttons.js"></script>
<script src="<?php echo $urlStr; ?>/javascripts/jquery.foundation.tabs.js"></script>
<script src="<?php echo $urlStr; ?>/javascripts/jquery.foundation.tooltips.js"></script>
<script src="<?php echo $urlStr; ?>/javascripts/jquery.foundation.accordion.js"></script>
<script src="<?php echo $urlStr; ?>/javascripts/jquery.placeholder.js"></script>
<script src="<?php echo $urlStr; ?>/javascripts/jquery.foundation.forms.js"></script>
<script src="<?php echo $urlStr; ?>/javascripts/jquery.foundation.orbit.js"></script>
<script src="<?php echo $urlStr; ?>/javascripts/jquery.foundation.alerts.js"></script>
-->
  
<!-- Included JS Files (Compressed) -->
<script src="<?php echo $urlStr; ?>/javascripts/jquery.js"></script>
<script src="<?php echo $urlStr; ?>/javascripts/foundation.js"></script>
<script src="<?php echo $urlStr; ?>/javascripts/foundation.core.js"></script>
<script src="<?php echo $urlStr; ?>/javascripts/foundation.accordion.js"></script>
<script src="<?php echo $urlStr; ?>/javascripts/foundation.util.keyboard.js"></script>
<script src="<?php echo $urlStr; ?>/javascripts/foundation.util.motion.js"></script>
<script src="<?php echo $urlStr; ?>/javascripts/jquery.foundation.navigation.js"></script>
  
<!-- Initialize JS Plugins -->
<script src="<?php echo $urlStr; ?>/javascripts/app.js"></script>

<script src="<?php echo $urlStr; ?>/resources/ckeditor/ckeditor.js"></script>
<script src="<?php echo $urlStr; ?>/javascripts/ajaxscript.js"></script>
<script src="<?php echo $urlStr; ?>/javascripts/script.js"></script>
<script type="text/javascript">setAJAXURL('<?php echo $urlStr; ?>');</script>