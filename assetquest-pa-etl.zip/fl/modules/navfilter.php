<nav class="top-bar" style="margin:0px 0px 0px 0px;">
    <ul>
  		<li class="name"><h1><a href="<?php echo $urlStr; ?>/index.php?p=<?php echo $_GET['p']; ?>&siteCity=ALL&lotType=ALL&liststat=ALL" title="Click here to reset filter">Filters</a></h1></li>
  		<li class="toggle-topbar"><a href="#"></a></li>
	</ul>
	<section>
	<ul class="left">
		<li class="divider"></li>
		<li class="has-dropdown">
			<a class="active" href="#">State: <?php echo $stateStr; ?></a>
      		<ul class="dropdown">
        		<!--<li><a<?php if($stateStr=="ALL"){echo " style='background-color:#3c3c3c;'";} ?> href="<?php echo $urlStr; ?>/index.php?p=<?php echo $pid; ?>&startrow=0&siteState=ALL">ALL</a></li>-->
<?php
// Select all the rows in the markers table
$query = "SELECT DISTINCT P.siteState FROM tbl_property P LEFT JOIN zlcom_listing L ON (P.propertyID = L.fkID AND L.typeID = 1) ORDER BY P.siteState";
$result = mysql_query($query);

while ($row = mysql_fetch_assoc($result)) {
?>
				<li><a<?php if($stateStr==$row['siteState']){echo " style='background-color:#3c3c3c;'";} ?> href="<?php echo $urlStr; ?>/index.php?p=<?php echo $pid; ?>&startrow=0&siteState=<?php echo $row['siteState']; ?>"><?php echo $row['siteState']; ?></a></li>
<?php
}
?>
             </ul>
		</li>
     
<?php
if($_SESSION['siteState']<>""){
?>
		<li class="divider"></li>
		<li class="has-dropdown">
			<a class="active" href="#">City: <?php echo $cityStr; ?></a>
      		<ul class="dropdown">
                <li><a<?php if($cityStr=="ALL"){echo " style='background-color:#3c3c3c;'";} ?> href="<?php echo $urlStr; ?>/index.php?p=<?php echo $pid; ?>&startrow=0&siteCity=ALL">ALL</a></li>
<?php
// Select all the rows in the markers table
$query = "SELECT DISTINCT P.siteCity FROM tbl_property P LEFT JOIN zlcom_listing L ON (P.propertyID = L.fkID AND L.typeID = 1) WHERE P.siteState = '".$_SESSION['siteState']."' AND P.siteCity <> '' ORDER BY P.siteCity";
$result = mysql_query($query);

while ($row = mysql_fetch_assoc($result)) {
?>
				<li><a<?php if($cityStr==$row['siteCity']){echo " style='background-color:#3c3c3c;'";} ?> href="<?php echo $urlStr; ?>/index.php?p=<?php echo $pid; ?>&startrow=0&siteCity=<?php echo $row['siteCity']; ?>"><?php echo $row['siteCity']; ?></a></li>
<?php
}
?>
			</ul>
		</li>
<?php
}
?>

<?php
if($_SESSION['siteCity']<>""){
?>
		<li class="divider"></li>
		<li class="has-dropdown">
			<a class="active" href="#">Area: <?php echo $subAreaStr; ?></a>
      		<ul class="dropdown">
                <li><a<?php if($subAreaStr=="ALL"){echo " style='background-color:#3c3c3c;'";} ?> href="<?php echo $urlStr; ?>/index.php?p=<?php echo $pid; ?>&startrow=0&siteSubArea=ALL">ALL</a></li>
<?php
// Select all the rows in the markers table
$query = "SELECT DISTINCT P.siteSubArea FROM tbl_property P LEFT JOIN zlcom_listing L ON (P.propertyID = L.fkID AND L.typeID = 1) WHERE P.siteState = '".$_SESSION['siteState']."' AND P.siteCity = '".$_SESSION['siteCity']."' AND P.siteSubArea <> '' ORDER BY P.siteSubArea";
$result = mysql_query($query);

while ($row = mysql_fetch_assoc($result)) {
?>
				<li><a<?php if($subAreaStr==$row['siteSubArea']){echo " style='background-color:#3c3c3c;'";} ?> href="<?php echo $urlStr; ?>/index.php?p=<?php echo $pid; ?>&startrow=0&siteSubArea=<?php echo $row['siteSubArea']; ?>"><?php echo $row['siteSubArea']; ?></a></li>
<?php
}
?>
			</ul>
		</li>
<?php
}
?>
 
<?php
if($_SESSION['siteSubArea']<>""){
?>
		<li class="divider"></li>
		<li class="has-dropdown">
			<a class="active" href="#">Unit: <?php echo $unitStr; ?></a>
      		<ul class="dropdown">
                <li><a<?php if($unitStr=="ALL"){echo " style='background-color:#3c3c3c;'";} ?> href="<?php echo $urlStr; ?>/index.php?p=<?php echo $pid; ?>&startrow=0&siteUnit=ALL">ALL</a></li>
<?php
// Select all the rows in the markers table
$query = "SELECT DISTINCT P.siteUnit FROM tbl_property P LEFT JOIN zlcom_listing L ON (P.propertyID = L.fkID AND L.typeID = 1) WHERE P.siteState = '".$_SESSION['siteState']."' AND P.siteCity = '".$_SESSION['siteCity']."' AND P.siteSubArea = '".$_SESSION['siteSubArea']."' AND P.siteUnit <> '' ORDER BY P.siteUnit";
$result = mysql_query($query);

while ($row = mysql_fetch_assoc($result)) {
?>
				<li><a<?php if($unitStr==$row['siteUnit']){echo " style='background-color:#3c3c3c;'";} ?> href="<?php echo $urlStr; ?>/index.php?p=<?php echo $pid; ?>&startrow=0&siteUnit=<?php echo $row['siteUnit']; ?>"><?php echo $row['siteUnit']; ?></a></li>
<?php
}
?>
			</ul>
		</li>
<?php
}
?>
		<li class="divider"></li>
		<li class="has-dropdown">
			<a class="active" href="#">Type: <?php echo $lotTypeStr; ?></a>
      		<ul class="dropdown">
                <li><a<?php if($lotTypeStr=="ALL"){echo " style='background-color:#3c3c3c;'";} ?> href="<?php echo $urlStr; ?>/index.php?p=<?php echo $pid; ?>&startrow=0&lotType=ALL">ALL</a></li>
<?php
// Select all the rows in the markers table
$query = "SELECT DISTINCT P.lotTypeStr FROM tbl_property P LEFT JOIN zlcom_listing L ON (P.propertyID = L.fkID AND L.typeID = 1) WHERE P.siteState = '".$_SESSION['siteState']."' AND P.siteCity = '".$_SESSION['siteCity']."'  AND P.lotTypeStr <> '' ORDER BY P.lotTypeStr";
$result = mysql_query($query);

while ($row = mysql_fetch_assoc($result)) {
?>
    			<li><a<?php if($lotTypeStr==$row['lotTypeStr']){echo " style='background-color:#3c3c3c;'";} ?> href="<?php echo $urlStr; ?>/index.php?p=<?php echo $pid; ?>&startrow=0&lotType=<?php echo $row['lotTypeStr']; ?>"><?php echo $row['lotTypeStr']; ?></a></li>
<?php
}
?>
			</ul>
		</li>
        <!--
        <li class="divider"></li>
		<li class="has-dropdown">
			<a class="active" href="#">PM: <?php echo $pmStatStr; ?></a>
      		<ul class="dropdown">
                <li><a<?php if($pmStatStr=="ALL"){echo " style='background-color:#3c3c3c;'";} ?> href="<?php echo $urlStr; ?>/index.php?p=<?php echo $pid; ?>&startrow=0&pmstat=ALL">ALL</a></li>
				<li><a<?php if($pmStatStr=="ACTIVE"){echo " style='background-color:#3c3c3c;'";} ?> href="<?php echo $urlStr; ?>/index.php?p=<?php echo $pid; ?>&startrow=0&pmstat=1">ACTIVE</a></li>
                <li><a<?php if($pmStatStr=="INACTIVE"){echo " style='background-color:#3c3c3c;'";} ?> href="<?php echo $urlStr; ?>/index.php?p=<?php echo $pid; ?>&startrow=0&pmstat=0">INACTIVE</a></li>
                <?php if($pid<>4){ ?><li><a<?php if($pmStatStr=="NONE"){echo " style='background-color:#3c3c3c;'";} ?> href="<?php echo $urlStr; ?>/index.php?p=<?php echo $pid; ?>&startrow=0&pmstat=NONE">NONE</a></li><?php } ?>
			</ul>
		</li>
        -->
<?php if($pid==3||$pid==5){ ?>
		<li class="divider"></li>
		<li class="has-dropdown">
			<a class="active" href="#">Listing: <?php echo $listStatStr; ?></a>
      		<ul class="dropdown">
                <li><a<?php if($listStatStr=="ALL"){echo " style='background-color:#3c3c3c;'";} ?> href="<?php echo $urlStr; ?>/index.php?p=<?php echo $pid; ?>&startrow=0&liststat=ALL">ALL</a></li>
				<li><a<?php if($listStatStr=="ACTIVE"){echo " style='background-color:#3c3c3c;'";} ?> href="<?php echo $urlStr; ?>/index.php?p=<?php echo $pid; ?>&startrow=0&liststat=1">ACTIVE</a></li>
                <li><a<?php if($listStatStr=="INACTIVE"){echo " style='background-color:#3c3c3c;'";} ?> href="<?php echo $urlStr; ?>/index.php?p=<?php echo $pid; ?>&startrow=0&liststat=0">INACTIVE</a></li>
                <?php if($pid<>5){ ?><li><a<?php if($listStatStr=="NONE"){echo " style='background-color:#3c3c3c;'";} ?> href="<?php echo $urlStr; ?>/index.php?p=<?php echo $pid; ?>&startrow=0&liststat=NONE">NONE</a></li><?php } ?>
			</ul>
		</li>
<?php } ?>   

<?php if($pid==6){ ?>
		<li class="divider"></li>
		<li class="has-dropdown">
			<a class="active" href="#">Title: <?php echo $titleStatStr; ?></a>
      		<ul class="dropdown">
                <li><a<?php if($titleStatStr=="ALL"){echo " style='background-color:#3c3c3c;'";} ?> href="<?php echo $urlStr; ?>/index.php?p=<?php echo $pid; ?>&startrow=0&titlestat=ALL">ALL</a></li>
				<li><a<?php if($titleStatStr=="STATUS 1"){echo " style='background-color:#3c3c3c;'";} ?> href="<?php echo $urlStr; ?>/index.php?p=<?php echo $pid; ?>&startrow=0&titlestat=1">STATUS 1</a></li>
                <li><a<?php if($titleStatStr=="STATUS 2"){echo " style='background-color:#3c3c3c;'";} ?> href="<?php echo $urlStr; ?>/index.php?p=<?php echo $pid; ?>&startrow=0&titlestat=2">STATUS 2</a></li>
			</ul>
		</li>
<?php } ?>     
	</ul>
	</section>
</nav>