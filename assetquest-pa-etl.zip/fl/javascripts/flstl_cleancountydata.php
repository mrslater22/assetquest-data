<?php
//Open Database Connection
include("flstldbopen.php");

//Clean Raw County Data
switch($_GET['pid']){
	case 0:
		//Update Null LANDUSEDES
		$query = "UPDATE fl_stl_pa SET LANDUSEDES = 'NULL' WHERE LANDUSEDES IS NULL OR LANDUSEDES = ''";
		$result = mysql_query($query);
		//Response Text
		echo "<img src='images/ajax_loading.gif' height='20' /> LANDUSEDES Updated NULL";
		break;
	case 1:
		//Update Null SITELOTTYPE
		$query = "UPDATE fl_stl_pa SET SITELOTTYPE = 'NULL' WHERE SITELOTTYPE IS NULL OR SITELOTTYPE = ''";
		$result = mysql_query($query);
		//Response Text
		echo "<img src='images/ajax_loading.gif' height='20' /> SITELOTTYPE Updated NULL";
		break;
	case 2:
		//Update Null SITEADDR
		$query = "UPDATE fl_stl_pa SET SITEADDRESS = 'NULL' WHERE SITEADDRESS IS NULL OR SITEADDRESS = ''";
		$result = mysql_query($query);
		//Response Text
		echo "<img src='images/ajax_loading.gif' height='20' /> SITEADDRESS Updated NULL";
		break;
	case 3:
		//Update Null SITENUMBER
		$query = "UPDATE fl_stl_pa SET SITENUMBER = 'NULL' WHERE SITENUMBER IS NULL OR SITENUMBER = ''";
		$result = mysql_query($query);
		//Response Text
		echo "<img src='images/ajax_loading.gif' height='20' /> SITENUMBER Updated NULL";
		break;
	case 4:
		//Update Null SITESTREET
		$query = "UPDATE fl_stl_pa SET SITESTREET = 'NULL' WHERE SITESTREET IS NULL OR SITESTREET = ''";
		$result = mysql_query($query);
		//Response Text
		echo "<img src='images/ajax_loading.gif' height='20' /> SITESTREET Updated NULL";
		break;
	case 5:
		//Update Null SITECITY
		$query = "UPDATE fl_stl_pa SET SITECITY = 'NULL' WHERE SITECITY IS NULL OR SITECITY = ''";
		$result = mysql_query($query);
		//Response Text
		echo "<img src='images/ajax_loading.gif' height='20' /> SITECITY Updated NULL";
		break;
	case 6:
		//Update Null SITEZIP
		$query = "UPDATE fl_stl_pa SET SITEZIP = 'NULL' WHERE SITEZIP IS NULL OR SITEZIP = ''";
		$result = mysql_query($query);
		//Response Text
		echo "<img src='images/ajax_loading.gif' height='20' /> SITEZIP Updated NULL";
		break;
	case 7:
		//Update Null O_OTHERS
		$query = "UPDATE fl_stl_pa SET ownerFullName = 'NULL' WHERE ownerFullName IS NULL OR ownerFullName = ''";
		$result = mysql_query($query);
		//Response Text
		echo "<img src='images/ajax_loading.gif' height='20' /> ownerFullName Updated NULL";
		break;
	case 8:
		//Update Null O_CAREOF
		$query = "UPDATE fl_stl_pa SET ownerCO = 'NULL' WHERE ownerCO IS NULL OR ownerCO = ''";
		$result = mysql_query($query);
		//Response Text
		echo "<img src='images/ajax_loading.gif' height='20' /> ownerCO Updated NULL";
		break;
	case 9:
		//Update Null O_ADDR1
		$query = "UPDATE fl_stl_pa SET ownerAddr1 = 'NULL' WHERE ownerAddr1 IS NULL OR ownerAddr1 = ''";
		$result = mysql_query($query);
		//Response Text
		echo "<img src='images/ajax_loading.gif' height='20' /> ownerAddr1 Updated NULL";
		break;
	case 10:
		//Update Null O_ADDR2
		$query = "UPDATE fl_stl_pa SET ownerAddr2 = 'NULL' WHERE ownerAddr2 IS NULL OR ownerAddr2 = ''";
		$result = mysql_query($query);
		//Response Text
		echo "<img src='images/ajax_loading.gif' height='20' /> ownerAddr2 Updated NULL";
		break;
	case 11:
		//Update Null O_CITY
		$query = "UPDATE fl_stl_pa SET ownerCity = 'NULL' WHERE ownerCity IS NULL OR ownerCity = ''";
		$result = mysql_query($query);
		//Response Text
		echo "<img src='images/ajax_loading.gif' height='20' /> ownerCity Updated NULL";
		break;
	case 12:
		//Update Null O_STATE
		$query = "UPDATE fl_stl_pa SET ownerState = 'NULL' WHERE ownerState IS NULL OR ownerState = ''";
		$result = mysql_query($query);
		//Response Text
		echo "<img src='images/ajax_loading.gif' height='20' /> ownerState Updated NULL";
		break;
	case 13:
		//Update Null O_ZIP
		$query = "UPDATE fl_stl_pa SET ownerZip = 'NULL' WHERE ownerZip IS NULL OR ownerZip = ''";
		$result = mysql_query($query);
		//Response Text
		echo "<img src='images/ajax_loading.gif' height='20' /> ownerZip Updated NULL";
		break;
	case 14:
		//Update Null O_COUNTRY
		$query = "UPDATE fl_stl_pa SET ownerCountry = 'UNITED STATES' WHERE ownerCountry IS NULL OR ownerCountry = ''";
		$result = mysql_query($query);
		//Response Text
		echo "<img src='images/ajax_loading.gif' height='20' /> ownerCountry Updated NULL";
		break;
	case 15:
		//Update remove ' from ownerFullName, ownerCO, ownerAddr1, ownerAddr2, ownerCity, ownerCountry
		$query = "UPDATE fl_stl_pa SET ownerFullName = REPLACE(ownerFullName, '\'', ' '), ownerCO = REPLACE(ownerCO, '\'', ' '), ownerAddr1 = REPLACE(ownerAddr1, '\'', ' '), ownerAddr2 = REPLACE(ownerAddr2, '\'', ' '), ownerCity = REPLACE(ownerCity, '\'', ' '), ownerCountry = REPLACE(ownerCountry, '\'', ' ')";
		$result = mysql_query($query);
		//Response Text
		echo "<img src='images/ajax_loading.gif' height='20' /> ownerFullName, ownerCO, ownerAddr1, ownerAddr2, ownerCity, ownerCountry Updated";
		break;
	default:
		echo "Error Processing...now";
}

//Close Database Connection
include("dbclose.php");
?>