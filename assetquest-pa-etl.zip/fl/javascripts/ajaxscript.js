// JavaScript Document
var ajaxUrl;

function setAJAXURL(url)
{
    ajaxUrl = url;
}

/************************/
/*     Lee County       */
/************************/

function truncate_master_fl_lee(divID1,divID2){
	document.getElementById(divID2).innerHTML="<img src='images/ajax_loading.gif' height='20' />";
	if (window.XMLHttpRequest){// code for IE7+, Firefox, Chrome, Opera, Safari
		xmlhttp=new XMLHttpRequest();
	}else{// code for IE6, IE5
		xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
	}
	xmlhttp.open("GET","controllers/ajax/fllee_truncatemaster.php?z="+Math.random(),true);
	xmlhttp.onload = function(){
		document.getElementById(divID1).innerHTML="<img src='images/checked_checkbox-26.png' />";
		document.getElementById(divID2).innerHTML=xmlhttp.responseText;
	}
	xmlhttp.send(null);
}

function clean_county_data_fl_lee(divID1,divID2){
	document.getElementById(divID2).innerHTML="<img src='images/ajax_loading.gif' height='20' />";
	if (window.XMLHttpRequest){// code for IE7+, Firefox, Chrome, Opera, Safari
		xmlhttp=new XMLHttpRequest();
	}else{// code for IE6, IE5
		xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
	}
	callHandle(0);
	function callHandle(proNum){
		if(proNum<26){
			callAjax(proNum);
		}else{
			document.getElementById(divID1).innerHTML="<img src='images/checked_checkbox-26.png' />";
			document.getElementById(divID2).innerHTML="Done!";
		}
	}
	function callAjax(proNum){
		xmlhttp.open("GET","controllers/ajax/fllee_cleancountydata.php?pid="+proNum+"&z="+Math.random(),true);
		xmlhttp.onload = function(){
			proNum++;
			document.getElementById(divID2).innerHTML=xmlhttp.responseText;
			callHandle(proNum);
		}
		xmlhttp.send(null);
	}
}

function insert_master_data_fl_lee(divID1,divID2){
	document.getElementById(divID2).innerHTML="<img src='images/ajax_loading.gif' height='30' />";
	if (window.XMLHttpRequest){// code for IE7+, Firefox, Chrome, Opera, Safari
		xmlhttp=new XMLHttpRequest();
	}else{// code for IE6, IE5
		xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
	}
	callHandle(1);
	function callHandle(recNum){
		if(recNum>0){
			callAjax();
		}else{
			document.getElementById(divID1).innerHTML="<img src='images/checked_checkbox-26.png' />";
			document.getElementById(divID2).innerHTML="Done!";
		}
	}
	function callAjax(){
		var recNum = 0;
		xmlhttp.open("GET","controllers/ajax/fllee_insertmasterdata.php?z="+Math.random(),true);
		xmlhttp.onload = function(){
			recNum = Number(xmlhttp.responseText);
			document.getElementById(divID2).innerHTML="<img src='images/ajax_loading.gif' height='20' /> Records Remaining: "+recNum;
			callHandle(recNum);
		}
		xmlhttp.send(null);
	}
}

function clean_master_data_fl_lee(divID1,divID2){
	document.getElementById(divID2).innerHTML="<img src='images/ajax_loading.gif' height='20' />";
	if (window.XMLHttpRequest){// code for IE7+, Firefox, Chrome, Opera, Safari
		xmlhttp=new XMLHttpRequest();
	}else{// code for IE6, IE5
		xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
	}
	callHandle(0);
	function callHandle(proNum){
		if(proNum<22){
			callAjax(proNum);
		}else{
			document.getElementById(divID1).innerHTML="<img src='images/checked_checkbox-26.png' />";
			document.getElementById(divID2).innerHTML="Done!";
		}
	}
	function callAjax(proNum){
		xmlhttp.open("GET","controllers/ajax/fllee_cleanmasterdata.php?pid="+proNum+"&z="+Math.random(),true);
		xmlhttp.onload = function(){
			proNum++;
			document.getElementById(divID2).innerHTML=xmlhttp.responseText;
			callHandle(proNum);
		}
		xmlhttp.send(null);
	}
}

function truncate_import_fl_lee(divID1,divID2){
	document.getElementById(divID2).innerHTML="<img src='images/ajax_loading.gif' height='20' />";
	if (window.XMLHttpRequest){// code for IE7+, Firefox, Chrome, Opera, Safari
		xmlhttp=new XMLHttpRequest();
	}else{// code for IE6, IE5
		xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
	}
	xmlhttp.open("GET","controllers/ajax/fllee_truncateimport.php?z="+Math.random(),true);
	xmlhttp.onload = function(){
		document.getElementById(divID1).innerHTML="<img src='images/checked_checkbox-26.png' />";
		document.getElementById(divID2).innerHTML=xmlhttp.responseText;
	}
	xmlhttp.send(null);
}

function insert_import_data_fl_lee(divID1,divID2,cd){
	document.getElementById(divID2).innerHTML="<img src='images/ajax_loading.gif' height='30' />";
	if (window.XMLHttpRequest){// code for IE7+, Firefox, Chrome, Opera, Safari
		xmlhttp=new XMLHttpRequest();
	}else{// code for IE6, IE5
		xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
	}
	callHandle(1,cd);
	function callHandle(recNum,cd){
		if(recNum>0){
			callAjax(cd);
		}else{
			document.getElementById(divID1).innerHTML="<img src='images/checked_checkbox-26.png' />";
			document.getElementById(divID2).innerHTML="Done!";
		}
	}
	function callAjax(cd){
		var recNum = 0;
		xmlhttp.open("GET","controllers/ajax/fllee_insertimportdata.php?cd="+cd+"&z="+Math.random(),true);
		xmlhttp.onload = function(){
			recNum = Number(xmlhttp.responseText);
			document.getElementById(divID2).innerHTML="<img src='images/ajax_loading.gif' height='20' /> Records Remaining: "+recNum;
			callHandle(recNum,cd);
		}
		xmlhttp.send(null);
	}
}

/************************/
/*  Charlotte County    */
/************************/

function truncate_master_fl_cha(divID1,divID2){
	document.getElementById(divID2).innerHTML="<img src='images/ajax_loading.gif' height='20' />";
	if (window.XMLHttpRequest){// code for IE7+, Firefox, Chrome, Opera, Safari
		xmlhttp=new XMLHttpRequest();
	}else{// code for IE6, IE5
		xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
	}
	xmlhttp.open("GET","controllers/ajax/flcha_truncatemaster.php?z="+Math.random(),true);
	xmlhttp.onload = function(){
		document.getElementById(divID1).innerHTML="<img src='images/checked_checkbox-26.png' />";
		document.getElementById(divID2).innerHTML=xmlhttp.responseText;
	}
	xmlhttp.send(null);
}

function clean_county_data_fl_cha(divID1,divID2){
	document.getElementById(divID2).innerHTML="<img src='images/ajax_loading.gif' height='20' />";
	if (window.XMLHttpRequest){// code for IE7+, Firefox, Chrome, Opera, Safari
		xmlhttp=new XMLHttpRequest();
	}else{// code for IE6, IE5
		xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
	}
	callHandle(0);
	function callHandle(proNum){
		if(proNum<26){
			callAjax(proNum);
		}else{
			document.getElementById(divID1).innerHTML="<img src='images/checked_checkbox-26.png' />";
			document.getElementById(divID2).innerHTML="Done!";
		}
	}
	function callAjax(proNum){
		xmlhttp.open("GET","controllers/ajax/flcha_cleancountydata.php?pid="+proNum+"&z="+Math.random(),true);
		xmlhttp.onload = function(){
			proNum++;
			document.getElementById(divID2).innerHTML=xmlhttp.responseText;
			callHandle(proNum);
		}
		xmlhttp.send(null);
	}
}

function insert_master_data_fl_cha(divID1,divID2){
	document.getElementById(divID2).innerHTML="<img src='images/ajax_loading.gif' height='30' />";
	if (window.XMLHttpRequest){// code for IE7+, Firefox, Chrome, Opera, Safari
		xmlhttp=new XMLHttpRequest();
	}else{// code for IE6, IE5
		xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
	}
	callHandle(1);
	function callHandle(recNum){
		if(recNum>0){
			callAjax();
		}else{
			document.getElementById(divID1).innerHTML="<img src='images/checked_checkbox-26.png' />";
			document.getElementById(divID2).innerHTML="Done!";
		}
	}
	function callAjax(){
		var recNum = 0;
		xmlhttp.open("GET","controllers/ajax/flcha_insertmasterdata.php?z="+Math.random(),true);
		xmlhttp.onload = function(){
			recNum = Number(xmlhttp.responseText);
			document.getElementById(divID2).innerHTML="<img src='images/ajax_loading.gif' height='20' /> Records Remaining: "+recNum;
			callHandle(recNum);
		}
		xmlhttp.send(null);
	}
}

function clean_master_data_fl_cha(divID1,divID2){
	document.getElementById(divID2).innerHTML="<img src='images/ajax_loading.gif' height='20' />";
	if (window.XMLHttpRequest){// code for IE7+, Firefox, Chrome, Opera, Safari
		xmlhttp=new XMLHttpRequest();
	}else{// code for IE6, IE5
		xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
	}
	callHandle(0);
	function callHandle(proNum){
		if(proNum<11){
			callAjax(proNum);
		}else{
			document.getElementById(divID1).innerHTML="<img src='images/checked_checkbox-26.png' />";
			document.getElementById(divID2).innerHTML="Done!";
		}
	}
	function callAjax(proNum){
		xmlhttp.open("GET","controllers/ajax/flcha_cleanmasterdata.php?pid="+proNum+"&z="+Math.random(),true);
		xmlhttp.onload = function(){
			proNum++;
			document.getElementById(divID2).innerHTML=xmlhttp.responseText;
			callHandle(proNum);
		}
		xmlhttp.send(null);
	}
}

function truncate_import_fl_cha(divID1,divID2){
	document.getElementById(divID2).innerHTML="<img src='images/ajax_loading.gif' height='20' />";
	if (window.XMLHttpRequest){// code for IE7+, Firefox, Chrome, Opera, Safari
		xmlhttp=new XMLHttpRequest();
	}else{// code for IE6, IE5
		xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
	}
	xmlhttp.open("GET","controllers/ajax/flcha_truncateimport.php?z="+Math.random(),true);
	xmlhttp.onload = function(){
		document.getElementById(divID1).innerHTML="<img src='images/checked_checkbox-26.png' />";
		document.getElementById(divID2).innerHTML=xmlhttp.responseText;
	}
	xmlhttp.send(null);
}

function insert_import_data_fl_cha(divID1,divID2,cd){
	document.getElementById(divID2).innerHTML="<img src='images/ajax_loading.gif' height='30' />";
	if (window.XMLHttpRequest){// code for IE7+, Firefox, Chrome, Opera, Safari
		xmlhttp=new XMLHttpRequest();
	}else{// code for IE6, IE5
		xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
	}
	callHandle(1,cd);
	function callHandle(recNum,cd){
		if(recNum>0){
			callAjax(cd);
		}else{
			document.getElementById(divID1).innerHTML="<img src='images/checked_checkbox-26.png' />";
			document.getElementById(divID2).innerHTML="Done!";
		}
	}
	function callAjax(cd){
		var recNum = 0;
		xmlhttp.open("GET","controllers/ajax/flcha_insertimportdata.php?cd="+cd+"&z="+Math.random(),true);
		xmlhttp.onload = function(){
			recNum = Number(xmlhttp.responseText);
			document.getElementById(divID2).innerHTML="<img src='images/ajax_loading.gif' height='20' /> Records Remaining: "+recNum;
			callHandle(recNum,cd);
		}
		xmlhttp.send(null);
	}
}

/************************/
/*   Sarasota County    */
/************************/

function truncate_master_fl_sar(divID1,divID2){
	document.getElementById(divID2).innerHTML="<img src='images/ajax_loading.gif' height='20' />";
	if (window.XMLHttpRequest){// code for IE7+, Firefox, Chrome, Opera, Safari
		xmlhttp=new XMLHttpRequest();
	}else{// code for IE6, IE5
		xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
	}
	xmlhttp.open("GET","controllers/ajax/flsar_truncatemaster.php?z="+Math.random(),true);
	xmlhttp.onload = function(){
		document.getElementById(divID1).innerHTML="<img src='images/checked_checkbox-26.png' />";
		document.getElementById(divID2).innerHTML=xmlhttp.responseText;
	}
	xmlhttp.send(null);
}

function clean_county_data_fl_sar(divID1,divID2){
	document.getElementById(divID2).innerHTML="<img src='images/ajax_loading.gif' height='20' />";
	if (window.XMLHttpRequest){// code for IE7+, Firefox, Chrome, Opera, Safari
		xmlhttp=new XMLHttpRequest();
	}else{// code for IE6, IE5
		xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
	}
	callHandle(0);
	function callHandle(proNum){
		if(proNum<42){
			callAjax(proNum);
		}else{
			document.getElementById(divID1).innerHTML="<img src='images/checked_checkbox-26.png' />";
			document.getElementById(divID2).innerHTML="Done!";
		}
	}
	function callAjax(proNum){
		xmlhttp.open("GET","controllers/ajax/flsar_cleancountydata.php?pid="+proNum+"&z="+Math.random(),true);
		xmlhttp.onload = function(){
			proNum++;
			document.getElementById(divID2).innerHTML=xmlhttp.responseText;
			callHandle(proNum);
		}
		xmlhttp.send(null);
	}
}

function insert_master_data_fl_sar(divID1,divID2){
	document.getElementById(divID2).innerHTML="<img src='images/ajax_loading.gif' height='30' />";
	if (window.XMLHttpRequest){// code for IE7+, Firefox, Chrome, Opera, Safari
		xmlhttp=new XMLHttpRequest();
	}else{// code for IE6, IE5
		xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
	}
	callHandle(1);
	function callHandle(recNum){
		if(recNum>0){
			callAjax();
		}else{
			document.getElementById(divID1).innerHTML="<img src='images/checked_checkbox-26.png' />";
			document.getElementById(divID2).innerHTML="Done!";
		}
	}
	function callAjax(){
		var recNum = 0;
		xmlhttp.open("GET","controllers/ajax/flsar_insertmasterdata.php?z="+Math.random(),true);
		xmlhttp.onload = function(){
			recNum = Number(xmlhttp.responseText);
			document.getElementById(divID2).innerHTML="<img src='images/ajax_loading.gif' height='20' /> Records Remaining: "+recNum;
			callHandle(recNum);
		}
		xmlhttp.send(null);
	}
}

function clean_master_data_fl_sar(divID1,divID2){
	document.getElementById(divID2).innerHTML="<img src='images/ajax_loading.gif' height='20' />";
	if (window.XMLHttpRequest){// code for IE7+, Firefox, Chrome, Opera, Safari
		xmlhttp=new XMLHttpRequest();
	}else{// code for IE6, IE5
		xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
	}
	callHandle(0);
	function callHandle(proNum){
		if(proNum<10){
			callAjax(proNum);
		}else{
			document.getElementById(divID1).innerHTML="<img src='images/checked_checkbox-26.png' />";
			document.getElementById(divID2).innerHTML="Done!";
		}
	}
	function callAjax(proNum){
		xmlhttp.open("GET","controllers/ajax/flsar_cleanmasterdata.php?pid="+proNum+"&z="+Math.random(),true);
		xmlhttp.onload = function(){
			proNum++;
			document.getElementById(divID2).innerHTML=xmlhttp.responseText;
			callHandle(proNum);
		}
		xmlhttp.send(null);
	}
}

function truncate_import_fl_sar(divID1,divID2){
	document.getElementById(divID2).innerHTML="<img src='images/ajax_loading.gif' height='20' />";
	if (window.XMLHttpRequest){// code for IE7+, Firefox, Chrome, Opera, Safari
		xmlhttp=new XMLHttpRequest();
	}else{// code for IE6, IE5
		xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
	}
	xmlhttp.open("GET","controllers/ajax/flsar_truncateimport.php?z="+Math.random(),true);
	xmlhttp.onload = function(){
		document.getElementById(divID1).innerHTML="<img src='images/checked_checkbox-26.png' />";
		document.getElementById(divID2).innerHTML=xmlhttp.responseText;
	}
	xmlhttp.send(null);
}

function insert_import_data_fl_sar(divID1,divID2,cd){
	document.getElementById(divID2).innerHTML="<img src='images/ajax_loading.gif' height='30' />";
	if (window.XMLHttpRequest){// code for IE7+, Firefox, Chrome, Opera, Safari
		xmlhttp=new XMLHttpRequest();
	}else{// code for IE6, IE5
		xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
	}
	callHandle(1,cd);
	function callHandle(recNum,cd){
		if(recNum>0){
			callAjax(cd);
		}else{
			document.getElementById(divID1).innerHTML="<img src='images/checked_checkbox-26.png' />";
			document.getElementById(divID2).innerHTML="Done!";
		}
	}
	function callAjax(cd){
		var recNum = 0;
		xmlhttp.open("GET","controllers/ajax/flsar_insertimportdata.php?cd="+cd+"&z="+Math.random(),true);
		xmlhttp.onload = function(){
			recNum = Number(xmlhttp.responseText);
			document.getElementById(divID2).innerHTML="<img src='images/ajax_loading.gif' height='20' /> Records Remaining: "+recNum;
			callHandle(recNum,cd);
		}
		xmlhttp.send(null);
	}
}

/************************/
/*    Collier County    */
/************************/

function truncate_master_fl_col(divID1,divID2){
	document.getElementById(divID2).innerHTML="<img src='images/ajax_loading.gif' height='20' />";
	if (window.XMLHttpRequest){// code for IE7+, Firefox, Chrome, Opera, Safari
		xmlhttp=new XMLHttpRequest();
	}else{// code for IE6, IE5
		xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
	}
	xmlhttp.open("GET","controllers/ajax/flcol_truncatemaster.php?z="+Math.random(),true);
	xmlhttp.onload = function(){
		document.getElementById(divID1).innerHTML="<img src='images/checked_checkbox-26.png' />";
		document.getElementById(divID2).innerHTML=xmlhttp.responseText;
	}
	xmlhttp.send(null);
}

function clean_county_data_fl_col(divID1,divID2){
	document.getElementById(divID2).innerHTML="<img src='images/ajax_loading.gif' height='20' />";
	if (window.XMLHttpRequest){// code for IE7+, Firefox, Chrome, Opera, Safari
		xmlhttp=new XMLHttpRequest();
	}else{// code for IE6, IE5
		xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
	}
	callHandle(0);
	function callHandle(proNum){
		if(proNum<40){
			callAjax(proNum);
		}else{
			document.getElementById(divID1).innerHTML="<img src='images/checked_checkbox-26.png' />";
			document.getElementById(divID2).innerHTML="Done!";
		}
	}
	function callAjax(proNum){
		xmlhttp.open("GET","controllers/ajax/flcol_cleancountydata.php?pid="+proNum+"&z="+Math.random(),true);
		xmlhttp.onload = function(){
			proNum++;
			document.getElementById(divID2).innerHTML=xmlhttp.responseText;
			callHandle(proNum);
		}
		xmlhttp.send(null);
	}
}

function insert_master_data_fl_col(divID1,divID2){
	document.getElementById(divID2).innerHTML="<img src='images/ajax_loading.gif' height='30' />";
	if (window.XMLHttpRequest){// code for IE7+, Firefox, Chrome, Opera, Safari
		xmlhttp=new XMLHttpRequest();
	}else{// code for IE6, IE5
		xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
	}
	callHandle(1);
	function callHandle(recNum){
		if(recNum>0){
			callAjax();
		}else{
			document.getElementById(divID1).innerHTML="<img src='images/checked_checkbox-26.png' />";
			document.getElementById(divID2).innerHTML="Done!";
		}
	}
	function callAjax(){
		var recNum = 0;
		xmlhttp.open("GET","controllers/ajax/flcol_insertmasterdata.php?z="+Math.random(),true);
		xmlhttp.onload = function(){
			recNum = Number(xmlhttp.responseText);
			document.getElementById(divID2).innerHTML="<img src='images/ajax_loading.gif' height='20' /> Records Remaining: "+recNum;
			callHandle(recNum);
		}
		xmlhttp.send(null);
	}
}

function clean_master_data_fl_col(divID1,divID2){
	document.getElementById(divID2).innerHTML="<img src='images/ajax_loading.gif' height='20' />";
	if (window.XMLHttpRequest){// code for IE7+, Firefox, Chrome, Opera, Safari
		xmlhttp=new XMLHttpRequest();
	}else{// code for IE6, IE5
		xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
	}
	callHandle(0);
	function callHandle(proNum){
		if(proNum<11){
			callAjax(proNum);
		}else{
			document.getElementById(divID1).innerHTML="<img src='images/checked_checkbox-26.png' />";
			document.getElementById(divID2).innerHTML="Done!";
		}
	}
	function callAjax(proNum){
		xmlhttp.open("GET","controllers/ajax/flcol_cleanmasterdata.php?pid="+proNum+"&z="+Math.random(),true);
		xmlhttp.onload = function(){
			proNum++;
			document.getElementById(divID2).innerHTML=xmlhttp.responseText;
			callHandle(proNum);
		}
		xmlhttp.send(null);
	}
}

function truncate_import_fl_col(divID1,divID2){
	document.getElementById(divID2).innerHTML="<img src='images/ajax_loading.gif' height='20' />";
	if (window.XMLHttpRequest){// code for IE7+, Firefox, Chrome, Opera, Safari
		xmlhttp=new XMLHttpRequest();
	}else{// code for IE6, IE5
		xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
	}
	xmlhttp.open("GET","controllers/ajax/flcol_truncateimport.php?z="+Math.random(),true);
	xmlhttp.onload = function(){
		document.getElementById(divID1).innerHTML="<img src='images/checked_checkbox-26.png' />";
		document.getElementById(divID2).innerHTML=xmlhttp.responseText;
	}
	xmlhttp.send(null);
}

function insert_import_data_fl_col(divID1,divID2,cd){
	document.getElementById(divID2).innerHTML="<img src='images/ajax_loading.gif' height='30' />";
	if (window.XMLHttpRequest){// code for IE7+, Firefox, Chrome, Opera, Safari
		xmlhttp=new XMLHttpRequest();
	}else{// code for IE6, IE5
		xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
	}
	callHandle(1,cd);
	function callHandle(recNum,cd){
		if(recNum>0){
			callAjax(cd);
		}else{
			document.getElementById(divID1).innerHTML="<img src='images/checked_checkbox-26.png' />";
			document.getElementById(divID2).innerHTML="Done!";
		}
	}
	function callAjax(cd){
		var recNum = 0;
		xmlhttp.open("GET","controllers/ajax/flcol_insertimportdata.php?cd="+cd+"&z="+Math.random(),true);
		xmlhttp.onload = function(){
			recNum = Number(xmlhttp.responseText);
			document.getElementById(divID2).innerHTML="<img src='images/ajax_loading.gif' height='20' /> Records Remaining: "+recNum;
			callHandle(recNum,cd);
		}
		xmlhttp.send(null);
	}
}

/************************/
/*    Brevard County    */
/************************/

function truncate_master_fl_bre(divID1,divID2){
	document.getElementById(divID2).innerHTML="<img src='images/ajax_loading.gif' height='20' />";
	if (window.XMLHttpRequest){// code for IE7+, Firefox, Chrome, Opera, Safari
		xmlhttp=new XMLHttpRequest();
	}else{// code for IE6, IE5
		xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
	}
	xmlhttp.open("GET","controllers/ajax/flbre_truncatemaster.php?z="+Math.random(),true);
	xmlhttp.onload = function(){
		document.getElementById(divID1).innerHTML="<img src='images/checked_checkbox-26.png' />";
		document.getElementById(divID2).innerHTML=xmlhttp.responseText;
	}
	xmlhttp.send(null);
}

function clean_county_data_fl_bre(divID1,divID2){
	document.getElementById(divID2).innerHTML="<img src='images/ajax_loading.gif' height='20' />";
	if (window.XMLHttpRequest){// code for IE7+, Firefox, Chrome, Opera, Safari
		xmlhttp=new XMLHttpRequest();
	}else{// code for IE6, IE5
		xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
	}
	callHandle(0);
	function callHandle(proNum){
		if(proNum<36){
			callAjax(proNum);
		}else{
			document.getElementById(divID1).innerHTML="<img src='images/checked_checkbox-26.png' />";
			document.getElementById(divID2).innerHTML="Done!";
		}
	}
	function callAjax(proNum){
		xmlhttp.open("GET","controllers/ajax/flbre_cleancountydata.php?pid="+proNum+"&z="+Math.random(),true);
		xmlhttp.onload = function(){
			proNum++;
			document.getElementById(divID2).innerHTML=xmlhttp.responseText;
			callHandle(proNum);
		}
		xmlhttp.send(null);
	}
}

function insert_master_data_fl_bre(divID1,divID2){
	document.getElementById(divID2).innerHTML="<img src='images/ajax_loading.gif' height='30' />";
	if (window.XMLHttpRequest){// code for IE7+, Firefox, Chrome, Opera, Safari
		xmlhttp=new XMLHttpRequest();
	}else{// code for IE6, IE5
		xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
	}
	callHandle(1);
	function callHandle(recNum){
		if(recNum>0){
			callAjax();
		}else{
			document.getElementById(divID1).innerHTML="<img src='images/checked_checkbox-26.png' />";
			document.getElementById(divID2).innerHTML="Done!";
		}
	}
	function callAjax(){
		var recNum = 0;
		xmlhttp.open("GET","controllers/ajax/flbre_insertmasterdata.php?z="+Math.random(),true);
		xmlhttp.onload = function(){
			recNum = Number(xmlhttp.responseText);
			document.getElementById(divID2).innerHTML="<img src='images/ajax_loading.gif' height='20' /> Records Remaining: "+recNum;
			callHandle(recNum);
		}
		xmlhttp.send(null);
	}
}

function clean_master_data_fl_bre(divID1,divID2){
	document.getElementById(divID2).innerHTML="<img src='images/ajax_loading.gif' height='20' />";
	if (window.XMLHttpRequest){// code for IE7+, Firefox, Chrome, Opera, Safari
		xmlhttp=new XMLHttpRequest();
	}else{// code for IE6, IE5
		xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
	}
	callHandle(0);
	function callHandle(proNum){
		if(proNum<9){
			callAjax(proNum);
		}else{
			document.getElementById(divID1).innerHTML="<img src='images/checked_checkbox-26.png' />";
			document.getElementById(divID2).innerHTML="Done!";
		}
	}
	function callAjax(proNum){
		xmlhttp.open("GET","controllers/ajax/flbre_cleanmasterdata.php?pid="+proNum+"&z="+Math.random(),true);
		xmlhttp.onload = function(){
			proNum++;
			document.getElementById(divID2).innerHTML=xmlhttp.responseText;
			callHandle(proNum);
		}
		xmlhttp.send(null);
	}
}

function truncate_import_fl_bre(divID1,divID2){
	document.getElementById(divID2).innerHTML="<img src='images/ajax_loading.gif' height='20' />";
	if (window.XMLHttpRequest){// code for IE7+, Firefox, Chrome, Opera, Safari
		xmlhttp=new XMLHttpRequest();
	}else{// code for IE6, IE5
		xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
	}
	xmlhttp.open("GET","controllers/ajax/flbre_truncateimport.php?z="+Math.random(),true);
	xmlhttp.onload = function(){
		document.getElementById(divID1).innerHTML="<img src='images/checked_checkbox-26.png' />";
		document.getElementById(divID2).innerHTML=xmlhttp.responseText;
	}
	xmlhttp.send(null);
}

function insert_import_data_fl_bre(divID1,divID2,cd){
	document.getElementById(divID2).innerHTML="<img src='images/ajax_loading.gif' height='30' />";
	if (window.XMLHttpRequest){// code for IE7+, Firefox, Chrome, Opera, Safari
		xmlhttp=new XMLHttpRequest();
	}else{// code for IE6, IE5
		xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
	}
	callHandle(1,cd);
	function callHandle(recNum,cd){
		if(recNum>0){
			callAjax(cd);
		}else{
			document.getElementById(divID1).innerHTML="<img src='images/checked_checkbox-26.png' />";
			document.getElementById(divID2).innerHTML="Done!";
		}
	}
	function callAjax(cd){
		var recNum = 0;
		xmlhttp.open("GET","controllers/ajax/flbre_insertimportdata.php?cd="+cd+"&z="+Math.random(),true);
		xmlhttp.onload = function(){
			recNum = Number(xmlhttp.responseText);
			document.getElementById(divID2).innerHTML="<img src='images/ajax_loading.gif' height='20' /> Records Remaining: "+recNum;
			callHandle(recNum,cd);
		}
		xmlhttp.send(null);
	}
}

/************************/
/*    Citrus County    */
/************************/

function truncate_master_fl_cit(divID1,divID2){
	document.getElementById(divID2).innerHTML="<img src='images/ajax_loading.gif' height='20' />";
	if (window.XMLHttpRequest){// code for IE7+, Firefox, Chrome, Opera, Safari
		xmlhttp=new XMLHttpRequest();
	}else{// code for IE6, IE5
		xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
	}
	xmlhttp.open("GET","controllers/ajax/flcit_truncatemaster.php?z="+Math.random(),true);
	xmlhttp.onload = function(){
		document.getElementById(divID1).innerHTML="<img src='images/checked_checkbox-26.png' />";
		document.getElementById(divID2).innerHTML=xmlhttp.responseText;
	}
	xmlhttp.send(null);
}

function clean_county_data_fl_cit(divID1,divID2){
	document.getElementById(divID2).innerHTML="<img src='images/ajax_loading.gif' height='20' />";
	if (window.XMLHttpRequest){// code for IE7+, Firefox, Chrome, Opera, Safari
		xmlhttp=new XMLHttpRequest();
	}else{// code for IE6, IE5
		xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
	}
	callHandle(0);
	function callHandle(proNum){
		if(proNum<40){
			callAjax(proNum);
		}else{
			document.getElementById(divID1).innerHTML="<img src='images/checked_checkbox-26.png' />";
			document.getElementById(divID2).innerHTML="Done!";
		}
	}
	function callAjax(proNum){
		xmlhttp.open("GET","controllers/ajax/flcit_cleancountydata.php?pid="+proNum+"&z="+Math.random(),true);
		xmlhttp.onload = function(){
			proNum++;
			document.getElementById(divID2).innerHTML=xmlhttp.responseText;
			callHandle(proNum);
		}
		xmlhttp.send(null);
	}
}

function insert_master_data_fl_cit(divID1,divID2){
	document.getElementById(divID2).innerHTML="<img src='images/ajax_loading.gif' height='30' />";
	if (window.XMLHttpRequest){// code for IE7+, Firefox, Chrome, Opera, Safari
		xmlhttp=new XMLHttpRequest();
	}else{// code for IE6, IE5
		xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
	}
	callHandle(1);
	function callHandle(recNum){
		if(recNum>0){
			callAjax();
		}else{
			document.getElementById(divID1).innerHTML="<img src='images/checked_checkbox-26.png' />";
			document.getElementById(divID2).innerHTML="Done!";
		}
	}
	function callAjax(){
		var recNum = 0;
		xmlhttp.open("GET","controllers/ajax/flcit_insertmasterdata.php?z="+Math.random(),true);
		xmlhttp.onload = function(){
			recNum = Number(xmlhttp.responseText);
			document.getElementById(divID2).innerHTML="<img src='images/ajax_loading.gif' height='20' /> Records Remaining: "+recNum;
			callHandle(recNum);
		}
		xmlhttp.send(null);
	}
}

function clean_master_data_fl_cit(divID1,divID2){
	document.getElementById(divID2).innerHTML="<img src='images/ajax_loading.gif' height='20' />";
	if (window.XMLHttpRequest){// code for IE7+, Firefox, Chrome, Opera, Safari
		xmlhttp=new XMLHttpRequest();
	}else{// code for IE6, IE5
		xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
	}
	callHandle(0);
	function callHandle(proNum){
		if(proNum<11){
			callAjax(proNum);
		}else{
			document.getElementById(divID1).innerHTML="<img src='images/checked_checkbox-26.png' />";
			document.getElementById(divID2).innerHTML="Done!";
		}
	}
	function callAjax(proNum){
		xmlhttp.open("GET","controllers/ajax/flcit_cleanmasterdata.php?pid="+proNum+"&z="+Math.random(),true);
		xmlhttp.onload = function(){
			proNum++;
			document.getElementById(divID2).innerHTML=xmlhttp.responseText;
			callHandle(proNum);
		}
		xmlhttp.send(null);
	}
}

function truncate_import_fl_cit(divID1,divID2){
	document.getElementById(divID2).innerHTML="<img src='images/ajax_loading.gif' height='20' />";
	if (window.XMLHttpRequest){// code for IE7+, Firefox, Chrome, Opera, Safari
		xmlhttp=new XMLHttpRequest();
	}else{// code for IE6, IE5
		xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
	}
	xmlhttp.open("GET","controllers/ajax/flcit_truncateimport.php?z="+Math.random(),true);
	xmlhttp.onload = function(){
		document.getElementById(divID1).innerHTML="<img src='images/checked_checkbox-26.png' />";
		document.getElementById(divID2).innerHTML=xmlhttp.responseText;
	}
	xmlhttp.send(null);
}

function insert_import_data_fl_cit(divID1,divID2,cd){
	document.getElementById(divID2).innerHTML="<img src='images/ajax_loading.gif' height='30' />";
	if (window.XMLHttpRequest){// code for IE7+, Firefox, Chrome, Opera, Safari
		xmlhttp=new XMLHttpRequest();
	}else{// code for IE6, IE5
		xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
	}
	callHandle(1,cd);
	function callHandle(recNum,cd){
		if(recNum>0){
			callAjax(cd);
		}else{
			document.getElementById(divID1).innerHTML="<img src='images/checked_checkbox-26.png' />";
			document.getElementById(divID2).innerHTML="Done!";
		}
	}
	function callAjax(cd){
		var recNum = 0;
		xmlhttp.open("GET","controllers/ajax/flcit_insertimportdata.php?cd="+cd+"&z="+Math.random(),true);
		xmlhttp.onload = function(){
			recNum = Number(xmlhttp.responseText);
			document.getElementById(divID2).innerHTML="<img src='images/ajax_loading.gif' height='20' /> Records Remaining: "+recNum;
			callHandle(recNum,cd);
		}
		xmlhttp.send(null);
	}
}


/************************/
/*    Flagler County    */
/************************/

function truncate_master_fl_fla(divID1,divID2){
	document.getElementById(divID2).innerHTML="<img src='images/ajax_loading.gif' height='20' />";
	if (window.XMLHttpRequest){// code for IE7+, Firefox, Chrome, Opera, Safari
		xmlhttp=new XMLHttpRequest();
	}else{// code for IE6, IE5
		xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
	}
	xmlhttp.open("GET","controllers/ajax/flfla_truncatemaster.php?z="+Math.random(),true);
	xmlhttp.onload = function(){
		document.getElementById(divID1).innerHTML="<img src='images/checked_checkbox-26.png' />";
		document.getElementById(divID2).innerHTML=xmlhttp.responseText;
	}
	xmlhttp.send(null);
}

function clean_county_data_fl_fla(divID1,divID2){
	document.getElementById(divID2).innerHTML="<img src='images/ajax_loading.gif' height='20' />";
	if (window.XMLHttpRequest){// code for IE7+, Firefox, Chrome, Opera, Safari
		xmlhttp=new XMLHttpRequest();
	}else{// code for IE6, IE5
		xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
	}
	callHandle(0);
	function callHandle(proNum){
		if(proNum<40){
			callAjax(proNum);
		}else{
			document.getElementById(divID1).innerHTML="<img src='images/checked_checkbox-26.png' />";
			document.getElementById(divID2).innerHTML="Done!";
		}
	}
	function callAjax(proNum){
		xmlhttp.open("GET","controllers/ajax/flfla_cleancountydata.php?pid="+proNum+"&z="+Math.random(),true);
		xmlhttp.onload = function(){
			proNum++;
			document.getElementById(divID2).innerHTML=xmlhttp.responseText;
			callHandle(proNum);
		}
		xmlhttp.send(null);
	}
}

function insert_master_data_fl_fla(divID1,divID2){
	document.getElementById(divID2).innerHTML="<img src='images/ajax_loading.gif' height='30' />";
	if (window.XMLHttpRequest){// code for IE7+, Firefox, Chrome, Opera, Safari
		xmlhttp=new XMLHttpRequest();
	}else{// code for IE6, IE5
		xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
	}
	callHandle(1);
	function callHandle(recNum){
		if(recNum>0){
			callAjax();
		}else{
			document.getElementById(divID1).innerHTML="<img src='images/checked_checkbox-26.png' />";
			document.getElementById(divID2).innerHTML="Done!";
		}
	}
	function callAjax(){
		var recNum = 0;
		xmlhttp.open("GET","controllers/ajax/flfla_insertmasterdata.php?z="+Math.random(),true);
		xmlhttp.onload = function(){
			recNum = Number(xmlhttp.responseText);
			document.getElementById(divID2).innerHTML="<img src='images/ajax_loading.gif' height='20' /> Records Remaining: "+recNum;
			callHandle(recNum);
		}
		xmlhttp.send(null);
	}
}

function clean_master_data_fl_fla(divID1,divID2){
	document.getElementById(divID2).innerHTML="<img src='images/ajax_loading.gif' height='20' />";
	if (window.XMLHttpRequest){// code for IE7+, Firefox, Chrome, Opera, Safari
		xmlhttp=new XMLHttpRequest();
	}else{// code for IE6, IE5
		xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
	}
	callHandle(0);
	function callHandle(proNum){
		if(proNum<11){
			callAjax(proNum);
		}else{
			document.getElementById(divID1).innerHTML="<img src='images/checked_checkbox-26.png' />";
			document.getElementById(divID2).innerHTML="Done!";
		}
	}
	function callAjax(proNum){
		xmlhttp.open("GET","controllers/ajax/flfla_cleanmasterdata.php?pid="+proNum+"&z="+Math.random(),true);
		xmlhttp.onload = function(){
			proNum++;
			document.getElementById(divID2).innerHTML=xmlhttp.responseText;
			callHandle(proNum);
		}
		xmlhttp.send(null);
	}
}

function truncate_import_fl_fla(divID1,divID2){
	document.getElementById(divID2).innerHTML="<img src='images/ajax_loading.gif' height='20' />";
	if (window.XMLHttpRequest){// code for IE7+, Firefox, Chrome, Opera, Safari
		xmlhttp=new XMLHttpRequest();
	}else{// code for IE6, IE5
		xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
	}
	xmlhttp.open("GET","controllers/ajax/flfla_truncateimport.php?z="+Math.random(),true);
	xmlhttp.onload = function(){
		document.getElementById(divID1).innerHTML="<img src='images/checked_checkbox-26.png' />";
		document.getElementById(divID2).innerHTML=xmlhttp.responseText;
	}
	xmlhttp.send(null);
}

function insert_import_data_fl_fla(divID1,divID2,cd){
	document.getElementById(divID2).innerHTML="<img src='images/ajax_loading.gif' height='30' />";
	if (window.XMLHttpRequest){// code for IE7+, Firefox, Chrome, Opera, Safari
		xmlhttp=new XMLHttpRequest();
	}else{// code for IE6, IE5
		xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
	}
	callHandle(1,cd);
	function callHandle(recNum,cd){
		if(recNum>0){
			callAjax(cd);
		}else{
			document.getElementById(divID1).innerHTML="<img src='images/checked_checkbox-26.png' />";
			document.getElementById(divID2).innerHTML="Done!";
		}
	}
	function callAjax(cd){
		var recNum = 0;
		xmlhttp.open("GET","controllers/ajax/flfla_insertimportdata.php?cd="+cd+"&z="+Math.random(),true);
		xmlhttp.onload = function(){
			recNum = Number(xmlhttp.responseText);
			document.getElementById(divID2).innerHTML="<img src='images/ajax_loading.gif' height='20' /> Records Remaining: "+recNum;
			callHandle(recNum,cd);
		}
		xmlhttp.send(null);
	}
}

/************************/
/*    Indian River County    */
/************************/

function truncate_master_fl_irc(divID1,divID2){
	document.getElementById(divID2).innerHTML="<img src='images/ajax_loading.gif' height='20' />";
	if (window.XMLHttpRequest){// code for IE7+, Firefox, Chrome, Opera, Safari
		xmlhttp=new XMLHttpRequest();
	}else{// code for IE6, IE5
		xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
	}
	xmlhttp.open("GET","controllers/ajax/flirc_truncatemaster.php?z="+Math.random(),true);
	xmlhttp.onload = function(){
		document.getElementById(divID1).innerHTML="<img src='images/checked_checkbox-26.png' />";
		document.getElementById(divID2).innerHTML=xmlhttp.responseText;
	}
	xmlhttp.send(null);
}

function clean_county_data_fl_irc(divID1,divID2){
	document.getElementById(divID2).innerHTML="<img src='images/ajax_loading.gif' height='20' />";
	if (window.XMLHttpRequest){// code for IE7+, Firefox, Chrome, Opera, Safari
		xmlhttp=new XMLHttpRequest();
	}else{// code for IE6, IE5
		xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
	}
	callHandle(0);
	function callHandle(proNum){
		if(proNum<40){
			callAjax(proNum);
		}else{
			document.getElementById(divID1).innerHTML="<img src='images/checked_checkbox-26.png' />";
			document.getElementById(divID2).innerHTML="Done!";
		}
	}
	function callAjax(proNum){
		xmlhttp.open("GET","controllers/ajax/flirc_cleancountydata.php?pid="+proNum+"&z="+Math.random(),true);
		xmlhttp.onload = function(){
			proNum++;
			document.getElementById(divID2).innerHTML=xmlhttp.responseText;
			callHandle(proNum);
		}
		xmlhttp.send(null);
	}
}

function insert_master_data_fl_irc(divID1,divID2){
	document.getElementById(divID2).innerHTML="<img src='images/ajax_loading.gif' height='30' />";
	if (window.XMLHttpRequest){// code for IE7+, Firefox, Chrome, Opera, Safari
		xmlhttp=new XMLHttpRequest();
	}else{// code for IE6, IE5
		xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
	}
	callHandle(1);
	function callHandle(recNum){
		if(recNum>0){
			callAjax();
		}else{
			document.getElementById(divID1).innerHTML="<img src='images/checked_checkbox-26.png' />";
			document.getElementById(divID2).innerHTML="Done!";
		}
	}
	function callAjax(){
		var recNum = 0;
		xmlhttp.open("GET","controllers/ajax/flirc_insertmasterdata.php?z="+Math.random(),true);
		xmlhttp.onload = function(){
			recNum = Number(xmlhttp.responseText);
			document.getElementById(divID2).innerHTML="<img src='images/ajax_loading.gif' height='20' /> Records Remaining: "+recNum;
			callHandle(recNum);
		}
		xmlhttp.send(null);
	}
}

function clean_master_data_fl_irc(divID1,divID2){
	document.getElementById(divID2).innerHTML="<img src='images/ajax_loading.gif' height='20' />";
	if (window.XMLHttpRequest){// code for IE7+, Firefox, Chrome, Opera, Safari
		xmlhttp=new XMLHttpRequest();
	}else{// code for IE6, IE5
		xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
	}
	callHandle(0);
	function callHandle(proNum){
		if(proNum<11){
			callAjax(proNum);
		}else{
			document.getElementById(divID1).innerHTML="<img src='images/checked_checkbox-26.png' />";
			document.getElementById(divID2).innerHTML="Done!";
		}
	}
	function callAjax(proNum){
		xmlhttp.open("GET","controllers/ajax/flirc_cleanmasterdata.php?pid="+proNum+"&z="+Math.random(),true);
		xmlhttp.onload = function(){
			proNum++;
			document.getElementById(divID2).innerHTML=xmlhttp.responseText;
			callHandle(proNum);
		}
		xmlhttp.send(null);
	}
}

function truncate_import_fl_irc(divID1,divID2){
	document.getElementById(divID2).innerHTML="<img src='images/ajax_loading.gif' height='20' />";
	if (window.XMLHttpRequest){// code for IE7+, Firefox, Chrome, Opera, Safari
		xmlhttp=new XMLHttpRequest();
	}else{// code for IE6, IE5
		xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
	}
	xmlhttp.open("GET","controllers/ajax/flirc_truncateimport.php?z="+Math.random(),true);
	xmlhttp.onload = function(){
		document.getElementById(divID1).innerHTML="<img src='images/checked_checkbox-26.png' />";
		document.getElementById(divID2).innerHTML=xmlhttp.responseText;
	}
	xmlhttp.send(null);
}

function insert_import_data_fl_irc(divID1,divID2,cd){
	document.getElementById(divID2).innerHTML="<img src='images/ajax_loading.gif' height='30' />";
	if (window.XMLHttpRequest){// code for IE7+, Firefox, Chrome, Opera, Safari
		xmlhttp=new XMLHttpRequest();
	}else{// code for IE6, IE5
		xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
	}
	callHandle(1,cd);
	function callHandle(recNum,cd){
		if(recNum>0){
			callAjax(cd);
		}else{
			document.getElementById(divID1).innerHTML="<img src='images/checked_checkbox-26.png' />";
			document.getElementById(divID2).innerHTML="Done!";
		}
	}
	function callAjax(cd){
		var recNum = 0;
		xmlhttp.open("GET","controllers/ajax/flirc_insertimportdata.php?cd="+cd+"&z="+Math.random(),true);
		xmlhttp.onload = function(){
			recNum = Number(xmlhttp.responseText);
			document.getElementById(divID2).innerHTML="<img src='images/ajax_loading.gif' height='20' /> Records Remaining: "+recNum;
			callHandle(recNum,cd);
		}
		xmlhttp.send(null);
	}
}


/************************/
/*    Marion County    */
/************************/

function truncate_master_fl_mar(divID1,divID2){
	document.getElementById(divID2).innerHTML="<img src='images/ajax_loading.gif' height='20' />";
	if (window.XMLHttpRequest){// code for IE7+, Firefox, Chrome, Opera, Safari
		xmlhttp=new XMLHttpRequest();
	}else{// code for IE6, IE5
		xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
	}
	xmlhttp.open("GET","controllers/ajax/flmar_truncatemaster.php?z="+Math.random(),true);
	xmlhttp.onload = function(){
		document.getElementById(divID1).innerHTML="<img src='images/checked_checkbox-26.png' />";
		document.getElementById(divID2).innerHTML=xmlhttp.responseText;
	}
	xmlhttp.send(null);
}

function clean_county_data_fl_mar(divID1,divID2){
	document.getElementById(divID2).innerHTML="<img src='images/ajax_loading.gif' height='20' />";
	if (window.XMLHttpRequest){// code for IE7+, Firefox, Chrome, Opera, Safari
		xmlhttp=new XMLHttpRequest();
	}else{// code for IE6, IE5
		xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
	}
	callHandle(0);
	function callHandle(proNum){
		if(proNum<40){
			callAjax(proNum);
		}else{
			document.getElementById(divID1).innerHTML="<img src='images/checked_checkbox-26.png' />";
			document.getElementById(divID2).innerHTML="Done!";
		}
	}
	function callAjax(proNum){
		xmlhttp.open("GET","controllers/ajax/flmar_cleancountydata.php?pid="+proNum+"&z="+Math.random(),true);
		xmlhttp.onload = function(){
			proNum++;
			document.getElementById(divID2).innerHTML=xmlhttp.responseText;
			callHandle(proNum);
		}
		xmlhttp.send(null);
	}
}

function insert_master_data_fl_mar(divID1,divID2){
	document.getElementById(divID2).innerHTML="<img src='images/ajax_loading.gif' height='30' />";
	if (window.XMLHttpRequest){// code for IE7+, Firefox, Chrome, Opera, Safari
		xmlhttp=new XMLHttpRequest();
	}else{// code for IE6, IE5
		xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
	}
	callHandle(1);
	function callHandle(recNum){
		if(recNum>0){
			callAjax();
		}else{
			document.getElementById(divID1).innerHTML="<img src='images/checked_checkbox-26.png' />";
			document.getElementById(divID2).innerHTML="Done!";
		}
	}
	function callAjax(){
		var recNum = 0;
		xmlhttp.open("GET","controllers/ajax/flmar_insertmasterdata.php?z="+Math.random(),true);
		xmlhttp.onload = function(){
			recNum = Number(xmlhttp.responseText);
			document.getElementById(divID2).innerHTML="<img src='images/ajax_loading.gif' height='20' /> Records Remaining: "+recNum;
			callHandle(recNum);
		}
		xmlhttp.send(null);
	}
}

function clean_master_data_fl_mar(divID1,divID2){
	document.getElementById(divID2).innerHTML="<img src='images/ajax_loading.gif' height='20' />";
	if (window.XMLHttpRequest){// code for IE7+, Firefox, Chrome, Opera, Safari
		xmlhttp=new XMLHttpRequest();
	}else{// code for IE6, IE5
		xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
	}
	callHandle(0);
	function callHandle(proNum){
		if(proNum<11){
			callAjax(proNum);
		}else{
			document.getElementById(divID1).innerHTML="<img src='images/checked_checkbox-26.png' />";
			document.getElementById(divID2).innerHTML="Done!";
		}
	}
	function callAjax(proNum){
		xmlhttp.open("GET","controllers/ajax/flmar_cleanmasterdata.php?pid="+proNum+"&z="+Math.random(),true);
		xmlhttp.onload = function(){
			proNum++;
			document.getElementById(divID2).innerHTML=xmlhttp.responseText;
			callHandle(proNum);
		}
		xmlhttp.send(null);
	}
}

function truncate_import_fl_mar(divID1,divID2){
	document.getElementById(divID2).innerHTML="<img src='images/ajax_loading.gif' height='20' />";
	if (window.XMLHttpRequest){// code for IE7+, Firefox, Chrome, Opera, Safari
		xmlhttp=new XMLHttpRequest();
	}else{// code for IE6, IE5
		xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
	}
	xmlhttp.open("GET","controllers/ajax/flmar_truncateimport.php?z="+Math.random(),true);
	xmlhttp.onload = function(){
		document.getElementById(divID1).innerHTML="<img src='images/checked_checkbox-26.png' />";
		document.getElementById(divID2).innerHTML=xmlhttp.responseText;
	}
	xmlhttp.send(null);
}

function insert_import_data_fl_mar(divID1,divID2,cd){
	document.getElementById(divID2).innerHTML="<img src='images/ajax_loading.gif' height='30' />";
	if (window.XMLHttpRequest){// code for IE7+, Firefox, Chrome, Opera, Safari
		xmlhttp=new XMLHttpRequest();
	}else{// code for IE6, IE5
		xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
	}
	callHandle(1,cd);
	function callHandle(recNum,cd){
		if(recNum>0){
			callAjax(cd);
		}else{
			document.getElementById(divID1).innerHTML="<img src='images/checked_checkbox-26.png' />";
			document.getElementById(divID2).innerHTML="Done!";
		}
	}
	function callAjax(cd){
		var recNum = 0;
		xmlhttp.open("GET","controllers/ajax/flmar_insertimportdata.php?cd="+cd+"&z="+Math.random(),true);
		xmlhttp.onload = function(){
			recNum = Number(xmlhttp.responseText);
			document.getElementById(divID2).innerHTML="<img src='images/ajax_loading.gif' height='20' /> Records Remaining: "+recNum;
			callHandle(recNum,cd);
		}
		xmlhttp.send(null);
	}
}

/************************/
/*    Osceola County    */
/************************/

function truncate_master_fl_osc(divID1,divID2){
	document.getElementById(divID2).innerHTML="<img src='images/ajax_loading.gif' height='20' />";
	if (window.XMLHttpRequest){// code for IE7+, Firefox, Chrome, Opera, Safari
		xmlhttp=new XMLHttpRequest();
	}else{// code for IE6, IE5
		xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
	}
	xmlhttp.open("GET","controllers/ajax/flosc_truncatemaster.php?z="+Math.random(),true);
	xmlhttp.onload = function(){
		document.getElementById(divID1).innerHTML="<img src='images/checked_checkbox-26.png' />";
		document.getElementById(divID2).innerHTML=xmlhttp.responseText;
	}
	xmlhttp.send(null);
}

function clean_county_data_fl_osc(divID1,divID2){
	document.getElementById(divID2).innerHTML="<img src='images/ajax_loading.gif' height='20' />";
	if (window.XMLHttpRequest){// code for IE7+, Firefox, Chrome, Opera, Safari
		xmlhttp=new XMLHttpRequest();
	}else{// code for IE6, IE5
		xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
	}
	callHandle(0);
	function callHandle(proNum){
		if(proNum<36){
			callAjax(proNum);
		}else{
			document.getElementById(divID1).innerHTML="<img src='images/checked_checkbox-26.png' />";
			document.getElementById(divID2).innerHTML="Done!";
		}
	}
	function callAjax(proNum){
		xmlhttp.open("GET","controllers/ajax/flosc_cleancountydata.php?pid="+proNum+"&z="+Math.random(),true);
		xmlhttp.onload = function(){
			proNum++;
			document.getElementById(divID2).innerHTML=xmlhttp.responseText;
			callHandle(proNum);
		}
		xmlhttp.send(null);
	}
}

function insert_master_data_fl_osc(divID1,divID2){
	document.getElementById(divID2).innerHTML="<img src='images/ajax_loading.gif' height='30' />";
	if (window.XMLHttpRequest){// code for IE7+, Firefox, Chrome, Opera, Safari
		xmlhttp=new XMLHttpRequest();
	}else{// code for IE6, IE5
		xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
	}
	callHandle(1);
	function callHandle(recNum){
		if(recNum>0){
			callAjax();
		}else{
			document.getElementById(divID1).innerHTML="<img src='images/checked_checkbox-26.png' />";
			document.getElementById(divID2).innerHTML="Done!";
		}
	}
	function callAjax(){
		var recNum = 0;
		xmlhttp.open("GET","controllers/ajax/flosc_insertmasterdata.php?z="+Math.random(),true);
		xmlhttp.onload = function(){
			recNum = Number(xmlhttp.responseText);
			document.getElementById(divID2).innerHTML="<img src='images/ajax_loading.gif' height='20' /> Records Remaining: "+recNum;
			callHandle(recNum);
		}
		xmlhttp.send(null);
	}
}

function clean_master_data_fl_osc(divID1,divID2){
	document.getElementById(divID2).innerHTML="<img src='images/ajax_loading.gif' height='20' />";
	if (window.XMLHttpRequest){// code for IE7+, Firefox, Chrome, Opera, Safari
		xmlhttp=new XMLHttpRequest();
	}else{// code for IE6, IE5
		xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
	}
	callHandle(0);
	function callHandle(proNum){
		if(proNum<8){
			callAjax(proNum);
		}else{
			document.getElementById(divID1).innerHTML="<img src='images/checked_checkbox-26.png' />";
			document.getElementById(divID2).innerHTML="Done!";
		}
	}
	function callAjax(proNum){
		xmlhttp.open("GET","controllers/ajax/flosc_cleanmasterdata.php?pid="+proNum+"&z="+Math.random(),true);
		xmlhttp.onload = function(){
			proNum++;
			document.getElementById(divID2).innerHTML=xmlhttp.responseText;
			callHandle(proNum);
		}
		xmlhttp.send(null);
	}
}

function truncate_import_fl_osc(divID1,divID2){
	document.getElementById(divID2).innerHTML="<img src='images/ajax_loading.gif' height='20' />";
	if (window.XMLHttpRequest){// code for IE7+, Firefox, Chrome, Opera, Safari
		xmlhttp=new XMLHttpRequest();
	}else{// code for IE6, IE5
		xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
	}
	xmlhttp.open("GET","controllers/ajax/flosc_truncateimport.php?z="+Math.random(),true);
	xmlhttp.onload = function(){
		document.getElementById(divID1).innerHTML="<img src='images/checked_checkbox-26.png' />";
		document.getElementById(divID2).innerHTML=xmlhttp.responseText;
	}
	xmlhttp.send(null);
}

function insert_import_data_fl_osc(divID1,divID2,cd){
	document.getElementById(divID2).innerHTML="<img src='images/ajax_loading.gif' height='30' />";
	if (window.XMLHttpRequest){// code for IE7+, Firefox, Chrome, Opera, Safari
		xmlhttp=new XMLHttpRequest();
	}else{// code for IE6, IE5
		xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
	}
	callHandle(1,cd);
	function callHandle(recNum,cd){
		if(recNum>0){
			callAjax(cd);
		}else{
			document.getElementById(divID1).innerHTML="<img src='images/checked_checkbox-26.png' />";
			document.getElementById(divID2).innerHTML="Done!";
		}
	}
	function callAjax(cd){
		var recNum = 0;
		xmlhttp.open("GET","controllers/ajax/flosc_insertimportdata.php?cd="+cd+"&z="+Math.random(),true);
		xmlhttp.onload = function(){
			recNum = Number(xmlhttp.responseText);
			document.getElementById(divID2).innerHTML="<img src='images/ajax_loading.gif' height='20' /> Records Remaining: "+recNum;
			callHandle(recNum,cd);
		}
		xmlhttp.send(null);
	}
}

/************************/
/*    Polk County    */
/************************/

function truncate_master_fl_pol(divID1,divID2){
	document.getElementById(divID2).innerHTML="<img src='images/ajax_loading.gif' height='20' />";
	if (window.XMLHttpRequest){// code for IE7+, Firefox, Chrome, Opera, Safari
		xmlhttp=new XMLHttpRequest();
	}else{// code for IE6, IE5
		xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
	}
	xmlhttp.open("GET","controllers/ajax/flpol_truncatemaster.php?z="+Math.random(),true);
	xmlhttp.onload = function(){
		document.getElementById(divID1).innerHTML="<img src='images/checked_checkbox-26.png' />";
		document.getElementById(divID2).innerHTML=xmlhttp.responseText;
	}
	xmlhttp.send(null);
}

function clean_county_data_fl_pol(divID1,divID2){
	document.getElementById(divID2).innerHTML="<img src='images/ajax_loading.gif' height='20' />";
	if (window.XMLHttpRequest){// code for IE7+, Firefox, Chrome, Opera, Safari
		xmlhttp=new XMLHttpRequest();
	}else{// code for IE6, IE5
		xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
	}
	callHandle(0);
	function callHandle(proNum){
		if(proNum<36){
			callAjax(proNum);
		}else{
			document.getElementById(divID1).innerHTML="<img src='images/checked_checkbox-26.png' />";
			document.getElementById(divID2).innerHTML="Done!";
		}
	}
	function callAjax(proNum){
		xmlhttp.open("GET","controllers/ajax/flpol_cleancountydata.php?pid="+proNum+"&z="+Math.random(),true);
		xmlhttp.onload = function(){
			proNum++;
			document.getElementById(divID2).innerHTML=xmlhttp.responseText;
			callHandle(proNum);
		}
		xmlhttp.send(null);
	}
}

function insert_master_data_fl_pol(divID1,divID2){
	document.getElementById(divID2).innerHTML="<img src='images/ajax_loading.gif' height='30' />";
	if (window.XMLHttpRequest){// code for IE7+, Firefox, Chrome, Opera, Safari
		xmlhttp=new XMLHttpRequest();
	}else{// code for IE6, IE5
		xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
	}
	callHandle(1);
	function callHandle(recNum){
		if(recNum>0){
			callAjax();
		}else{
			document.getElementById(divID1).innerHTML="<img src='images/checked_checkbox-26.png' />";
			document.getElementById(divID2).innerHTML="Done!";
		}
	}
	function callAjax(){
		var recNum = 0;
		xmlhttp.open("GET","controllers/ajax/flpol_insertmasterdata.php?z="+Math.random(),true);
		xmlhttp.onload = function(){
			recNum = Number(xmlhttp.responseText);
			document.getElementById(divID2).innerHTML="<img src='images/ajax_loading.gif' height='20' /> Records Remaining: "+recNum;
			callHandle(recNum);
		}
		xmlhttp.send(null);
	}
}

function clean_master_data_fl_pol(divID1,divID2){
	document.getElementById(divID2).innerHTML="<img src='images/ajax_loading.gif' height='20' />";
	if (window.XMLHttpRequest){// code for IE7+, Firefox, Chrome, Opera, Safari
		xmlhttp=new XMLHttpRequest();
	}else{// code for IE6, IE5
		xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
	}
	callHandle(0);
	function callHandle(proNum){
		if(proNum<8){
			callAjax(proNum);
		}else{
			document.getElementById(divID1).innerHTML="<img src='images/checked_checkbox-26.png' />";
			document.getElementById(divID2).innerHTML="Done!";
		}
	}
	function callAjax(proNum){
		xmlhttp.open("GET","controllers/ajax/flpol_cleanmasterdata.php?pid="+proNum+"&z="+Math.random(),true);
		xmlhttp.onload = function(){
			proNum++;
			document.getElementById(divID2).innerHTML=xmlhttp.responseText;
			callHandle(proNum);
		}
		xmlhttp.send(null);
	}
}

function truncate_import_fl_pol(divID1,divID2){
	document.getElementById(divID2).innerHTML="<img src='images/ajax_loading.gif' height='20' />";
	if (window.XMLHttpRequest){// code for IE7+, Firefox, Chrome, Opera, Safari
		xmlhttp=new XMLHttpRequest();
	}else{// code for IE6, IE5
		xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
	}
	xmlhttp.open("GET","controllers/ajax/flpol_truncateimport.php?z="+Math.random(),true);
	xmlhttp.onload = function(){
		document.getElementById(divID1).innerHTML="<img src='images/checked_checkbox-26.png' />";
		document.getElementById(divID2).innerHTML=xmlhttp.responseText;
	}
	xmlhttp.send(null);
}

function insert_import_data_fl_pol(divID1,divID2,cd){
	document.getElementById(divID2).innerHTML="<img src='images/ajax_loading.gif' height='30' />";
	if (window.XMLHttpRequest){// code for IE7+, Firefox, Chrome, Opera, Safari
		xmlhttp=new XMLHttpRequest();
	}else{// code for IE6, IE5
		xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
	}
	callHandle(1,cd);
	function callHandle(recNum,cd){
		if(recNum>0){
			callAjax(cd);
		}else{
			document.getElementById(divID1).innerHTML="<img src='images/checked_checkbox-26.png' />";
			document.getElementById(divID2).innerHTML="Done!";
		}
	}
	function callAjax(cd){
		var recNum = 0;
		xmlhttp.open("GET","controllers/ajax/flpol_insertimportdata.php?cd="+cd+"&z="+Math.random(),true);
		xmlhttp.onload = function(){
			recNum = Number(xmlhttp.responseText);
			document.getElementById(divID2).innerHTML="<img src='images/ajax_loading.gif' height='20' /> Records Remaining: "+recNum;
			callHandle(recNum,cd);
		}
		xmlhttp.send(null);
	}
}

/****************************/
/*    Saint Lucie County    */
/****************************/

function truncate_master_fl_stl(divID1,divID2){
	document.getElementById(divID2).innerHTML="<img src='images/ajax_loading.gif' height='20' />";
	if (window.XMLHttpRequest){// code for IE7+, Firefox, Chrome, Opera, Safari
		xmlhttp=new XMLHttpRequest();
	}else{// code for IE6, IE5
		xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
	}
	xmlhttp.open("GET","controllers/ajax/flstl_truncatemaster.php?z="+Math.random(),true);
	xmlhttp.onload = function(){
		document.getElementById(divID1).innerHTML="<img src='images/checked_checkbox-26.png' />";
		document.getElementById(divID2).innerHTML=xmlhttp.responseText;
	}
	xmlhttp.send(null);
}

function clean_county_data_fl_stl(divID1,divID2){
	document.getElementById(divID2).innerHTML="<img src='images/ajax_loading.gif' height='20' />";
	if (window.XMLHttpRequest){// code for IE7+, Firefox, Chrome, Opera, Safari
		xmlhttp=new XMLHttpRequest();
	}else{// code for IE6, IE5
		xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
	}
	callHandle(0);
	function callHandle(proNum){
		if(proNum<36){
			callAjax(proNum);
		}else{
			document.getElementById(divID1).innerHTML="<img src='images/checked_checkbox-26.png' />";
			document.getElementById(divID2).innerHTML="Done!";
		}
	}
	function callAjax(proNum){
		xmlhttp.open("GET","controllers/ajax/flstl_cleancountydata.php?pid="+proNum+"&z="+Math.random(),true);
		xmlhttp.onload = function(){
			proNum++;
			document.getElementById(divID2).innerHTML=xmlhttp.responseText;
			callHandle(proNum);
		}
		xmlhttp.send(null);
	}
}

function insert_master_data_fl_stl(divID1,divID2){
	document.getElementById(divID2).innerHTML="<img src='images/ajax_loading.gif' height='30' />";
	if (window.XMLHttpRequest){// code for IE7+, Firefox, Chrome, Opera, Safari
		xmlhttp=new XMLHttpRequest();
	}else{// code for IE6, IE5
		xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
	}
	callHandle(1);
	function callHandle(recNum){
		if(recNum>0){
			callAjax();
		}else{
			document.getElementById(divID1).innerHTML="<img src='images/checked_checkbox-26.png' />";
			document.getElementById(divID2).innerHTML="Done!";
		}
	}
	function callAjax(){
		var recNum = 0;
		xmlhttp.open("GET","controllers/ajax/flstl_insertmasterdata.php?z="+Math.random(),true);
		xmlhttp.onload = function(){
			recNum = Number(xmlhttp.responseText);
			document.getElementById(divID2).innerHTML="<img src='images/ajax_loading.gif' height='20' /> Records Remaining: "+recNum;
			callHandle(recNum);
		}
		xmlhttp.send(null);
	}
}

function clean_master_data_fl_stl(divID1,divID2){
	document.getElementById(divID2).innerHTML="<img src='images/ajax_loading.gif' height='20' />";
	if (window.XMLHttpRequest){// code for IE7+, Firefox, Chrome, Opera, Safari
		xmlhttp=new XMLHttpRequest();
	}else{// code for IE6, IE5
		xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
	}
	callHandle(0);
	function callHandle(proNum){
		if(proNum<10){
			callAjax(proNum);
		}else{
			document.getElementById(divID1).innerHTML="<img src='images/checked_checkbox-26.png' />";
			document.getElementById(divID2).innerHTML="Done!";
		}
	}
	function callAjax(proNum){
		xmlhttp.open("GET","controllers/ajax/flstl_cleanmasterdata.php?pid="+proNum+"&z="+Math.random(),true);
		xmlhttp.onload = function(){
			proNum++;
			document.getElementById(divID2).innerHTML=xmlhttp.responseText;
			callHandle(proNum);
		}
		xmlhttp.send(null);
	}
}

function truncate_import_fl_stl(divID1,divID2){
	document.getElementById(divID2).innerHTML="<img src='images/ajax_loading.gif' height='20' />";
	if (window.XMLHttpRequest){// code for IE7+, Firefox, Chrome, Opera, Safari
		xmlhttp=new XMLHttpRequest();
	}else{// code for IE6, IE5
		xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
	}
	xmlhttp.open("GET","controllers/ajax/flstl_truncateimport.php?z="+Math.random(),true);
	xmlhttp.onload = function(){
		document.getElementById(divID1).innerHTML="<img src='images/checked_checkbox-26.png' />";
		document.getElementById(divID2).innerHTML=xmlhttp.responseText;
	}
	xmlhttp.send(null);
}

function insert_import_data_fl_stl(divID1,divID2,cd){
	document.getElementById(divID2).innerHTML="<img src='images/ajax_loading.gif' height='30' />";
	if (window.XMLHttpRequest){// code for IE7+, Firefox, Chrome, Opera, Safari
		xmlhttp=new XMLHttpRequest();
	}else{// code for IE6, IE5
		xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
	}
	callHandle(1,cd);
	function callHandle(recNum,cd){
		if(recNum>0){
			callAjax(cd);
		}else{
			document.getElementById(divID1).innerHTML="<img src='images/checked_checkbox-26.png' />";
			document.getElementById(divID2).innerHTML="Done!";
		}
	}
	function callAjax(cd){
		var recNum = 0;
		xmlhttp.open("GET","controllers/ajax/flstl_insertimportdata.php?cd="+cd+"&z="+Math.random(),true);
		xmlhttp.onload = function(){
			recNum = Number(xmlhttp.responseText);
			document.getElementById(divID2).innerHTML="<img src='images/ajax_loading.gif' height='20' /> Records Remaining: "+recNum;
			callHandle(recNum,cd);
		}
		xmlhttp.send(null);
	}
}