// JavaScript Document

function Is()
{   // convert all characters to lowercase to simplify testing
    var agt = navigator.userAgent.toLowerCase();

    // *** CHECK USER PLATFORM ***
	
	// Macintosh
	this.mac = (agt.indexOf("macintosh")!=-1);
	
	// Windows
	this.win = (agt.indexOf("windows")!=-1);
	
	// *** CHECK LATEST BROWSER VERSION ***

    // Safari Check
    this.safari = ((agt.indexOf('safari')!=-1) && (agt.indexOf('chrome')==1));
	this.safari533 = ((agt.indexOf('safari/533')!=-1) && (agt.indexOf('chrome')==1));
    
	// Internet Explore Check
	this.ie = (agt.indexOf("msie")!=-1);
	this.ie8 = (agt.indexOf("msie 8")!=-1);
	
	// Firefox Check
	this.ff = (agt.indexOf("firefox")!=-1);
	this.ff5 = (agt.indexOf("firefox/5")!=-1);

}

var is = new Is(); 