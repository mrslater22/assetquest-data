// JavaScript Document
var ajaxUrl;

function setAJAXURL(url)
{
    ajaxUrl = url;
}

/************************/
/*     Lee County       */
/************************/

function truncate_master_fl_lee(divID1,divID2){	
	document.getElementById(divID2).innerHTML="<img src='images/ajax_loading.gif' height='20' />";	
	if (window.XMLHttpRequest){// code for IE7+, Firefox, Chrome, Opera, Safari
		xmlhttp=new XMLHttpRequest();
	}else{// code for IE6, IE5
		xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
	}
	xmlhttp.open("GET","controllers/ajax/fllee_truncatemaster.php?z="+Math.random(),true);
	xmlhttp.onload = function(){
		document.getElementById(divID1).innerHTML="<img src='images/checked_checkbox-26.png' />";
		document.getElementById(divID2).innerHTML=xmlhttp.responseText;
	}
	xmlhttp.send(null);	
}

function clean_county_data_fl_lee(divID1,divID2){
	document.getElementById(divID2).innerHTML="<img src='images/ajax_loading.gif' height='20' />";
	if (window.XMLHttpRequest){// code for IE7+, Firefox, Chrome, Opera, Safari
		xmlhttp=new XMLHttpRequest();
	}else{// code for IE6, IE5
		xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
	}
	callHandle(0);
	function callHandle(proNum){
		if(proNum<26){
			callAjax(proNum);
		}else{
			document.getElementById(divID1).innerHTML="<img src='images/checked_checkbox-26.png' />";
			document.getElementById(divID2).innerHTML="Done!";	
		}
	}
	function callAjax(proNum){
		xmlhttp.open("GET","controllers/ajax/fllee_cleancountydata.php?pid="+proNum+"&z="+Math.random(),true);
		xmlhttp.onload = function(){
			proNum++;
			document.getElementById(divID2).innerHTML=xmlhttp.responseText;
			callHandle(proNum);
		}
		xmlhttp.send(null);	
	}
}

function insert_master_data_fl_lee(divID1,divID2){	
	document.getElementById(divID2).innerHTML="<img src='images/ajax_loading.gif' height='30' />";
	if (window.XMLHttpRequest){// code for IE7+, Firefox, Chrome, Opera, Safari
		xmlhttp=new XMLHttpRequest();
	}else{// code for IE6, IE5
		xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
	}
	callHandle(1);
	function callHandle(recNum){
		if(recNum>0){
			callAjax();
		}else{
			document.getElementById(divID1).innerHTML="<img src='images/checked_checkbox-26.png' />";
			document.getElementById(divID2).innerHTML="Done!";	
		}
	}
	function callAjax(){
		var recNum = 0;
		xmlhttp.open("GET","controllers/ajax/fllee_insertmasterdata.php?z="+Math.random(),true);
		xmlhttp.onload = function(){
			recNum = Number(xmlhttp.responseText);
			document.getElementById(divID2).innerHTML="<img src='images/ajax_loading.gif' height='20' /> Records Remaining: "+recNum;
			callHandle(recNum);
		}
		xmlhttp.send(null);	
	}
}

function clean_master_data_fl_lee(divID1,divID2){
	document.getElementById(divID2).innerHTML="<img src='images/ajax_loading.gif' height='20' />";
	if (window.XMLHttpRequest){// code for IE7+, Firefox, Chrome, Opera, Safari
		xmlhttp=new XMLHttpRequest();
	}else{// code for IE6, IE5
		xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
	}
	callHandle(0);
	function callHandle(proNum){
		if(proNum<22){
			callAjax(proNum);
		}else{
			document.getElementById(divID1).innerHTML="<img src='images/checked_checkbox-26.png' />";
			document.getElementById(divID2).innerHTML="Done!";	
		}
	}
	function callAjax(proNum){
		xmlhttp.open("GET","controllers/ajax/fllee_cleanmasterdata.php?pid="+proNum+"&z="+Math.random(),true);
		xmlhttp.onload = function(){
			proNum++;
			document.getElementById(divID2).innerHTML=xmlhttp.responseText;
			callHandle(proNum);
		}
		xmlhttp.send(null);	
	}
}

function truncate_import_fl_lee(divID1,divID2){
	document.getElementById(divID2).innerHTML="<img src='images/ajax_loading.gif' height='20' />";
	if (window.XMLHttpRequest){// code for IE7+, Firefox, Chrome, Opera, Safari
		xmlhttp=new XMLHttpRequest();
	}else{// code for IE6, IE5
		xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
	}
	xmlhttp.open("GET","controllers/ajax/fllee_truncateimport.php?z="+Math.random(),true);
	xmlhttp.onload = function(){
		document.getElementById(divID1).innerHTML="<img src='images/checked_checkbox-26.png' />";
		document.getElementById(divID2).innerHTML=xmlhttp.responseText;
	}
	xmlhttp.send(null);
}

function insert_import_data_fl_lee(divID1,divID2,cd){
	document.getElementById(divID2).innerHTML="<img src='images/ajax_loading.gif' height='30' />";
	if (window.XMLHttpRequest){// code for IE7+, Firefox, Chrome, Opera, Safari
		xmlhttp=new XMLHttpRequest();
	}else{// code for IE6, IE5
		xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
	}
	callHandle(1,cd);
	function callHandle(recNum,cd){
		if(recNum>0){
			callAjax(cd);
		}else{
			document.getElementById(divID1).innerHTML="<img src='images/checked_checkbox-26.png' />";
			document.getElementById(divID2).innerHTML="Done!";	
		}
	}
	function callAjax(cd){
		var recNum = 0;
		xmlhttp.open("GET","controllers/ajax/fllee_insertimportdata.php?cd="+cd+"&z="+Math.random(),true);
		xmlhttp.onload = function(){
			recNum = Number(xmlhttp.responseText);
			document.getElementById(divID2).innerHTML="<img src='images/ajax_loading.gif' height='20' /> Records Remaining: "+recNum;
			callHandle(recNum,cd);
		}
		xmlhttp.send(null);	
	}
}

/************************/
/*  Charlotte County    */
/************************/

function truncate_master_fl_cha(divID1,divID2){	
	document.getElementById(divID2).innerHTML="<img src='images/ajax_loading.gif' height='20' />";	
	if (window.XMLHttpRequest){// code for IE7+, Firefox, Chrome, Opera, Safari
		xmlhttp=new XMLHttpRequest();
	}else{// code for IE6, IE5
		xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
	}
	xmlhttp.open("GET","controllers/ajax/flcha_truncatemaster.php?z="+Math.random(),true);
	xmlhttp.onload = function(){
		document.getElementById(divID1).innerHTML="<img src='images/checked_checkbox-26.png' />";
		document.getElementById(divID2).innerHTML=xmlhttp.responseText;
	}
	xmlhttp.send(null);	
}

function clean_county_data_fl_cha(divID1,divID2){
	document.getElementById(divID2).innerHTML="<img src='images/ajax_loading.gif' height='20' />";
	if (window.XMLHttpRequest){// code for IE7+, Firefox, Chrome, Opera, Safari
		xmlhttp=new XMLHttpRequest();
	}else{// code for IE6, IE5
		xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
	}
	callHandle(0);
	function callHandle(proNum){
		if(proNum<26){
			callAjax(proNum);
		}else{
			document.getElementById(divID1).innerHTML="<img src='images/checked_checkbox-26.png' />";
			document.getElementById(divID2).innerHTML="Done!";	
		}
	}
	function callAjax(proNum){
		xmlhttp.open("GET","controllers/ajax/flcha_cleancountydata.php?pid="+proNum+"&z="+Math.random(),true);
		xmlhttp.onload = function(){
			proNum++;
			document.getElementById(divID2).innerHTML=xmlhttp.responseText;
			callHandle(proNum);
		}
		xmlhttp.send(null);	
	}
}

function insert_master_data_fl_cha(divID1,divID2){	
	document.getElementById(divID2).innerHTML="<img src='images/ajax_loading.gif' height='30' />";
	if (window.XMLHttpRequest){// code for IE7+, Firefox, Chrome, Opera, Safari
		xmlhttp=new XMLHttpRequest();
	}else{// code for IE6, IE5
		xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
	}
	callHandle(1);
	function callHandle(recNum){
		if(recNum>0){
			callAjax();
		}else{
			document.getElementById(divID1).innerHTML="<img src='images/checked_checkbox-26.png' />";
			document.getElementById(divID2).innerHTML="Done!";	
		}
	}
	function callAjax(){
		var recNum = 0;
		xmlhttp.open("GET","controllers/ajax/flcha_insertmasterdata.php?z="+Math.random(),true);
		xmlhttp.onload = function(){
			recNum = Number(xmlhttp.responseText);
			document.getElementById(divID2).innerHTML="<img src='images/ajax_loading.gif' height='20' /> Records Remaining: "+recNum;
			callHandle(recNum);
		}
		xmlhttp.send(null);	
	}
}

function clean_master_data_fl_cha(divID1,divID2){
	document.getElementById(divID2).innerHTML="<img src='images/ajax_loading.gif' height='20' />";
	if (window.XMLHttpRequest){// code for IE7+, Firefox, Chrome, Opera, Safari
		xmlhttp=new XMLHttpRequest();
	}else{// code for IE6, IE5
		xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
	}
	callHandle(0);
	function callHandle(proNum){
		if(proNum<11){
			callAjax(proNum);
		}else{
			document.getElementById(divID1).innerHTML="<img src='images/checked_checkbox-26.png' />";
			document.getElementById(divID2).innerHTML="Done!";	
		}
	}
	function callAjax(proNum){
		xmlhttp.open("GET","controllers/ajax/flcha_cleanmasterdata.php?pid="+proNum+"&z="+Math.random(),true);
		xmlhttp.onload = function(){
			proNum++;
			document.getElementById(divID2).innerHTML=xmlhttp.responseText;
			callHandle(proNum);
		}
		xmlhttp.send(null);	
	}
}

function truncate_import_fl_cha(divID1,divID2){
	document.getElementById(divID2).innerHTML="<img src='images/ajax_loading.gif' height='20' />";
	if (window.XMLHttpRequest){// code for IE7+, Firefox, Chrome, Opera, Safari
		xmlhttp=new XMLHttpRequest();
	}else{// code for IE6, IE5
		xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
	}
	xmlhttp.open("GET","controllers/ajax/flcha_truncateimport.php?z="+Math.random(),true);
	xmlhttp.onload = function(){
		document.getElementById(divID1).innerHTML="<img src='images/checked_checkbox-26.png' />";
		document.getElementById(divID2).innerHTML=xmlhttp.responseText;
	}
	xmlhttp.send(null);
}

function insert_import_data_fl_cha(divID1,divID2,cd){
	document.getElementById(divID2).innerHTML="<img src='images/ajax_loading.gif' height='30' />";
	if (window.XMLHttpRequest){// code for IE7+, Firefox, Chrome, Opera, Safari
		xmlhttp=new XMLHttpRequest();
	}else{// code for IE6, IE5
		xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
	}
	callHandle(1,cd);
	function callHandle(recNum,cd){
		if(recNum>0){
			callAjax(cd);
		}else{
			document.getElementById(divID1).innerHTML="<img src='images/checked_checkbox-26.png' />";
			document.getElementById(divID2).innerHTML="Done!";	
		}
	}
	function callAjax(cd){
		var recNum = 0;
		xmlhttp.open("GET","controllers/ajax/flcha_insertimportdata.php?cd="+cd+"&z="+Math.random(),true);
		xmlhttp.onload = function(){
			recNum = Number(xmlhttp.responseText);
			document.getElementById(divID2).innerHTML="<img src='images/ajax_loading.gif' height='20' /> Records Remaining: "+recNum;
			callHandle(recNum,cd);
		}
		xmlhttp.send(null);	
	}
}

/************************/
/*   Sarasota County    */
/************************/

function truncate_master_fl_sar(divID1,divID2){	
	document.getElementById(divID2).innerHTML="<img src='images/ajax_loading.gif' height='20' />";	
	if (window.XMLHttpRequest){// code for IE7+, Firefox, Chrome, Opera, Safari
		xmlhttp=new XMLHttpRequest();
	}else{// code for IE6, IE5
		xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
	}
	xmlhttp.open("GET","controllers/ajax/flsar_truncatemaster.php?z="+Math.random(),true);
	xmlhttp.onload = function(){
		document.getElementById(divID1).innerHTML="<img src='images/checked_checkbox-26.png' />";
		document.getElementById(divID2).innerHTML=xmlhttp.responseText;
	}
	xmlhttp.send(null);	
}

function clean_county_data_fl_sar(divID1,divID2){
	document.getElementById(divID2).innerHTML="<img src='images/ajax_loading.gif' height='20' />";
	if (window.XMLHttpRequest){// code for IE7+, Firefox, Chrome, Opera, Safari
		xmlhttp=new XMLHttpRequest();
	}else{// code for IE6, IE5
		xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
	}
	callHandle(0);
	function callHandle(proNum){
		if(proNum<42){
			callAjax(proNum);
		}else{
			document.getElementById(divID1).innerHTML="<img src='images/checked_checkbox-26.png' />";
			document.getElementById(divID2).innerHTML="Done!";	
		}
	}
	function callAjax(proNum){
		xmlhttp.open("GET","controllers/ajax/flsar_cleancountydata.php?pid="+proNum+"&z="+Math.random(),true);
		xmlhttp.onload = function(){
			proNum++;
			document.getElementById(divID2).innerHTML=xmlhttp.responseText;
			callHandle(proNum);
		}
		xmlhttp.send(null);	
	}
}

function insert_master_data_fl_sar(divID1,divID2){	
	document.getElementById(divID2).innerHTML="<img src='images/ajax_loading.gif' height='30' />";
	if (window.XMLHttpRequest){// code for IE7+, Firefox, Chrome, Opera, Safari
		xmlhttp=new XMLHttpRequest();
	}else{// code for IE6, IE5
		xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
	}
	callHandle(1);
	function callHandle(recNum){
		if(recNum>0){
			callAjax();
		}else{
			document.getElementById(divID1).innerHTML="<img src='images/checked_checkbox-26.png' />";
			document.getElementById(divID2).innerHTML="Done!";	
		}
	}
	function callAjax(){
		var recNum = 0;
		xmlhttp.open("GET","controllers/ajax/flsar_insertmasterdata.php?z="+Math.random(),true);
		xmlhttp.onload = function(){
			recNum = Number(xmlhttp.responseText);
			document.getElementById(divID2).innerHTML="<img src='images/ajax_loading.gif' height='20' /> Records Remaining: "+recNum;
			callHandle(recNum);
		}
		xmlhttp.send(null);	
	}
}

function clean_master_data_fl_sar(divID1,divID2){
	document.getElementById(divID2).innerHTML="<img src='images/ajax_loading.gif' height='20' />";
	if (window.XMLHttpRequest){// code for IE7+, Firefox, Chrome, Opera, Safari
		xmlhttp=new XMLHttpRequest();
	}else{// code for IE6, IE5
		xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
	}
	callHandle(0);
	function callHandle(proNum){
		if(proNum<10){
			callAjax(proNum);
		}else{
			document.getElementById(divID1).innerHTML="<img src='images/checked_checkbox-26.png' />";
			document.getElementById(divID2).innerHTML="Done!";	
		}
	}
	function callAjax(proNum){
		xmlhttp.open("GET","controllers/ajax/flsar_cleanmasterdata.php?pid="+proNum+"&z="+Math.random(),true);
		xmlhttp.onload = function(){
			proNum++;
			document.getElementById(divID2).innerHTML=xmlhttp.responseText;
			callHandle(proNum);
		}
		xmlhttp.send(null);	
	}
}

function truncate_import_fl_sar(divID1,divID2){
	document.getElementById(divID2).innerHTML="<img src='images/ajax_loading.gif' height='20' />";
	if (window.XMLHttpRequest){// code for IE7+, Firefox, Chrome, Opera, Safari
		xmlhttp=new XMLHttpRequest();
	}else{// code for IE6, IE5
		xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
	}
	xmlhttp.open("GET","controllers/ajax/flsar_truncateimport.php?z="+Math.random(),true);
	xmlhttp.onload = function(){
		document.getElementById(divID1).innerHTML="<img src='images/checked_checkbox-26.png' />";
		document.getElementById(divID2).innerHTML=xmlhttp.responseText;
	}
	xmlhttp.send(null);
}

function insert_import_data_fl_sar(divID1,divID2,cd){
	document.getElementById(divID2).innerHTML="<img src='images/ajax_loading.gif' height='30' />";
	if (window.XMLHttpRequest){// code for IE7+, Firefox, Chrome, Opera, Safari
		xmlhttp=new XMLHttpRequest();
	}else{// code for IE6, IE5
		xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
	}
	callHandle(1,cd);
	function callHandle(recNum,cd){
		if(recNum>0){
			callAjax(cd);
		}else{
			document.getElementById(divID1).innerHTML="<img src='images/checked_checkbox-26.png' />";
			document.getElementById(divID2).innerHTML="Done!";	
		}
	}
	function callAjax(cd){
		var recNum = 0;
		xmlhttp.open("GET","controllers/ajax/flsar_insertimportdata.php?cd="+cd+"&z="+Math.random(),true);
		xmlhttp.onload = function(){
			recNum = Number(xmlhttp.responseText);
			document.getElementById(divID2).innerHTML="<img src='images/ajax_loading.gif' height='20' /> Records Remaining: "+recNum;
			callHandle(recNum,cd);
		}
		xmlhttp.send(null);	
	}
}

/************************/
/*    Collier County    */
/************************/

function truncate_master_fl_col(divID1,divID2){	
	document.getElementById(divID2).innerHTML="<img src='images/ajax_loading.gif' height='20' />";	
	if (window.XMLHttpRequest){// code for IE7+, Firefox, Chrome, Opera, Safari
		xmlhttp=new XMLHttpRequest();
	}else{// code for IE6, IE5
		xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
	}
	xmlhttp.open("GET","controllers/ajax/flcol_truncatemaster.php?z="+Math.random(),true);
	xmlhttp.onload = function(){
		document.getElementById(divID1).innerHTML="<img src='images/checked_checkbox-26.png' />";
		document.getElementById(divID2).innerHTML=xmlhttp.responseText;
	}
	xmlhttp.send(null);	
}

function clean_county_data_fl_col(divID1,divID2){
	document.getElementById(divID2).innerHTML="<img src='images/ajax_loading.gif' height='20' />";
	if (window.XMLHttpRequest){// code for IE7+, Firefox, Chrome, Opera, Safari
		xmlhttp=new XMLHttpRequest();
	}else{// code for IE6, IE5
		xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
	}
	callHandle(0);
	function callHandle(proNum){
		if(proNum<40){
			callAjax(proNum);
		}else{
			document.getElementById(divID1).innerHTML="<img src='images/checked_checkbox-26.png' />";
			document.getElementById(divID2).innerHTML="Done!";	
		}
	}
	function callAjax(proNum){
		xmlhttp.open("GET","controllers/ajax/flcol_cleancountydata.php?pid="+proNum+"&z="+Math.random(),true);
		xmlhttp.onload = function(){
			proNum++;
			document.getElementById(divID2).innerHTML=xmlhttp.responseText;
			callHandle(proNum);
		}
		xmlhttp.send(null);	
	}
}

function insert_master_data_fl_col(divID1,divID2){	
	document.getElementById(divID2).innerHTML="<img src='images/ajax_loading.gif' height='30' />";
	if (window.XMLHttpRequest){// code for IE7+, Firefox, Chrome, Opera, Safari
		xmlhttp=new XMLHttpRequest();
	}else{// code for IE6, IE5
		xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
	}
	callHandle(1);
	function callHandle(recNum){
		if(recNum>0){
			callAjax();
		}else{
			document.getElementById(divID1).innerHTML="<img src='images/checked_checkbox-26.png' />";
			document.getElementById(divID2).innerHTML="Done!";	
		}
	}
	function callAjax(){
		var recNum = 0;
		xmlhttp.open("GET","controllers/ajax/flcol_insertmasterdata.php?z="+Math.random(),true);
		xmlhttp.onload = function(){
			recNum = Number(xmlhttp.responseText);
			document.getElementById(divID2).innerHTML="<img src='images/ajax_loading.gif' height='20' /> Records Remaining: "+recNum;
			callHandle(recNum);
		}
		xmlhttp.send(null);	
	}
}

function clean_master_data_fl_col(divID1,divID2){
	document.getElementById(divID2).innerHTML="<img src='images/ajax_loading.gif' height='20' />";
	if (window.XMLHttpRequest){// code for IE7+, Firefox, Chrome, Opera, Safari
		xmlhttp=new XMLHttpRequest();
	}else{// code for IE6, IE5
		xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
	}
	callHandle(0);
	function callHandle(proNum){
		if(proNum<11){
			callAjax(proNum);
		}else{
			document.getElementById(divID1).innerHTML="<img src='images/checked_checkbox-26.png' />";
			document.getElementById(divID2).innerHTML="Done!";	
		}
	}
	function callAjax(proNum){
		xmlhttp.open("GET","controllers/ajax/flcol_cleanmasterdata.php?pid="+proNum+"&z="+Math.random(),true);
		xmlhttp.onload = function(){
			proNum++;
			document.getElementById(divID2).innerHTML=xmlhttp.responseText;
			callHandle(proNum);
		}
		xmlhttp.send(null);	
	}
}

function truncate_import_fl_col(divID1,divID2){
	document.getElementById(divID2).innerHTML="<img src='images/ajax_loading.gif' height='20' />";
	if (window.XMLHttpRequest){// code for IE7+, Firefox, Chrome, Opera, Safari
		xmlhttp=new XMLHttpRequest();
	}else{// code for IE6, IE5
		xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
	}
	xmlhttp.open("GET","controllers/ajax/flcol_truncateimport.php?z="+Math.random(),true);
	xmlhttp.onload = function(){
		document.getElementById(divID1).innerHTML="<img src='images/checked_checkbox-26.png' />";
		document.getElementById(divID2).innerHTML=xmlhttp.responseText;
	}
	xmlhttp.send(null);
}

function insert_import_data_fl_col(divID1,divID2,cd){
	document.getElementById(divID2).innerHTML="<img src='images/ajax_loading.gif' height='30' />";
	if (window.XMLHttpRequest){// code for IE7+, Firefox, Chrome, Opera, Safari
		xmlhttp=new XMLHttpRequest();
	}else{// code for IE6, IE5
		xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
	}
	callHandle(1,cd);
	function callHandle(recNum,cd){
		if(recNum>0){
			callAjax(cd);
		}else{
			document.getElementById(divID1).innerHTML="<img src='images/checked_checkbox-26.png' />";
			document.getElementById(divID2).innerHTML="Done!";	
		}
	}
	function callAjax(cd){
		var recNum = 0;
		xmlhttp.open("GET","controllers/ajax/flcol_insertimportdata.php?cd="+cd+"&z="+Math.random(),true);
		xmlhttp.onload = function(){
			recNum = Number(xmlhttp.responseText);
			document.getElementById(divID2).innerHTML="<img src='images/ajax_loading.gif' height='20' /> Records Remaining: "+recNum;
			callHandle(recNum,cd);
		}
		xmlhttp.send(null);	
	}
}